"""Generate the multi-resolution application icon."""
from pathlib import Path

from PIL import Image, ImageDraw

SCALE = 4
SIZE = 256
W = SIZE * SCALE
HERE = Path(__file__).resolve().parent


def lerp(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def star(draw, cx, cy, outer, inner, fill, points=4):
    pts = []
    for i in range(points * 2):
        angle = -90 + i * (180 / points)
        radius = outer if i % 2 == 0 else inner
        from math import cos, sin, radians

        pts.append((cx + cos(radians(angle)) * radius,
                    cy + sin(radians(angle)) * radius))
    draw.polygon(pts, fill=fill)


def main():
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    margin = 6 * SCALE
    radius = 56 * SCALE
    top = (37, 99, 235)
    bottom = (59, 130, 246)
    for y in range(margin, W - margin):
        t = (y - margin) / max(1, (W - 2 * margin - 1))
        color = lerp(top, bottom, t)
        draw.rectangle([margin, y, W - margin, y], fill=color + (255,))
    mask = Image.new("L", (W, W), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [margin, margin, W - margin, W - margin], radius=radius, fill=255
    )
    img.putalpha(mask)

    # Soft top highlight.
    gloss = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    gd = ImageDraw.Draw(gloss)
    gd.rounded_rectangle(
        [margin + 10 * SCALE, margin + 8 * SCALE, W - margin - 10 * SCALE, W // 2],
        radius=radius, fill=(255, 255, 255, 28)
    )
    img = Image.alpha_composite(img, gloss)
    draw = ImageDraw.Draw(img)

    star(draw, 118 * SCALE, 138 * SCALE, 60 * SCALE, 15 * SCALE, (255, 255, 255, 255))
    star(draw, 184 * SCALE, 72 * SCALE, 25 * SCALE, 7 * SCALE, (219, 234, 254, 255))

    img = img.resize((SIZE, SIZE), Image.LANCZOS)
    img.save(
        HERE / "app.ico",
        format="ICO",
        sizes=[(16, 16), (20, 20), (24, 24), (32, 32), (40, 40), (48, 48),
               (64, 64), (128, 128), (256, 256)],
    )
    img.save(HERE / "app.png", format="PNG")
    print("wrote app.ico and app.png")


if __name__ == "__main__":
    main()
