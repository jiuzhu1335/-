[CmdletBinding()]
param(
    [switch]$Clean,
    [switch]$Run,
    [switch]$Package
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$dist = Join-Path $root 'dist'
$build = Join-Path $root 'build'
$exeName = 'MemoryAssist.exe'

function Find-Zig {
    $candidates = @(
        (Join-Path $root '.tools\zig\zig.exe'),
        (Join-Path (Split-Path $root -Parent) '.tools\zig\zig.exe'),
        (Join-Path (Split-Path $root -Parent) '..\.tools\zig\zig.exe')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) { return (Resolve-Path $candidate).Path }
    }
    $command = Get-Command zig -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    return $null
}

$zig = Find-Zig
if (-not $zig) {
    throw 'Zig 0.14.1 is required. Put zig.exe on PATH or in .tools\zig\zig.exe.'
}
$version = & $zig version
if ($version -notlike '0.14.1*') {
    throw "Zig 0.14.1 required, found $version"
}

if (Get-Process MemoryAssist -ErrorAction SilentlyContinue) {
    throw 'MemoryAssist.exe is running. Close it before rebuilding.'
}

if ($Clean) {
    Remove-Item $dist, $build -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Force -Path $dist, $build | Out-Null

$resource = Join-Path $build 'app.res'
Push-Location (Join-Path $root 'resources')
try {
    & $zig rc app.rc $resource
    if ($LASTEXITCODE -ne 0) { throw 'Resource compilation failed' }
} finally {
    Pop-Location
}

$exe = Join-Path $dist $exeName
$compileArgs = @(
    'c++', (Join-Path $root 'src\main.cpp'), $resource,
    '-target', 'x86_64-windows-gnu', '-O2', '-s', '-municode',
    '-Wl,--subsystem,windows', '-fno-exceptions', '-fno-rtti',
    '-finput-charset=UTF-8', '-fexec-charset=UTF-8',
    '-o', $exe,
    '-lpdh', '-lpsapi', '-ladvapi32', '-lshell32', '-lcomdlg32',
    '-lgdiplus', '-lmsimg32', '-luser32', '-lgdi32', '-lole32',
    '-luuid', '-lntdll', '-lm'
)
Write-Host 'Compiling standard build...' -ForegroundColor Cyan
& $zig @compileArgs
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $exe)) { throw 'Compilation failed' }

Copy-Item (Join-Path $root 'README.md') $dist -Force
Copy-Item (Join-Path $root 'LICENSE') $dist -Force
$distDocs = Join-Path $dist 'docs'
New-Item -ItemType Directory -Force -Path $distDocs | Out-Null
foreach ($image in @('screenshot.png', 'settings.png', 'compact.png', 'minimal.png', 'background.png', 'background-image.png')) {
    $source = Join-Path $root "docs\$image"
    if (Test-Path $source) { Copy-Item $source $distDocs -Force }
}

$file = Get-Item $exe
$hash = (Get-FileHash $exe -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host ''
Write-Host 'Build OK' -ForegroundColor Green
Write-Host ("  {0}  ({1:N1} KB)" -f $file.FullName, ($file.Length / 1KB))
Write-Host "  SHA-256: $hash"

if ($Package) {
    $zip = Join-Path $dist 'MemoryAssist-v1.0-win64.zip'
    if (Test-Path $zip) { Remove-Item $zip -Force }
    $stage = Join-Path $build 'package'
    if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    Copy-Item $exe $stage -Force
    Copy-Item (Join-Path $dist 'README.md') $stage -Force
    Copy-Item (Join-Path $dist 'LICENSE') $stage -Force
    Copy-Item $distDocs $stage -Recurse -Force
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip -CompressionLevel Optimal
    Remove-Item $stage -Recurse -Force
    Write-Host "  Package: $zip" -ForegroundColor Green
}

if ($Run) { Start-Process -FilePath $exe }
