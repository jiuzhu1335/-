// MemoryAssist - a tiny native Windows memory monitor / working-set trimmer.
// Build: see build.ps1 (Zig's bundled clang + Windows SDK headers).
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#ifndef WINVER
#define WINVER 0x0A00
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif

#include <windows.h>
#include <windowsx.h>
#include <commdlg.h>
#include <propidl.h>
#include <gdiplus.h>
#include <evntrace.h>
#include <evntcons.h>
#include <pdh.h>
#include <pdhmsg.h>
#include <psapi.h>
#include <shellapi.h>
#include <strsafe.h>
#include <tlhelp32.h>
#include <wchar.h>

#include <cmath>

#if defined(_MSC_VER)
#pragma execution_character_set("utf-8")
#endif

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
#ifdef TEST_INSTANCE
static const wchar_t* kWindowClass = L"MemoryAssist.MainWindow.test";
#else
static const wchar_t* kWindowClass = L"MemoryAssist.MainWindow.v1";
#endif
static const wchar_t* kAceSettingsClass = L"MemoryAssist.AceSettings.v1";
static const wchar_t* kWindowTitle = L"内存整理助手";

#ifdef SPECIAL_VERSION
static const bool kSpecialTheme = true;
#else
static const bool kSpecialTheme = false;
#endif
static wchar_t g_displayName[64] = L"内存整理助手";
static HWND g_nameEdit = nullptr;
static HBITMAP g_watermarkBitmap = nullptr;
static int g_watermarkWidth = 0;
static int g_watermarkHeight = 0;
#ifdef TEST_INSTANCE
static const wchar_t* kMutexName   = L"Local\\MemoryAssist.Test.SingleInstance.v1";
#elif defined(SPECIAL_VERSION)
static const wchar_t* kMutexName   = L"Local\\MemoryAssist.Special.SingleInstance.v1";
#else
static const wchar_t* kMutexName   = L"Local\\MemoryAssist.SingleInstance.v1";
#endif
static const wchar_t* kSettingsKey = L"Software\\MemoryAssist";

#ifndef SPECIAL_VERSION
static const int kDesignW = 1180;
static const int kDesignH = 676;
static const int kCompactW = 560;
static const int kCompactH = 460;
static const int kMinimalW = 1120;
static const int kMinimalH = 32;
#else
static const int kDesignW = 820;
static const int kDesignH = 676;
static const int kCompactW = 380;
static const int kCompactH = 230;
static const int kMinimalW = 860;
static const int kMinimalH = 32;
#endif
static const int kMinThreshold = 50;
static const int kMaxThreshold = 95;
static const UINT kSampleTimer = 1;
static const UINT kSelfTrimTimer = 2;
static const UINT WM_APP_CLEAN_DONE = WM_APP + 1;
static const ULONGLONG kAutoCooldownMs = 60ULL * 1000ULL;
static const wchar_t* kFpsSessionName = L"MemoryAssistFpsSessionV1";
static const GUID kDxgiProvider = {
    0xCA11C036, 0x0102, 0x4A2D, {0xA6, 0xAD, 0xF0, 0x3C, 0xFE, 0xD5, 0xD3, 0xC9}
};
static const GUID kD3d9Provider = {
    0x783ACA0A, 0x790E, 0x4D7F, {0x84, 0x51, 0xAA, 0x85, 0x05, 0x11, 0xC6, 0xB9}
};

struct BackgroundPreset {
    COLORREF color;
    const wchar_t* name;
};

static const BackgroundPreset kBackgroundPresets[] = {
    { RGB(245, 247, 251), L"默认" },
    { RGB(250, 247, 242), L"米白" },
    { RGB(234, 247, 242), L"薄荷" },
    { RGB(234, 242, 255), L"天蓝" },
    { RGB(253, 240, 244), L"樱粉" },
    { RGB(255, 244, 232), L"杏色" },
    { RGB(233, 238, 245), L"雾灰" },
    { RGB(243, 239, 255), L"淡紫" }
};
static const int kBackgroundPresetCount =
    (int)(sizeof(kBackgroundPresets) / sizeof(kBackgroundPresets[0]));

enum AceSettingsId {
    IDC_ACE_PRIORITY_LOW = 3001,
    IDC_ACE_PRIORITY_IDLE,
    IDC_ACE_ECO,
    IDC_ACE_IO,
    IDC_ACE_MEMORY,
    IDC_ACE_TRIM,
    IDC_ACE_AFFINITY,
    IDC_ACE_RESET,
    IDC_ACE_DONE
};

static const COLORREF kBg          = RGB(245, 247, 251);
static const COLORREF kCard        = RGB(255, 255, 255);
static const COLORREF kCardBorder  = RGB(229, 233, 241);
static const COLORREF kText        = RGB(23, 32, 51);
static const COLORREF kTextSoft    = RGB(92, 104, 126);
static const COLORREF kMuted       = RGB(126, 137, 156);
static const COLORREF kFaint       = RGB(154, 164, 181);
static const COLORREF kTrack       = RGB(237, 241, 247);
static const COLORREF kBlue        = RGB(37, 99, 235);
static const COLORREF kBlueHover   = RGB(29, 78, 216);
static const COLORREF kBluePale    = RGB(239, 246, 255);
static const COLORREF kBlueBorder  = RGB(219, 234, 254);
static const COLORREF kAmber       = RGB(245, 158, 11);
static const COLORREF kAmberPale   = RGB(255, 247, 237);
static const COLORREF kAmberBorder = RGB(253, 216, 170);
static const COLORREF kAmberText   = RGB(154, 52, 18);
static const COLORREF kRed         = RGB(220, 38, 38);
static const COLORREF kRedPale     = RGB(254, 242, 242);
static const COLORREF kRedBorder   = RGB(254, 202, 202);
static const COLORREF kGreen       = RGB(5, 150, 105);
static const COLORREF kGreenPale   = RGB(236, 253, 245);
static const COLORREF kGreenBorder = RGB(209, 250, 229);
static const COLORREF kViolet      = RGB(124, 58, 237);

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
struct GpuAggregate {
    wchar_t key[80];
    double value;
};

struct CleanupResult {
    BOOL standbyPurged;
    BOOL closeRequested;
    int trimmed;
    int closed;
    ULONGLONG availBefore;
    ULONGLONG availAfter;
};

struct AceProcessState {
    DWORD pid;
    HANDLE process;
    DWORD originalPriority;
    ULONG_PTR originalAffinity;
    bool affinitySaved;
    bool affinityApplied;
    ULONGLONG lastTrim;
};

struct AppEntry {
    DWORD pid;
    wchar_t path[512];
    wchar_t name[128];
    wchar_t title[200];
    ULONGLONG workingSet;
};

struct AppPriorityState {
    DWORD pid;
    HANDLE process;
    DWORD originalPriority;
};

enum ClipboardKind {
    CLIPBOARD_TEXT = 0,
    CLIPBOARD_IMAGE = 1,
    CLIPBOARD_OTHER = 2
};

struct ClipboardEntry {
    ClipboardKind kind;
    wchar_t* text;
    HBITMAP image;
    ULONGLONG hash;
};

struct Metrics {
    double cpu;
    double gpu;
    bool gpuValid;
    int memPercent;
    ULONGLONG memTotal;
    ULONGLONG memAvail;
    unsigned logicalCpus;
};

struct Layout {
    RECT card[4];
    RECT control;
    RECT trimButton;
    RECT toggle;
    RECT toggleCloseAuto;
    RECT toggleCloseManual;
    RECT slider;       // track
    RECT sliderHit;
    RECT adminChip;
    RECT compactButton;
    RECT minimalButton;
    RECT tencent;
    RECT aceToggle;
    RECT aceSettings;
    RECT appModeCard;
    RECT singleSwitch;
    RECT singleField;
    RECT multiSwitch;
    RECT multiField;
    RECT backgroundButton;
    RECT clipboardCard;
    RECT quickCard;
    RECT foreground;
    RECT info;
    RECT footer;
};

struct CompactLayout {
    RECT card;
    RECT trimButton;
    RECT minimalButton;
    RECT expandButton;
    RECT closeButton;
    RECT dragArea;
    RECT chip[4];
    RECT clipboardCard;
    RECT quickButton[3];
    RECT foreground;
};

struct MinimalLayout {
    RECT expandButton;
};

enum HoverId {
    HOVER_NONE = 0,
    HOVER_TRIM,
    HOVER_TOGGLE,
    HOVER_CLOSE_AUTO,
    HOVER_CLOSE_MANUAL,
    HOVER_SLIDER,
    HOVER_ADMIN,
    HOVER_ACE_TOGGLE,
    HOVER_ACE_SETTINGS,
    HOVER_COMPACT,
    HOVER_MINIMAL,
    HOVER_EXPAND,
    HOVER_COMPACT_CLOSE,
    HOVER_MINIMAL_EXPAND,
    HOVER_SINGLE_SWITCH,
    HOVER_MULTI_SWITCH,
    HOVER_SINGLE_FIELD,
    HOVER_MULTI_FIELD,
    HOVER_PICKER_CLOSE,
    HOVER_PICKER_DONE,
    HOVER_PICKER_CLEAR,
    HOVER_BACKGROUND,
    HOVER_BG_PANEL_CLOSE,
    HOVER_BG_IMAGE,
    HOVER_BG_RESET,
    HOVER_BG_NAME,
    HOVER_CLIPBOARD,
    HOVER_QUICK
};

static HWND g_hwnd = nullptr;
static HANDLE g_mutex = nullptr;
static bool g_closing = false;

static HFONT g_fTitle = nullptr;
static HFONT g_fSubtitle = nullptr;
static HFONT g_fChip = nullptr;
static HFONT g_fCardLabel = nullptr;
static HFONT g_fValue = nullptr;
static HFONT g_fUnit = nullptr;
static HFONT g_fDetail = nullptr;
static HFONT g_fSection = nullptr;
static HFONT g_fBody = nullptr;
static HFONT g_fButton = nullptr;
static HFONT g_fSmall = nullptr;
static HFONT g_fFooter = nullptr;
static HFONT g_fWarnTitle = nullptr;
static HFONT g_fWarnDetail = nullptr;
static HFONT g_fCompactValue = nullptr;
static HFONT g_fSettingsTitle = nullptr;
static HFONT g_fSettingsSection = nullptr;
static HFONT g_fSettingsBody = nullptr;
static HFONT g_fSettingsSmall = nullptr;

static void OpenAceSettings();
static LRESULT CALLBACK AceSettingsProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
static void AceSettingsChanged();
static void RebuildAppModeDisplay();
static bool IsProtectedProcess(const wchar_t* name);
static RECT GetPickerRect();
static int GetPickerRowHeight();
static int GetPickerHeaderHeight();
static int GetPickerFooterHeight();
static int GetPickerVisibleRows();
static void CloseAppPicker();
static void HideNameEditor();

static int g_dpi = 96;
static HDC g_memDC = nullptr;
static HBITMAP g_backBmp = nullptr;
static HBITMAP g_oldBmp = nullptr;
static int g_bufW = 0;
static int g_bufH = 0;

static bool g_elevated = false;
static bool g_auto = false;
static bool g_autoBlocked = false;
static bool g_closeManual = false;
static bool g_closeAuto = false;
static bool g_aceMode = false;
static int g_acePriority = 1;       // 0 = below normal, 1 = idle
static bool g_aceEcoQos = true;
static bool g_aceIoPriority = true;
static bool g_aceMemoryPriority = true;
static bool g_aceTrimWorkingSet = true;
static bool g_aceAffinity = false;  // experimental
static int g_aceDetected = 0;
static int g_aceLimited = 0;
static ULONGLONG g_aceNextScan = 0;
static bool g_aceForceApply = false;
static HWND g_aceSettingsWindow = nullptr;
static bool g_compact = false;
static bool g_minimal = false;
static int g_threshold = 85;

static int g_appMode = 0; // 0 = off, 1 = single app, 2 = multi app
static wchar_t g_singleAppPath[512] = {};
static wchar_t g_singleAppName[128] = {};
static wchar_t g_multiPaths[12][512] = {};
static wchar_t g_multiNames[12][128] = {};
static int g_multiCount = 0;
static wchar_t g_appModeText[256] = L"应用模式 关";
static wchar_t g_singleFieldText[160] = L"选择应用";
static wchar_t g_multiFieldText[200] = L"选择应用";
static ULONGLONG g_appModeNextScan = 0;
static bool g_appModeForceApply = false;
static int g_appSelectedProcesses = 0;
static int g_appLimitedProcesses = 0;

#ifndef SPECIAL_VERSION
static ClipboardEntry g_clipboardHistory[256] = {};
static int g_clipboardCount = 0;
static int g_clipboardScroll = 0;
static int g_clipboardHoverRow = -1;
static bool g_clipboardListening = false;
static DWORD g_lastClipboardSequence = 0;
static wchar_t g_foregroundText[256] = L"台前 —";
static wchar_t g_recentForeground[3][128] = {};
static int g_recentForegroundCount = 0;
static AppEntry g_quickApps[6] = {};
static int g_quickAppCount = 0;
static wchar_t g_quickText[128] = L"常用 —";
static ULONGLONG g_quickNextScan = 0;
static int g_quickHover = -1;
static HWND g_previewHwnd = nullptr;
static HBITMAP g_previewImage = nullptr;
static bool g_previewOwnsImage = false;
static int g_previewImageWidth = 0;
static int g_previewImageHeight = 0;
#endif

static int g_bgPreset = 0;
static bool g_bgUseImage = false;
static wchar_t g_bgImagePath[1024] = {};
static HBITMAP g_bgImageBitmap = nullptr;
static int g_bgBitmapWidth = 0;
static int g_bgBitmapHeight = 0;
static bool g_bgPanelOpen = false;

static bool g_fpsAttempted = false;
static bool g_fpsAvailable = false;
static bool g_fpsNeedsAdmin = false;
static TRACEHANDLE g_fpsSession = 0;
static TRACEHANDLE g_fpsTrace = 0;
static HANDLE g_fpsThread = nullptr;
static EVENT_TRACE_PROPERTIES* g_fpsProperties = nullptr;
static volatile LONG g_fpsFrameCount = 0;
static volatile LONG g_fpsTargetPid = 0;
static int g_fpsValue = 0;
static bool g_fpsValid = false;
static ULONGLONG g_fpsLastForegroundTick = 0;
static bool g_busy = false;
static bool g_warning = false;
static long long g_lastFreed = 0;
static int g_lastClosed = 0;
static bool g_lastCloseRequested = false;
static ULONGLONG g_lastCleanupTick = 0;

static Metrics g_metrics = {};
static wchar_t g_status1[160] = L"尚未整理";
static wchar_t g_status2[160] = L"点击按钮释放内存";
static wchar_t g_warnDetail[320] = L"";
static wchar_t g_cpuDetail[64] = L"";
static wchar_t g_memDetail[80] = L"";
static wchar_t g_gpuDetail[80] = L"最高引擎利用率";
static wchar_t g_footerOwn[64] = L"本应用内存 —";

static int g_hover = HOVER_NONE;
static bool g_trackingMouse = false;
static bool g_dragging = false;
static bool g_pressedTrim = false;
static bool g_pressedToggle = false;
static bool g_pressedCloseAuto = false;
static bool g_pressedCloseManual = false;
static bool g_pressedAdmin = false;
static bool g_pressedAceToggle = false;
static bool g_pressedAceSettings = false;
static bool g_pressedCompact = false;
static bool g_pressedMinimal = false;
static bool g_pressedSingleSwitch = false;
static bool g_pressedMultiSwitch = false;
static bool g_pressedSingleField = false;
static bool g_pressedMultiField = false;
static bool g_pressedBackground = false;
static bool g_pressedExpand = false;
static bool g_pressedCompactClose = false;
static bool g_pressedMinimalExpand = false;
static bool g_compactDragging = false;
static POINT g_compactDragStart = {};
static RECT g_compactDragWindow = {};

static ULONGLONG g_prevIdle = 0;
static ULONGLONG g_prevKernel = 0;
static ULONGLONG g_prevUser = 0;

static AceProcessState g_aceStates[16] = {};
static int g_aceStateCount = 0;

static AppEntry g_apps[32] = {};
static int g_appCount = 0;
static AppPriorityState g_appStates[64] = {};
static int g_appStateCount = 0;
static bool g_pickerOpen = false;
static int g_pickerMode = 0;
static int g_pickerScroll = 0;
static bool g_pickerChecked[32] = {};
static int g_pickerHoverRow = -1;

static PDH_HQUERY g_pdhQuery = nullptr;
static PDH_HCOUNTER g_pdhGpuCounter = nullptr;
static bool g_gpuQueryOpen = false;
static bool g_gpuAvailable = false;
static ULONGLONG g_nextGpuRetry = 0;

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
static int S(int value)
{
    return MulDiv(value, g_dpi, 96);
}

static RECT R(int x, int y, int w, int h)
{
    RECT r = { S(x), S(y), S(x + w), S(y + h) };
    return r;
}

static Layout GetLayout()
{
    Layout l = {};
    const int margin = 42;
    const int cardW = 172;
    const int cardH = 146;
    const int gap = 16;
    const int cardsY = 88;

    l.card[0] = R(margin, cardsY, cardW, cardH);
    l.card[1] = R(margin + cardW + gap, cardsY, cardW, cardH);
    l.card[2] = R(margin + (cardW + gap) * 2, cardsY, cardW, cardH);
    l.card[3] = R(margin + (cardW + gap) * 3, cardsY, cardW, cardH);

    l.control = R(42, 252, 736, 208);
    l.trimButton = R(520, 270, 238, 54);
    l.toggle = R(390, 266, 46, 24);
    l.toggleCloseAuto = R(390, 320, 46, 24);
    l.toggleCloseManual = R(700, 334, 46, 24);
    l.slider = R(142, 387, 200, 5);
    l.sliderHit = R(132, 369, 220, 42);
    l.adminChip = R(616, 28, 162, 30);
    l.compactButton = R(490, 28, 56, 30);
    l.minimalButton = R(552, 28, 56, 30);
    l.tencent = R(42, 476, 736, 80);
    l.aceToggle = R(390, 500, 46, 24);
    l.aceSettings = R(664, 496, 94, 32);
    l.appModeCard = R(42, 572, 736, 56);
    l.singleSwitch = R(62, 588, 42, 24);
    l.singleField = R(176, 584, 200, 32);
    l.multiSwitch = R(430, 588, 42, 24);
    l.multiField = R(540, 584, 218, 32);
#ifndef SPECIAL_VERSION
    l.backgroundButton = R(1070, 634, 68, 26);
#else
    l.backgroundButton = R(710, 634, 68, 26);
#endif
#ifndef SPECIAL_VERSION
    l.clipboardCard = R(856, 88, 282, 300);
    l.quickCard = R(856, 404, 282, 224);
    l.foreground = R(800, 22, 338, 42);
#endif
    l.info = R(42, 572, 736, 56);
    l.footer = R(42, 642, 736, 18);
    return l;
}

static CompactLayout GetCompactLayout()
{
    CompactLayout l = {};
#ifndef SPECIAL_VERSION
    l.card = R(8, 8, 544, 444);
    l.trimButton = R(20, 102, 120, 32);
    l.minimalButton = R(386, 14, 46, 22);
    l.expandButton = R(438, 14, 54, 22);
    l.closeButton = R(500, 14, 40, 22);
    l.dragArea = R(8, 8, 330, 36);
    l.chip[0] = R(20, 144, 250, 22);
    l.chip[1] = R(290, 144, 250, 22);
    l.chip[2] = R(20, 170, 250, 22);
    l.chip[3] = R(290, 170, 250, 22);
    l.clipboardCard = R(20, 236, 520, 150);
    l.foreground = R(20, 214, 520, 18);
    l.quickButton[0] = R(20, 394, 168, 34);
    l.quickButton[1] = R(196, 394, 168, 34);
    l.quickButton[2] = R(372, 394, 168, 34);
#else
    l.card = R(8, 8, 364, 214);
    l.trimButton = R(20, 102, 104, 32);
    l.minimalButton = R(242, 14, 40, 22);
    l.expandButton = R(286, 14, 44, 22);
    l.closeButton = R(336, 14, 24, 22);
    l.dragArea = R(8, 8, 228, 36);
    l.chip[0] = R(20, 144, 165, 22);
    l.chip[1] = R(195, 144, 165, 22);
    l.chip[2] = R(20, 170, 165, 22);
    l.chip[3] = R(195, 170, 165, 22);
#endif
    return l;
}

static MinimalLayout GetMinimalLayout()
{
    MinimalLayout l = {};
#ifndef SPECIAL_VERSION
    l.expandButton = R(1074, 3, 40, 26);
#else
    l.expandButton = R(814, 3, 40, 26);
#endif
    return l;
}

static int CurrentDesignWidth()
{
    if (g_minimal) return kMinimalW;
    return g_compact ? kCompactW : kDesignW;
}

static int CurrentDesignHeight()
{
    if (g_minimal) return kMinimalH;
    return g_compact ? kCompactH : kDesignH;
}

static bool PointIn(const RECT& r, int x, int y)
{
    return x >= r.left && x < r.right && y >= r.top && y < r.bottom;
}

static void FillColor(HDC dc, const RECT& r, COLORREF color)
{
    HBRUSH brush = CreateSolidBrush(color);
    FillRect(dc, &r, brush);
    DeleteObject(brush);
}

static void RoundFill(HDC dc, const RECT& r, int radius, COLORREF fill, COLORREF border)
{
    HBRUSH brush = CreateSolidBrush(fill);
    HPEN pen = CreatePen(PS_SOLID, S(1), border);
    HGDIOBJ oldBrush = SelectObject(dc, brush);
    HGDIOBJ oldPen = SelectObject(dc, pen);
    RoundRect(dc, r.left, r.top, r.right, r.bottom, S(radius) * 2, S(radius) * 2);
    SelectObject(dc, oldBrush);
    SelectObject(dc, oldPen);
    DeleteObject(brush);
    DeleteObject(pen);
}

static COLORREF SurfaceBorder()
{
    return kSpecialTheme ? RGB(126, 143, 166) : kCardBorder;
}

static void DrawHollowRound(HDC dc, const RECT& r, int radius, COLORREF border)
{
    HPEN pen = CreatePen(PS_SOLID, S(1), border);
    HGDIOBJ oldBrush = SelectObject(dc, GetStockObject(NULL_BRUSH));
    HGDIOBJ oldPen = SelectObject(dc, pen);
    RoundRect(dc, r.left, r.top, r.right, r.bottom, S(radius) * 2, S(radius) * 2);
    SelectObject(dc, oldBrush);
    SelectObject(dc, oldPen);
    DeleteObject(pen);
}

static void DrawSurface(HDC dc, const RECT& r, int radius, COLORREF fill, COLORREF border)
{
    if (kSpecialTheme) {
        if (border == kCardBorder) border = SurfaceBorder();
        DrawHollowRound(dc, r, radius, border);
    } else {
        RoundFill(dc, r, radius, fill, border);
    }
}

static void DrawString(HDC dc, const wchar_t* text, RECT r, HFONT font,
                       COLORREF color, UINT flags = DT_LEFT | DT_VCENTER | DT_SINGLELINE)
{
    HGDIOBJ oldFont = SelectObject(dc, font);
    SetBkMode(dc, TRANSPARENT);
    SetTextColor(dc, color);
    DrawTextW(dc, text, -1, &r, flags | DT_NOPREFIX);
    SelectObject(dc, oldFont);
}

static int MeasureString(HDC dc, HFONT font, const wchar_t* text)
{
    HGDIOBJ oldFont = SelectObject(dc, font);
    SIZE size = {};
    GetTextExtentPoint32W(dc, text, (int)wcslen(text), &size);
    SelectObject(dc, oldFont);
    return size.cx;
}

static void FormatBytes(ULONGLONG bytes, wchar_t* out, size_t cch)
{
    double gb = (double)bytes / (1024.0 * 1024.0 * 1024.0);
    if (gb >= 1.0) {
        StringCchPrintfW(out, cch, L"%.1f GB", gb);
    } else {
        double mb = (double)bytes / (1024.0 * 1024.0);
        StringCchPrintfW(out, cch, L"%.0f MB", mb);
    }
}

static void FormatDelta(long long bytes, wchar_t* out, size_t cch)
{
    ULONGLONG mag = (ULONGLONG)(bytes < 0 ? -bytes : bytes);
    FormatBytes(mag, out, cch);
}

static HFONT MakeFont(int pixels, int weight, const wchar_t* face = L"Microsoft YaHei UI")
{
    return CreateFontW(-S(pixels), 0, 0, 0, weight, FALSE, FALSE, FALSE,
                       DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                       CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face);
}

static void DestroyFonts()
{
    HFONT* fonts[] = {
        &g_fTitle, &g_fSubtitle, &g_fChip, &g_fCardLabel, &g_fValue, &g_fUnit,
        &g_fDetail, &g_fSection, &g_fBody, &g_fButton, &g_fSmall, &g_fFooter,
        &g_fWarnTitle, &g_fWarnDetail, &g_fCompactValue
    };
    for (HFONT* font : fonts) {
        if (*font) {
            DeleteObject(*font);
            *font = nullptr;
        }
    }
}

static void CreateFonts()
{
    DestroyFonts();
    g_fTitle      = MakeFont(20, 600);
    g_fSubtitle   = MakeFont(11, 400);
    g_fChip       = MakeFont(11, 500);
    g_fCardLabel  = MakeFont(12, 500);
    g_fValue      = MakeFont(37, 600, L"Segoe UI");
    g_fUnit       = MakeFont(15, 600, L"Segoe UI");
    g_fDetail     = MakeFont(11, 400);
    g_fSection    = MakeFont(14, 600);
    g_fBody       = MakeFont(12, 400);
    g_fButton     = MakeFont(14, 600);
    g_fSmall      = MakeFont(10, 400);
    g_fFooter     = MakeFont(10, 400);
    g_fWarnTitle  = MakeFont(13, 600);
    g_fWarnDetail = MakeFont(11, 400);
    g_fCompactValue = MakeFont(22, 600, L"Segoe UI");
}

static UINT GetWindowDpiSafe(HWND hwnd)
{
    typedef UINT(WINAPI* GetDpiForWindowFn)(HWND);
    static GetDpiForWindowFn fn = nullptr;
    static bool loaded = false;
    if (!loaded) {
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        fn = (GetDpiForWindowFn)GetProcAddress(user32, "GetDpiForWindow");
        loaded = true;
    }
    if (fn) {
        UINT dpi = fn(hwnd);
        if (dpi) return dpi;
    }
    HDC dc = GetDC(hwnd);
    UINT dpi = dc ? (UINT)GetDeviceCaps(dc, LOGPIXELSX) : 96;
    if (dc) ReleaseDC(hwnd, dc);
    return dpi ? dpi : 96;
}

// ---------------------------------------------------------------------------
// Settings / elevation
// ---------------------------------------------------------------------------
static DWORD ReadDwordSetting(HKEY key, const wchar_t* name, DWORD fallback)
{
    DWORD value = 0;
    DWORD size = sizeof(value);
    DWORD type = 0;
    if (RegQueryValueExW(key, name, nullptr, &type, (LPBYTE)&value, &size) == ERROR_SUCCESS &&
        type == REG_DWORD) {
        return value;
    }
    return fallback;
}

static void ReadStringSetting(HKEY key, const wchar_t* name, wchar_t* out, DWORD capacity)
{
    out[0] = 0;
    DWORD size = capacity * sizeof(wchar_t);
    DWORD type = 0;
    if (RegQueryValueExW(key, name, nullptr, &type, (LPBYTE)out, &size) != ERROR_SUCCESS ||
        (type != REG_SZ && type != REG_EXPAND_SZ)) {
        out[0] = 0;
    }
    out[capacity - 1] = 0;
}

static void LoadSettings()
{
    HKEY key = nullptr;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, kSettingsKey, 0, KEY_QUERY_VALUE, &key) == ERROR_SUCCESS) {
        DWORD value = 0;
        DWORD size = sizeof(value);
        DWORD type = 0;
        if (RegQueryValueExW(key, L"Threshold", nullptr, &type, (LPBYTE)&value, &size) == ERROR_SUCCESS &&
            type == REG_DWORD) {
            g_threshold = (int)value;
        }
        size = sizeof(value);
        type = 0;
        if (RegQueryValueExW(key, L"AutoClean", nullptr, &type, (LPBYTE)&value, &size) == ERROR_SUCCESS &&
            type == REG_DWORD) {
            g_auto = value != 0;
        }
        size = sizeof(value);
        type = 0;
        if (RegQueryValueExW(key, L"CloseManual", nullptr, &type, (LPBYTE)&value, &size) == ERROR_SUCCESS &&
            type == REG_DWORD) {
            g_closeManual = value != 0;
        }
        size = sizeof(value);
        type = 0;
        if (RegQueryValueExW(key, L"CloseAuto", nullptr, &type, (LPBYTE)&value, &size) == ERROR_SUCCESS &&
            type == REG_DWORD) {
            g_closeAuto = value != 0;
        }
        g_aceMode = ReadDwordSetting(key, L"AceMode", 0) != 0;
        g_acePriority = (int)ReadDwordSetting(key, L"AcePriority", 1);
        if (g_acePriority < 0) g_acePriority = 0;
        if (g_acePriority > 1) g_acePriority = 1;
        g_aceEcoQos = ReadDwordSetting(key, L"AceEcoQos", 1) != 0;
        g_aceIoPriority = ReadDwordSetting(key, L"AceIoPriority", 1) != 0;
        g_aceMemoryPriority = ReadDwordSetting(key, L"AceMemoryPriority", 1) != 0;
        g_aceTrimWorkingSet = ReadDwordSetting(key, L"AceTrimWorkingSet", 1) != 0;
        g_aceAffinity = ReadDwordSetting(key, L"AceAffinity", 0) != 0;

        g_appMode = (int)ReadDwordSetting(key, L"AppMode", 0);
        if (g_appMode < 0) g_appMode = 0;
        if (g_appMode > 2) g_appMode = 2;
        ReadStringSetting(key, L"SingleApp", g_singleAppPath, 512);
        wchar_t multiBuffer[8192] = {};
        ReadStringSetting(key, L"MultiApps", multiBuffer, 8192);
        g_bgPreset = (int)ReadDwordSetting(key, L"BackgroundPreset", 0);
        if (g_bgPreset < 0) g_bgPreset = 0;
        if (g_bgPreset >= kBackgroundPresetCount) g_bgPreset = kBackgroundPresetCount - 1;
        g_bgUseImage = ReadDwordSetting(key, L"BackgroundUseImage", 0) != 0;
        ReadStringSetting(key, L"BackgroundImage", g_bgImagePath, 1024);
        ReadStringSetting(key, L"DisplayName", g_displayName, 64);
        if (!g_displayName[0]) StringCchCopyW(g_displayName, 64, L"内存整理助手");
        g_multiCount = 0;
        wchar_t* cursor = multiBuffer;
        while (*cursor && g_multiCount < 12) {
            wchar_t* lineEnd = wcschr(cursor, L'\n');
            if (lineEnd) *lineEnd = 0;
            if (*cursor) {
                StringCchCopyW(g_multiPaths[g_multiCount], 512, cursor);
                ++g_multiCount;
            }
            if (!lineEnd) break;
            cursor = lineEnd + 1;
        }
        RegCloseKey(key);
    }
    if (g_threshold < kMinThreshold) g_threshold = kMinThreshold;
    if (g_threshold > kMaxThreshold) g_threshold = kMaxThreshold;
    RebuildAppModeDisplay();
}

static void SaveSettings()
{
    HKEY key = nullptr;
    DWORD disposition = 0;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, kSettingsKey, 0, nullptr, 0,
                        KEY_SET_VALUE, nullptr, &key, &disposition) == ERROR_SUCCESS) {
        DWORD threshold = (DWORD)g_threshold;
        DWORD autoClean = g_auto ? 1 : 0;
        DWORD closeManual = g_closeManual ? 1 : 0;
        DWORD closeAuto = g_closeAuto ? 1 : 0;
        DWORD aceMode = g_aceMode ? 1 : 0;
        DWORD acePriority = (DWORD)g_acePriority;
        DWORD aceEco = g_aceEcoQos ? 1 : 0;
        DWORD aceIo = g_aceIoPriority ? 1 : 0;
        DWORD aceMemory = g_aceMemoryPriority ? 1 : 0;
        DWORD aceTrim = g_aceTrimWorkingSet ? 1 : 0;
        DWORD aceAffinity = g_aceAffinity ? 1 : 0;
        DWORD appMode = (DWORD)g_appMode;
        DWORD backgroundPreset = (DWORD)g_bgPreset;
        DWORD backgroundUseImage = g_bgUseImage ? 1 : 0;
        wchar_t multiBuffer[8192] = {};
        for (int i = 0; i < g_multiCount; ++i) {
            if (i > 0) StringCchCatW(multiBuffer, 8192, L"\n");
            StringCchCatW(multiBuffer, 8192, g_multiPaths[i]);
        }
        RegSetValueExW(key, L"Threshold", 0, REG_DWORD, (const BYTE*)&threshold, sizeof(threshold));
        RegSetValueExW(key, L"AutoClean", 0, REG_DWORD, (const BYTE*)&autoClean, sizeof(autoClean));
        RegSetValueExW(key, L"CloseManual", 0, REG_DWORD, (const BYTE*)&closeManual, sizeof(closeManual));
        RegSetValueExW(key, L"CloseAuto", 0, REG_DWORD, (const BYTE*)&closeAuto, sizeof(closeAuto));
        RegSetValueExW(key, L"AceMode", 0, REG_DWORD, (const BYTE*)&aceMode, sizeof(aceMode));
        RegSetValueExW(key, L"AcePriority", 0, REG_DWORD, (const BYTE*)&acePriority, sizeof(acePriority));
        RegSetValueExW(key, L"AceEcoQos", 0, REG_DWORD, (const BYTE*)&aceEco, sizeof(aceEco));
        RegSetValueExW(key, L"AceIoPriority", 0, REG_DWORD, (const BYTE*)&aceIo, sizeof(aceIo));
        RegSetValueExW(key, L"AceMemoryPriority", 0, REG_DWORD, (const BYTE*)&aceMemory, sizeof(aceMemory));
        RegSetValueExW(key, L"AceTrimWorkingSet", 0, REG_DWORD, (const BYTE*)&aceTrim, sizeof(aceTrim));
        RegSetValueExW(key, L"AceAffinity", 0, REG_DWORD, (const BYTE*)&aceAffinity, sizeof(aceAffinity));
        RegSetValueExW(key, L"AppMode", 0, REG_DWORD, (const BYTE*)&appMode, sizeof(appMode));
        RegSetValueExW(key, L"SingleApp", 0, REG_SZ, (const BYTE*)g_singleAppPath,
                       (DWORD)((wcslen(g_singleAppPath) + 1) * sizeof(wchar_t)));
        RegSetValueExW(key, L"MultiApps", 0, REG_SZ, (const BYTE*)multiBuffer,
                       (DWORD)((wcslen(multiBuffer) + 1) * sizeof(wchar_t)));
        RegSetValueExW(key, L"BackgroundPreset", 0, REG_DWORD,
                       (const BYTE*)&backgroundPreset, sizeof(backgroundPreset));
        RegSetValueExW(key, L"BackgroundUseImage", 0, REG_DWORD,
                       (const BYTE*)&backgroundUseImage, sizeof(backgroundUseImage));
        RegSetValueExW(key, L"BackgroundImage", 0, REG_SZ, (const BYTE*)g_bgImagePath,
                       (DWORD)((wcslen(g_bgImagePath) + 1) * sizeof(wchar_t)));
        RegSetValueExW(key, L"DisplayName", 0, REG_SZ, (const BYTE*)g_displayName,
                       (DWORD)((wcslen(g_displayName) + 1) * sizeof(wchar_t)));
        RegCloseKey(key);
    }
}

static bool IsElevated()
{
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) return false;
    TOKEN_ELEVATION elevation = {};
    DWORD size = sizeof(elevation);
    bool elevated = false;
    if (GetTokenInformation(token, TokenElevation, &elevation, size, &size)) {
        elevated = elevation.TokenIsElevated != 0;
    }
    CloseHandle(token);
    return elevated;
}

static bool EnablePrivilege(const wchar_t* name)
{
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token)) {
        return false;
    }
    LUID luid = {};
    bool ok = false;
    if (LookupPrivilegeValueW(nullptr, name, &luid)) {
        TOKEN_PRIVILEGES privileges = {};
        privileges.PrivilegeCount = 1;
        privileges.Privileges[0].Luid = luid;
        privileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        if (AdjustTokenPrivileges(token, FALSE, &privileges, 0, nullptr, nullptr) &&
            GetLastError() == ERROR_SUCCESS) {
            ok = true;
        }
    }
    CloseHandle(token);
    return ok;
}

static bool PurgeStandbyList()
{
    if (!g_elevated) return false;
    if (!EnablePrivilege(L"SeProfileSingleProcessPrivilege")) return false;
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll) return false;
    typedef LONG(WINAPI* NtSetSystemInformationFn)(ULONG, PVOID, ULONG);
    NtSetSystemInformationFn fn =
        (NtSetSystemInformationFn)GetProcAddress(ntdll, "NtSetSystemInformation");
    if (!fn) return false;
    // SystemMemoryListInformation = 80, MemoryPurgeStandbyList = 4
    ULONG command = 4;
    LONG status = fn(80, &command, sizeof(command));
    return status >= 0;
}

static void RelaunchElevated()
{
    wchar_t path[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, path, MAX_PATH);
    SaveSettings();
    if (g_mutex) {
        CloseHandle(g_mutex);
        g_mutex = nullptr;
    }
    HINSTANCE result = ShellExecuteW(nullptr, L"runas", path, L"--replace --elevated", nullptr,
                                     SW_SHOWNORMAL);
    if ((INT_PTR)result > 32) {
        g_closing = true;
        DestroyWindow(g_hwnd);
        return;
    }
    g_mutex = CreateMutexW(nullptr, TRUE, kMutexName);
    MessageBoxW(g_hwnd,
                L"没有获得管理员权限，将继续以标准权限运行。\n"
                L"标准权限仍可整理当前用户程序的物理内存。",
                L"内存整理助手", MB_OK | MB_ICONINFORMATION);
}

// ---------------------------------------------------------------------------
// Metrics
// ---------------------------------------------------------------------------
static void SampleCpu()
{
    FILETIME idleFt = {}, kernelFt = {}, userFt = {};
    if (!GetSystemTimes(&idleFt, &kernelFt, &userFt)) return;

    ULARGE_INTEGER idle, kernel, user;
    idle.LowPart = idleFt.dwLowDateTime; idle.HighPart = idleFt.dwHighDateTime;
    kernel.LowPart = kernelFt.dwLowDateTime; kernel.HighPart = kernelFt.dwHighDateTime;
    user.LowPart = userFt.dwLowDateTime; user.HighPart = userFt.dwHighDateTime;

    ULONGLONG idleNow = idle.QuadPart;
    ULONGLONG kernelNow = kernel.QuadPart;
    ULONGLONG userNow = user.QuadPart;

    if (g_prevKernel || g_prevUser) {
        ULONGLONG idleDelta = idleNow - g_prevIdle;
        ULONGLONG totalDelta = (kernelNow - g_prevKernel) + (userNow - g_prevUser);
        if (totalDelta > 0) {
            double usage = (double)(totalDelta - idleDelta) * 100.0 / (double)totalDelta;
            if (usage < 0.0) usage = 0.0;
            if (usage > 100.0) usage = 100.0;
            g_metrics.cpu = usage;
        }
    }
    g_prevIdle = idleNow;
    g_prevKernel = kernelNow;
    g_prevUser = userNow;
}

static void SampleMemory()
{
    MEMORYSTATUSEX status = {};
    status.dwLength = sizeof(status);
    if (!GlobalMemoryStatusEx(&status)) return;

    g_metrics.memTotal = status.ullTotalPhys;
    g_metrics.memAvail = status.ullAvailPhys;
    ULONGLONG used = status.ullTotalPhys > status.ullAvailPhys
                         ? status.ullTotalPhys - status.ullAvailPhys
                         : 0;
    int pct = 0;
    if (status.ullTotalPhys > 0) {
        pct = (int)std::lround((double)used * 100.0 / (double)status.ullTotalPhys);
    }
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;
    g_metrics.memPercent = pct;

    double usedGB = (double)used / (1024.0 * 1024.0 * 1024.0);
    double totalGB = (double)status.ullTotalPhys / (1024.0 * 1024.0 * 1024.0);
    StringCchPrintfW(g_memDetail, 80, L"%.1f / %.1f GB", usedGB, totalGB);

    PROCESS_MEMORY_COUNTERS_EX counters = {};
    counters.cb = sizeof(counters);
    if (GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&counters,
                             sizeof(counters))) {
        StringCchPrintfW(g_footerOwn, 64, L"本应用内存 %.1f MB",
                         (double)counters.WorkingSetSize / (1024.0 * 1024.0));
    }
}

static void CloseGpuQuery()
{
    if (g_pdhQuery) {
        PdhCloseQuery(g_pdhQuery);
        g_pdhQuery = nullptr;
        g_pdhGpuCounter = nullptr;
    }
    g_gpuQueryOpen = false;
    g_gpuAvailable = false;
    g_metrics.gpuValid = false;
}

static void InitGpuQuery()
{
    if (g_gpuQueryOpen) return;
    PDH_HQUERY query = nullptr;
    PDH_HCOUNTER counter = nullptr;
    PDH_STATUS status = PdhOpenQueryW(nullptr, 0, &query);
    if (status != ERROR_SUCCESS) {
        g_nextGpuRetry = GetTickCount64() + 15000;
        return;
    }
    status = PdhAddEnglishCounterW(query, L"\\GPU Engine(*)\\Utilization Percentage", 0, &counter);
    if (status != ERROR_SUCCESS) {
        PdhCloseQuery(query);
        g_nextGpuRetry = GetTickCount64() + 15000;
        return;
    }
    status = PdhCollectQueryData(query);
    if (status != ERROR_SUCCESS) {
        PdhCloseQuery(query);
        g_nextGpuRetry = GetTickCount64() + 15000;
        return;
    }
    g_pdhQuery = query;
    g_pdhGpuCounter = counter;
    g_gpuQueryOpen = true;
    g_gpuAvailable = true;
    StringCchCopyW(g_gpuDetail, 80, L"最高引擎利用率");
}

static void SampleGpu()
{
    if (!g_gpuAvailable) {
        if (GetTickCount64() >= g_nextGpuRetry) InitGpuQuery();
        if (!g_gpuAvailable) {
            g_metrics.gpuValid = false;
            StringCchCopyW(g_gpuDetail, 80, L"GPU 计数器不可用");
            return;
        }
    }

    PDH_STATUS status = PdhCollectQueryData(g_pdhQuery);
    if (status != ERROR_SUCCESS) {
        g_metrics.gpuValid = false;
        return;
    }

    DWORD bufferSize = 0;
    DWORD itemCount = 0;
    status = PdhGetFormattedCounterArrayW(g_pdhGpuCounter, PDH_FMT_DOUBLE,
                                          &bufferSize, &itemCount, nullptr);
    if (status != PDH_MORE_DATA && status != ERROR_SUCCESS) {
        g_metrics.gpuValid = false;
        return;
    }
    if (bufferSize == 0) {
        g_metrics.gpu = 0.0;
        g_metrics.gpuValid = true;
        return;
    }

    BYTE* buffer = (BYTE*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, bufferSize);
    if (!buffer) return;
    status = PdhGetFormattedCounterArrayW(g_pdhGpuCounter, PDH_FMT_DOUBLE,
                                          &bufferSize, &itemCount,
                                          (PDH_FMT_COUNTERVALUE_ITEM_W*)buffer);
    if (status != ERROR_SUCCESS) {
        HeapFree(GetProcessHeap(), 0, buffer);
        g_metrics.gpuValid = false;
        return;
    }

    static GpuAggregate aggregates[1024];
    int aggregateCount = 0;
    PDH_FMT_COUNTERVALUE_ITEM_W* items = (PDH_FMT_COUNTERVALUE_ITEM_W*)buffer;
    for (DWORD i = 0; i < itemCount && i < 4096; ++i) {
        PDH_FMT_COUNTERVALUE* value = &items[i].FmtValue;
        if (value->CStatus != PDH_CSTATUS_VALID_DATA &&
            value->CStatus != PDH_CSTATUS_NEW_DATA) {
            continue;
        }
        const wchar_t* instance = items[i].szName;
        if (!instance) continue;
        const wchar_t* key = wcsstr(instance, L"_luid_");
        if (!key) continue;
        size_t keyLen = wcslen(key);
        if (keyLen >= 80) continue;

        int found = -1;
        for (int j = 0; j < aggregateCount; ++j) {
            if (wcscmp(aggregates[j].key, key) == 0) {
                found = j;
                break;
            }
        }
        if (found < 0) {
            if (aggregateCount >= 1024) continue;
            found = aggregateCount++;
            StringCchCopyW(aggregates[found].key, 80, key);
            aggregates[found].value = 0.0;
        }
        aggregates[found].value += value->doubleValue;
    }

    double maxUsage = 0.0;
    for (int i = 0; i < aggregateCount; ++i) {
        if (aggregates[i].value > maxUsage) maxUsage = aggregates[i].value;
    }
    if (maxUsage < 0.0) maxUsage = 0.0;
    if (maxUsage > 100.0) maxUsage = 100.0;
    g_metrics.gpu = maxUsage;
    g_metrics.gpuValid = true;
    StringCchCopyW(g_gpuDetail, 80, L"最高引擎利用率");

    HeapFree(GetProcessHeap(), 0, buffer);
}

static void InitMetrics()
{
    SYSTEM_INFO info = {};
    GetSystemInfo(&info);
    g_metrics.logicalCpus = GetActiveProcessorCount(ALL_PROCESSOR_GROUPS);
    if (!g_metrics.logicalCpus) g_metrics.logicalCpus = info.dwNumberOfProcessors;
    StringCchPrintfW(g_cpuDetail, 64, L"%u 个逻辑处理器", g_metrics.logicalCpus);

    FILETIME idleFt = {}, kernelFt = {}, userFt = {};
    if (GetSystemTimes(&idleFt, &kernelFt, &userFt)) {
        ULARGE_INTEGER idle, kernel, user;
        idle.LowPart = idleFt.dwLowDateTime; idle.HighPart = idleFt.dwHighDateTime;
        kernel.LowPart = kernelFt.dwLowDateTime; kernel.HighPart = kernelFt.dwHighDateTime;
        user.LowPart = userFt.dwLowDateTime; user.HighPart = userFt.dwHighDateTime;
        g_prevIdle = idle.QuadPart;
        g_prevKernel = kernel.QuadPart;
        g_prevUser = user.QuadPart;
    }
    SampleMemory();
    SampleGpu();
}

// ---------------------------------------------------------------------------
// Foreground FPS (ETW: DXGI / D3D9 present events)
// ---------------------------------------------------------------------------
static void WINAPI FpsEventCallback(PEVENT_RECORD event)
{
    if (!event) return;
    DWORD target = (DWORD)InterlockedCompareExchange((volatile LONG*)&g_fpsTargetPid, 0, 0);
    if (!target || event->EventHeader.ProcessId != target) return;

    bool present = false;
    if (IsEqualGUID(event->EventHeader.ProviderId, kDxgiProvider) &&
        event->EventHeader.EventDescriptor.Id == 42) {
        present = true;
    } else if (IsEqualGUID(event->EventHeader.ProviderId, kD3d9Provider) &&
               event->EventHeader.EventDescriptor.Id == 1) {
        present = true;
    }
    if (present) InterlockedIncrement(&g_fpsFrameCount);
}

static DWORD WINAPI FpsConsumerThread(LPVOID)
{
    EVENT_TRACE_LOGFILEW log = {};
    log.LoggerName = (LPWSTR)kFpsSessionName;
    log.ProcessTraceMode = PROCESS_TRACE_MODE_REAL_TIME | PROCESS_TRACE_MODE_EVENT_RECORD;
    log.EventRecordCallback = FpsEventCallback;

    g_fpsTrace = OpenTraceW(&log);
    if (g_fpsTrace == INVALID_PROCESSTRACE_HANDLE) {
        g_fpsAvailable = false;
        if (g_fpsSession && g_fpsProperties) {
            ControlTraceW(g_fpsSession, kFpsSessionName, g_fpsProperties, EVENT_TRACE_CONTROL_STOP);
        }
        return 1;
    }
    g_fpsAvailable = true;
    ProcessTrace(&g_fpsTrace, 1, nullptr, nullptr);
    CloseTrace(g_fpsTrace);
    g_fpsTrace = 0;
    g_fpsAvailable = false;
    return 0;
}

static void StopFpsTrace()
{
    if (g_fpsSession && g_fpsProperties) {
        ControlTraceW(g_fpsSession, kFpsSessionName, g_fpsProperties, EVENT_TRACE_CONTROL_STOP);
    }
    if (g_fpsThread) {
        WaitForSingleObject(g_fpsThread, 2000);
        CloseHandle(g_fpsThread);
        g_fpsThread = nullptr;
    }
    if (g_fpsTrace) {
        CloseTrace(g_fpsTrace);
        g_fpsTrace = 0;
    }
    if (g_fpsProperties) {
        free(g_fpsProperties);
        g_fpsProperties = nullptr;
    }
    g_fpsSession = 0;
    g_fpsAvailable = false;
    g_fpsValid = false;
}

static void StartFpsTrace()
{
    if (g_fpsAttempted) return;
    g_fpsAttempted = true;

    if (!g_elevated) {
        g_fpsNeedsAdmin = true;
        return;
    }

    int nameBytes = (int)((wcslen(kFpsSessionName) + 1) * sizeof(wchar_t));
    int size = sizeof(EVENT_TRACE_PROPERTIES) + nameBytes;
    g_fpsProperties = (EVENT_TRACE_PROPERTIES*)calloc(1, size);
    if (!g_fpsProperties) return;

    auto initialize = [&]() {
        ZeroMemory(g_fpsProperties, size);
        g_fpsProperties->Wnode.BufferSize = size;
        g_fpsProperties->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
        g_fpsProperties->Wnode.ClientContext = 1;
        g_fpsProperties->LogFileMode = EVENT_TRACE_REAL_TIME_MODE;
        g_fpsProperties->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
        g_fpsProperties->BufferSize = 64;
        g_fpsProperties->MinimumBuffers = 4;
        g_fpsProperties->MaximumBuffers = 16;
        StringCchCopyW((wchar_t*)((BYTE*)g_fpsProperties + sizeof(EVENT_TRACE_PROPERTIES)),
                       32, kFpsSessionName);
    };

    initialize();
    ULONG status = StartTraceW(&g_fpsSession, kFpsSessionName, g_fpsProperties);
    if (status == ERROR_ALREADY_EXISTS) {
        ControlTraceW(0, kFpsSessionName, g_fpsProperties, EVENT_TRACE_CONTROL_STOP);
        initialize();
        status = StartTraceW(&g_fpsSession, kFpsSessionName, g_fpsProperties);
    }
    if (status != ERROR_SUCCESS) {
        if (status == ERROR_ACCESS_DENIED) g_fpsNeedsAdmin = true;
        free(g_fpsProperties);
        g_fpsProperties = nullptr;
        g_fpsSession = 0;
        return;
    }

    ULONG dxgi = EnableTraceEx2(g_fpsSession, &kDxgiProvider, EVENT_CONTROL_CODE_ENABLE_PROVIDER,
                                TRACE_LEVEL_INFORMATION, 0x8000000000000002, 0, 0, nullptr);
    ULONG d3d9 = EnableTraceEx2(g_fpsSession, &kD3d9Provider, EVENT_CONTROL_CODE_ENABLE_PROVIDER,
                                TRACE_LEVEL_INFORMATION, 0x8000000000000002, 0, 0, nullptr);
    if (dxgi != ERROR_SUCCESS && d3d9 != ERROR_SUCCESS) {
        ControlTraceW(g_fpsSession, kFpsSessionName, g_fpsProperties, EVENT_TRACE_CONTROL_STOP);
        free(g_fpsProperties);
        g_fpsProperties = nullptr;
        g_fpsSession = 0;
        return;
    }

    g_fpsThread = CreateThread(nullptr, 0, FpsConsumerThread, nullptr, 0, nullptr);
    if (!g_fpsThread) {
        StopFpsTrace();
    }
}

static bool GetProcessBaseName(DWORD pid, wchar_t* name, size_t capacity)
{
    HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!process) return false;
    wchar_t path[1024] = {};
    DWORD size = 1024;
    bool ok = QueryFullProcessImageNameW(process, 0, path, &size) != FALSE;
    CloseHandle(process);
    if (!ok) return false;
    const wchar_t* base = wcsrchr(path, L'\\');
    base = base ? base + 1 : path;
    StringCchCopyW(name, capacity, base);
    return true;
}

static bool IsShellForeground(DWORD pid)
{
    wchar_t name[128] = {};
    if (!GetProcessBaseName(pid, name, 128)) return false;
    return _wcsicmp(name, L"explorer.exe") == 0 ||
           _wcsicmp(name, L"ShellExperienceHost.exe") == 0 ||
           _wcsicmp(name, L"StartMenuExperienceHost.exe") == 0 ||
           _wcsicmp(name, L"SearchApp.exe") == 0 ||
           _wcsicmp(name, L"SearchHost.exe") == 0 ||
           _wcsicmp(name, L"LockApp.exe") == 0;
}

static void UpdateFps()
{
    if (!g_fpsAttempted) StartFpsTrace();
    if (!g_fpsAvailable) {
        g_fpsValid = false;
        return;
    }

    ULONGLONG now = GetTickCount64();
    HWND foreground = GetForegroundWindow();
    DWORD foregroundPid = 0;
    if (foreground) GetWindowThreadProcessId(foreground, &foregroundPid);

    if (foregroundPid == GetCurrentProcessId()) {
        // Interaction with the monitor itself must not lose the game target.
    } else if (foregroundPid != 0 && !IsShellForeground(foregroundPid)) {
        DWORD target = (DWORD)InterlockedCompareExchange((volatile LONG*)&g_fpsTargetPid, 0, 0);
        if (foregroundPid != target) {
            InterlockedExchange((volatile LONG*)&g_fpsTargetPid, (LONG)foregroundPid);
            InterlockedExchange(&g_fpsFrameCount, 0);
        }
        g_fpsLastForegroundTick = now;
    } else if (now - g_fpsLastForegroundTick > 5000) {
        InterlockedExchange((volatile LONG*)&g_fpsTargetPid, 0);
        InterlockedExchange(&g_fpsFrameCount, 0);
    }

    DWORD target = (DWORD)InterlockedCompareExchange((volatile LONG*)&g_fpsTargetPid, 0, 0);
    if (target) {
        HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, target);
        if (!process) {
            InterlockedExchange((volatile LONG*)&g_fpsTargetPid, 0);
            target = 0;
        } else {
            CloseHandle(process);
        }
    }

    int frames = (int)InterlockedExchange(&g_fpsFrameCount, 0);
    g_fpsValue = frames < 0 ? 0 : frames;
    g_fpsValid = target != 0;
}

// ---------------------------------------------------------------------------
// Per-application focus modes
// ---------------------------------------------------------------------------
static void AppNameFromPath(const wchar_t* path, wchar_t* out, size_t capacity)
{
    out[0] = 0;
    if (!path || !path[0]) return;
    const wchar_t* base = wcsrchr(path, L'\\');
    base = base ? base + 1 : path;
    StringCchCopyW(out, capacity, base);
    wchar_t* dot = wcsrchr(out, L'.');
    if (dot && dot != out) *dot = 0;
}

static bool SamePath(const wchar_t* a, const wchar_t* b)
{
    return a && b && _wcsicmp(a, b) == 0;
}

static bool IsSelectedAppPath(const wchar_t* path)
{
    if (g_appMode == 1 && SamePath(path, g_singleAppPath)) return true;
    if (g_appMode == 2) {
        for (int i = 0; i < g_multiCount; ++i) {
            if (SamePath(path, g_multiPaths[i])) return true;
        }
    }
    return false;
}

static bool IsVisibleAppPath(const wchar_t* path)
{
    for (int i = 0; i < g_appCount; ++i) {
        if (SamePath(path, g_apps[i].path)) return true;
    }
    return false;
}

static bool IsMultiPathSelected(const wchar_t* path)
{
    for (int i = 0; i < g_multiCount; ++i) {
        if (SamePath(path, g_multiPaths[i])) return true;
    }
    return false;
}

static void UpdateAppModeText()
{
    if (g_appMode == 0) {
        StringCchCopyW(g_appModeText, 256, L"应用模式 关");
        return;
    }

    if (g_appMode == 1) {
        if (g_singleAppName[0]) {
            StringCchPrintfW(g_appModeText, 256, L"单应用 · %ls", g_singleAppName);
        } else {
            StringCchCopyW(g_appModeText, 256, L"单应用 · 未选择");
        }
        return;
    }

    if (g_multiCount == 0) {
        StringCchCopyW(g_appModeText, 256, L"多开 · 未选择");
        return;
    }

    // For more than two apps, show the two with the largest visible working set.
    int first = 0;
    int second = -1;
    ULONGLONG firstBytes = 0;
    ULONGLONG secondBytes = 0;
    for (int i = 0; i < g_multiCount; ++i) {
        ULONGLONG bytes = 0;
        for (int a = 0; a < g_appCount; ++a) {
            if (SamePath(g_apps[a].path, g_multiPaths[i])) {
                bytes += g_apps[a].workingSet;
            }
        }
        if (i == 0) {
            first = 0;
            firstBytes = bytes;
            continue;
        }
        if (bytes > firstBytes) {
            second = first;
            secondBytes = firstBytes;
            first = i;
            firstBytes = bytes;
        } else if (second < 0 || bytes > secondBytes) {
            second = i;
            secondBytes = bytes;
        }
    }

    if (g_multiCount == 1 || second < 0) {
        StringCchPrintfW(g_appModeText, 256, L"多开 · %ls", g_multiNames[first]);
    } else {
        StringCchPrintfW(g_appModeText, 256, L"多开 · %ls/%ls",
                         g_multiNames[first], g_multiNames[second]);
    }
}

static void RebuildAppModeDisplay()
{
    AppNameFromPath(g_singleAppPath, g_singleAppName, 128);
    if (g_singleAppName[0]) {
        StringCchCopyW(g_singleFieldText, 160, g_singleAppName);
    } else {
        StringCchCopyW(g_singleFieldText, 160, L"选择应用");
    }

    for (int i = 0; i < g_multiCount; ++i) {
        AppNameFromPath(g_multiPaths[i], g_multiNames[i], 128);
    }

    if (g_multiCount == 0) {
        StringCchCopyW(g_multiFieldText, 200, L"选择应用");
    } else if (g_multiCount == 1) {
        StringCchCopyW(g_multiFieldText, 200, g_multiNames[0]);
    } else {
        StringCchPrintfW(g_multiFieldText, 200, g_multiCount > 2 ? L"%ls/%ls +%d"
                                                                 : L"%ls/%ls",
                         g_multiNames[0], g_multiNames[1],
                         g_multiCount - 2);
    }
    UpdateAppModeText();
}

struct AppEnumContext {
    AppEntry* apps;
    int count;
    int capacity;
    DWORD session;
};

static bool IsShellAppName(const wchar_t* name)
{
    return _wcsicmp(name, L"explorer.exe") == 0 ||
           _wcsicmp(name, L"dwm.exe") == 0 ||
           _wcsicmp(name, L"ShellExperienceHost.exe") == 0 ||
           _wcsicmp(name, L"StartMenuExperienceHost.exe") == 0 ||
           _wcsicmp(name, L"SearchApp.exe") == 0 ||
           _wcsicmp(name, L"SearchHost.exe") == 0 ||
           _wcsicmp(name, L"LockApp.exe") == 0 ||
           _wcsicmp(name, L"TextInputHost.exe") == 0 ||
           _wcsicmp(name, L"InputApp.exe") == 0 ||
           _wcsicmp(name, L"ApplicationFrameHost.exe") == 0;
}

static BOOL CALLBACK EnumAppWindowsProc(HWND hwnd, LPARAM parameter)
{
    AppEnumContext* context = (AppEnumContext*)parameter;
    if (context->count >= context->capacity) return FALSE;
    if (hwnd == g_hwnd || !IsWindowVisible(hwnd)) return TRUE;
    LONG exStyle = GetWindowLongW(hwnd, GWL_EXSTYLE);
    if (exStyle & WS_EX_TOOLWINDOW) return TRUE;
    if (GetWindow(hwnd, GW_OWNER)) return TRUE;
    if (GetWindowTextLengthW(hwnd) == 0) return TRUE;

    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (!pid || pid == GetCurrentProcessId()) return TRUE;

    DWORD session = 0;
    if (!ProcessIdToSessionId(pid, &session) || session != context->session) {
        return TRUE;
    }

    HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!process) return TRUE;
    wchar_t path[1024] = {};
    DWORD size = 1024;
    if (!QueryFullProcessImageNameW(process, 0, path, &size)) {
        CloseHandle(process);
        return TRUE;
    }

    const wchar_t* base = wcsrchr(path, L'\\');
    base = base ? base + 1 : path;
    if (IsShellAppName(base)) {
        CloseHandle(process);
        return TRUE;
    }

    for (int i = 0; i < context->count; ++i) {
        if (SamePath(context->apps[i].path, path)) {
            CloseHandle(process);
            return TRUE;
        }
    }

    AppEntry& entry = context->apps[context->count];
    ZeroMemory(&entry, sizeof(entry));
    entry.pid = pid;
    StringCchCopyW(entry.path, 512, path);
    AppNameFromPath(path, entry.name, 128);
    GetWindowTextW(hwnd, entry.title, 200);
    PROCESS_MEMORY_COUNTERS_EX counters = {};
    counters.cb = sizeof(counters);
    if (GetProcessMemoryInfo(process, (PROCESS_MEMORY_COUNTERS*)&counters, sizeof(counters))) {
        entry.workingSet = (ULONGLONG)counters.WorkingSetSize;
    }
    CloseHandle(process);
    ++context->count;
    return TRUE;
}

static void EnumerateVisibleApps()
{
    DWORD currentSession = 0;
    ProcessIdToSessionId(GetCurrentProcessId(), &currentSession);
    g_appCount = 0;
    AppEnumContext context = { g_apps, 0, (int)(sizeof(g_apps) / sizeof(g_apps[0])),
                               currentSession };
    EnumWindows(EnumAppWindowsProc, (LPARAM)&context);
    g_appCount = context.count;

    // Keep the dropdown stable and readable.
    for (int i = 1; i < g_appCount; ++i) {
        AppEntry key = g_apps[i];
        int j = i - 1;
        while (j >= 0 && _wcsicmp(g_apps[j].name, key.name) > 0) {
            g_apps[j + 1] = g_apps[j];
            --j;
        }
        g_apps[j + 1] = key;
    }
}

static void RestoreAppPriorities()
{
    for (int i = 0; i < g_appStateCount; ++i) {
        AppPriorityState& state = g_appStates[i];
        if (state.process) {
            if (WaitForSingleObject(state.process, 0) == WAIT_TIMEOUT &&
                state.originalPriority) {
                SetPriorityClass(state.process, state.originalPriority);
                SetProcessPriorityBoost(state.process, FALSE);
            }
            CloseHandle(state.process);
        }
    }
    g_appStateCount = 0;
    g_appSelectedProcesses = 0;
    g_appLimitedProcesses = 0;
}

static int FindAppState(DWORD pid)
{
    for (int i = 0; i < g_appStateCount; ++i) {
        if (g_appStates[i].pid == pid) return i;
    }
    return -1;
}

static void RefreshAppMode()
{
    if (g_appMode == 0) {
        RestoreAppPriorities();
        UpdateAppModeText();
        return;
    }

    EnumerateVisibleApps();

    bool seen[64] = {};
    int selectedProcesses = 0;
    int limitedProcesses = 0;
    DWORD currentSession = 0;
    ProcessIdToSessionId(GetCurrentProcessId(), &currentSession);
    DWORD self = GetCurrentProcessId();

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) return;

    PROCESSENTRY32W entry = {};
    entry.dwSize = sizeof(entry);
    if (Process32FirstW(snapshot, &entry)) {
        do {
            DWORD pid = entry.th32ProcessID;
            if (pid == 0 || pid == 4 || pid == self) continue;
            if (IsProtectedProcess(entry.szExeFile)) continue;

            DWORD session = 0;
            if (!ProcessIdToSessionId(pid, &session) || session != currentSession) continue;

            HANDLE query = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
            if (!query) continue;
            wchar_t path[1024] = {};
            DWORD pathSize = 1024;
            bool pathOk = QueryFullProcessImageNameW(query, 0, path, &pathSize) != FALSE;
            CloseHandle(query);
            if (!pathOk) continue;

            bool selected = IsSelectedAppPath(path);
            bool otherApp = !selected && IsVisibleAppPath(path);
            if (!selected && !otherApp) continue;

            int index = FindAppState(pid);
            if (index < 0) {
                if (g_appStateCount >= (int)(sizeof(g_appStates) / sizeof(g_appStates[0]))) {
                    continue;
                }
                HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION |
                                                 PROCESS_SET_INFORMATION |
                                                 SYNCHRONIZE,
                                             FALSE, pid);
                if (!process) continue;
                index = g_appStateCount++;
                AppPriorityState& state = g_appStates[index];
                state = {};
                state.pid = pid;
                state.process = process;
                state.originalPriority = GetPriorityClass(process);
                if (!state.originalPriority) state.originalPriority = NORMAL_PRIORITY_CLASS;
            }

            AppPriorityState& state = g_appStates[index];
            if (!state.process || WaitForSingleObject(state.process, 0) != WAIT_TIMEOUT) {
                continue;
            }
            seen[index] = true;
            DWORD priority = selected
                                 ? (g_appMode == 1 ? HIGH_PRIORITY_CLASS : ABOVE_NORMAL_PRIORITY_CLASS)
                                 : (g_appMode == 1 ? IDLE_PRIORITY_CLASS : BELOW_NORMAL_PRIORITY_CLASS);
            if (SetPriorityClass(state.process, priority)) {
                SetProcessPriorityBoost(state.process, selected ? FALSE : TRUE);
                if (selected) ++selectedProcesses;
                else ++limitedProcesses;
            }
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);

    // Restore processes that are no longer part of the current app set.
    int writeIndex = 0;
    for (int i = 0; i < g_appStateCount; ++i) {
        AppPriorityState state = g_appStates[i];
        if (seen[i] && state.process) {
            g_appStates[writeIndex++] = state;
            continue;
        }
        if (state.process) {
            if (WaitForSingleObject(state.process, 0) == WAIT_TIMEOUT &&
                state.originalPriority) {
                SetPriorityClass(state.process, state.originalPriority);
                SetProcessPriorityBoost(state.process, FALSE);
            }
            CloseHandle(state.process);
        }
    }
    for (int i = writeIndex; i < g_appStateCount; ++i) {
        g_appStates[i] = {};
    }
    g_appStateCount = writeIndex;

    if (selectedProcesses == 0) {
        RestoreAppPriorities();
    } else {
        g_appSelectedProcesses = selectedProcesses;
        g_appLimitedProcesses = limitedProcesses;
    }
    UpdateAppModeText();
}

static void UpdateAppMode()
{
    if (g_appMode == 0) {
        if (g_appStateCount) RestoreAppPriorities();
        UpdateAppModeText();
        return;
    }
    if (g_pickerOpen) {
        UpdateAppModeText();
        return;
    }
    ULONGLONG now = GetTickCount64();
    if (!g_appModeForceApply && now < g_appModeNextScan) {
        UpdateAppModeText();
        return;
    }
    g_appModeForceApply = false;
    g_appModeNextScan = now + 2000;
    RefreshAppMode();
}

#ifndef SPECIAL_VERSION
// ---------------------------------------------------------------------------
// Clipboard history and foreground/common apps
// ---------------------------------------------------------------------------
static ULONGLONG HashBytes(const void* data, size_t size, ULONGLONG seed)
{
    const unsigned char* bytes = (const unsigned char*)data;
    ULONGLONG hash = seed ? seed : 1469598103934665603ULL;
    for (size_t i = 0; i < size; ++i) {
        hash ^= bytes[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

static ULONGLONG HashTextValue(const wchar_t* text)
{
    if (!text) return 0;
    return HashBytes(text, wcslen(text) * sizeof(wchar_t), 1469598103934665603ULL);
}

static ULONGLONG HashBitmapValue(HBITMAP bitmap)
{
    if (!bitmap) return 0;
    BITMAP info = {};
    if (!GetObjectW(bitmap, sizeof(info), &info) || info.bmWidth <= 0 || info.bmHeight <= 0) {
        return 0;
    }
    if ((long long)info.bmWidth * info.bmHeight > 64000000LL) return 0;

    BITMAPINFO dib = {};
    dib.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    dib.bmiHeader.biWidth = info.bmWidth;
    dib.bmiHeader.biHeight = -info.bmHeight;
    dib.bmiHeader.biPlanes = 1;
    dib.bmiHeader.biBitCount = 32;
    dib.bmiHeader.biCompression = BI_RGB;
    size_t bytes = (size_t)info.bmWidth * info.bmHeight * 4;
    unsigned char* pixels = new unsigned char[bytes];
    HDC screen = GetDC(nullptr);
    int lines = GetDIBits(screen, bitmap, 0, info.bmHeight, pixels, &dib, DIB_RGB_COLORS);
    ReleaseDC(nullptr, screen);
    ULONGLONG hash = 0;
    if (lines == info.bmHeight) {
        hash = HashBytes(pixels, bytes, 1469598103934665603ULL);
        hash = HashBytes(&info.bmWidth, sizeof(info.bmWidth), hash);
        hash = HashBytes(&info.bmHeight, sizeof(info.bmHeight), hash);
    }
    delete[] pixels;
    return hash;
}

static void FreeClipboardEntry(ClipboardEntry& entry)
{
    if (entry.text) {
        delete[] entry.text;
        entry.text = nullptr;
    }
    if (entry.image) {
        DeleteObject(entry.image);
        entry.image = nullptr;
    }
    entry.kind = CLIPBOARD_TEXT;
    entry.hash = 0;
}

static void FreeClipboardHistory()
{
    for (int i = 0; i < g_clipboardCount; ++i) FreeClipboardEntry(g_clipboardHistory[i]);
    g_clipboardCount = 0;
    g_clipboardScroll = 0;
    g_clipboardHoverRow = -1;
}

static bool ClipboardHistoryContains(ClipboardKind kind, ULONGLONG hash)
{
    for (int i = 0; i < g_clipboardCount; ++i) {
        if (g_clipboardHistory[i].kind == kind && g_clipboardHistory[i].hash == hash) {
            return true;
        }
    }
    return false;
}

static void AddClipboardEntry(ClipboardKind kind, wchar_t* text, HBITMAP image, ULONGLONG hash)
{
    if (g_clipboardCount >= (int)(sizeof(g_clipboardHistory) / sizeof(g_clipboardHistory[0]))) {
        FreeClipboardEntry(g_clipboardHistory[0]);
        for (int i = 1; i < g_clipboardCount; ++i) {
            g_clipboardHistory[i - 1] = g_clipboardHistory[i];
        }
        --g_clipboardCount;
        g_clipboardHistory[g_clipboardCount] = {};
    }
    ClipboardEntry& entry = g_clipboardHistory[g_clipboardCount++];
    entry.kind = kind;
    entry.text = text;
    entry.image = image;
    entry.hash = hash;
    g_clipboardScroll = 0;
    if (g_hwnd) InvalidateRect(g_hwnd, nullptr, FALSE);
}

static HBITMAP ClipboardBitmap()
{
    if (IsClipboardFormatAvailable(CF_DIB)) {
        HANDLE handle = GetClipboardData(CF_DIB);
        BITMAPINFO* info = (BITMAPINFO*)handle;
        if (info && info->bmiHeader.biSize >= sizeof(BITMAPINFOHEADER) &&
            info->bmiHeader.biWidth > 0 && info->bmiHeader.biHeight != 0) {
            int bitCount = info->bmiHeader.biBitCount;
            int colors = info->bmiHeader.biClrUsed;
            if (bitCount <= 8 && colors == 0) colors = 1 << bitCount;
            size_t palette = bitCount <= 8 ? (size_t)colors * sizeof(RGBQUAD) : 0;
            BYTE* bits = (BYTE*)handle + info->bmiHeader.biSize + palette;
            HDC screen = GetDC(nullptr);
            HBITMAP bitmap = CreateDIBitmap(screen, &info->bmiHeader, CBM_INIT,
                                            bits, info, DIB_RGB_COLORS);
            ReleaseDC(nullptr, screen);
            if (bitmap) return bitmap;
        }
    }
    if (IsClipboardFormatAvailable(CF_BITMAP)) {
        HBITMAP source = (HBITMAP)GetClipboardData(CF_BITMAP);
        if (source) return (HBITMAP)CopyImage(source, IMAGE_BITMAP, 0, 0, 0);
    }
    return nullptr;
}

static void CaptureClipboard()
{
    if (!g_hwnd) return;
    DWORD sequence = GetClipboardSequenceNumber();
    if (sequence && sequence == g_lastClipboardSequence) return;
    if (!OpenClipboard(g_hwnd)) return;
    g_lastClipboardSequence = sequence;

    if (IsClipboardFormatAvailable(CF_UNICODETEXT)) {
        HANDLE handle = GetClipboardData(CF_UNICODETEXT);
        const wchar_t* source = handle ? (const wchar_t*)GlobalLock(handle) : nullptr;
        if (source && source[0]) {
            size_t length = wcslen(source);
            wchar_t* text = new wchar_t[length + 1];
            memcpy(text, source, (length + 1) * sizeof(wchar_t));
            ULONGLONG hash = HashTextValue(text);
            if (!ClipboardHistoryContains(CLIPBOARD_TEXT, hash)) {
                AddClipboardEntry(CLIPBOARD_TEXT, text, nullptr, hash);
            } else {
                delete[] text;
            }
        }
        if (source) GlobalUnlock(handle);
    } else if (IsClipboardFormatAvailable(CF_DIB) || IsClipboardFormatAvailable(CF_BITMAP)) {
        HBITMAP bitmap = ClipboardBitmap();
        if (bitmap) {
            ULONGLONG hash = HashBitmapValue(bitmap);
            if (hash && !ClipboardHistoryContains(CLIPBOARD_IMAGE, hash)) {
                AddClipboardEntry(CLIPBOARD_IMAGE, nullptr, bitmap, hash);
            } else {
                DeleteObject(bitmap);
            }
        }
    } else {
        ULONGLONG hash = 1469598103934665603ULL;
        bool hasFormat = false;
        UINT format = 0;
        while ((format = EnumClipboardFormats(format)) != 0) {
            hasFormat = true;
            hash = HashBytes(&format, sizeof(format), hash);
        }
        if (hasFormat && !ClipboardHistoryContains(CLIPBOARD_OTHER, hash)) {
            wchar_t* text = new wchar_t[16];
            StringCchCopyW(text, 16, L"（特殊格式）");
            AddClipboardEntry(CLIPBOARD_OTHER, text, nullptr, hash);
        }
    }
    CloseClipboard();
}

static void CopyTextToClipboard(const wchar_t* text)
{
    if (!text || !g_hwnd) return;
    if (!OpenClipboard(g_hwnd)) return;
    EmptyClipboard();
    size_t bytes = (wcslen(text) + 1) * sizeof(wchar_t);
    HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (memory) {
        void* target = GlobalLock(memory);
        if (target) {
            memcpy(target, text, bytes);
            GlobalUnlock(memory);
            SetClipboardData(CF_UNICODETEXT, memory);
        } else {
            GlobalFree(memory);
        }
    }
    CloseClipboard();
}

static void UpdateForegroundInfo()
{
    HWND foreground = GetForegroundWindow();
    if (!foreground || foreground == g_hwnd || IsChild(g_hwnd, foreground)) return;
    DWORD pid = 0;
    GetWindowThreadProcessId(foreground, &pid);
    if (!pid || pid == GetCurrentProcessId()) return;

    HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!process) return;
    wchar_t path[1024] = {};
    DWORD size = 1024;
    bool ok = QueryFullProcessImageNameW(process, 0, path, &size) != FALSE;
    CloseHandle(process);
    if (!ok) return;

    const wchar_t* base = wcsrchr(path, L'\\');
    base = base ? base + 1 : path;
    if (IsShellAppName(base)) return;
    wchar_t name[128] = {};
    AppNameFromPath(path, name, 128);
    if (!name[0]) return;
    if (g_recentForegroundCount > 0 && _wcsicmp(g_recentForeground[0], name) == 0) return;

    int found = -1;
    for (int i = 0; i < g_recentForegroundCount; ++i) {
        if (_wcsicmp(g_recentForeground[i], name) == 0) {
            found = i;
            break;
        }
    }
    if (found >= 0) {
        for (int i = found; i > 0; --i) {
            StringCchCopyW(g_recentForeground[i], 128, g_recentForeground[i - 1]);
        }
    } else {
        if (g_recentForegroundCount < 3) ++g_recentForegroundCount;
        for (int i = g_recentForegroundCount - 1; i > 0; --i) {
            StringCchCopyW(g_recentForeground[i], 128, g_recentForeground[i - 1]);
        }
    }
    StringCchCopyW(g_recentForeground[0], 128, name);

    wchar_t text[256] = L"台前 ";
    for (int i = 0; i < g_recentForegroundCount; ++i) {
        if (i) StringCchCatW(text, 256, L"/");
        StringCchCatW(text, 256, g_recentForeground[i]);
    }
    StringCchCopyW(g_foregroundText, 256, text);
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void RefreshQuickApps()
{
    if (g_pickerOpen) return;
    EnumerateVisibleApps();
    AppEntry sorted[32] = {};
    int count = g_appCount;
    for (int i = 0; i < count; ++i) sorted[i] = g_apps[i];
    for (int i = 1; i < count; ++i) {
        AppEntry key = sorted[i];
        int j = i - 1;
        while (j >= 0 && sorted[j].workingSet < key.workingSet) {
            sorted[j + 1] = sorted[j];
            --j;
        }
        sorted[j + 1] = key;
    }
    g_quickAppCount = count < 6 ? count : 6;
    for (int i = 0; i < g_quickAppCount; ++i) g_quickApps[i] = sorted[i];
    if (g_quickAppCount > 0) {
        StringCchPrintfW(g_quickText, 128, L"常用 %ls", g_quickApps[0].name);
    } else {
        StringCchCopyW(g_quickText, 128, L"常用 —");
    }
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

struct QuickActivateContext {
    DWORD pid;
    HWND window;
};

static BOOL CALLBACK QuickActivateProc(HWND window, LPARAM parameter)
{
    QuickActivateContext* context = (QuickActivateContext*)parameter;
    if (!IsWindowVisible(window)) return TRUE;
    if (GetWindow(window, GW_OWNER)) return TRUE;
    if (GetWindowLongW(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) return TRUE;
    if (GetWindowTextLengthW(window) == 0) return TRUE;
    DWORD pid = 0;
    GetWindowThreadProcessId(window, &pid);
    if (pid != context->pid) return TRUE;
    context->window = window;
    return FALSE;
}

static void ActivateQuickApp(int index)
{
    if (index < 0 || index >= g_quickAppCount) return;
    QuickActivateContext context = { g_quickApps[index].pid, nullptr };
    EnumWindows(QuickActivateProc, (LPARAM)&context);
    if (!context.window) return;
    if (IsIconic(context.window)) ShowWindow(context.window, SW_RESTORE);
    SetForegroundWindow(context.window);
    BringWindowToTop(context.window);
}
#endif

// ---------------------------------------------------------------------------
// Memory cleanup
// ---------------------------------------------------------------------------
static bool IsProtectedProcess(const wchar_t* name)
{
    static const wchar_t* protectedNames[] = {
        L"system", L"registry", L"smss.exe", L"csrss.exe", L"wininit.exe",
        L"winlogon.exe", L"services.exe", L"lsass.exe", L"lsaiso.exe",
        L"fontdrvhost.exe", L"dwm.exe", L"svchost.exe", L"audiodg.exe",
        L"memcompression", L"msmpeng.exe", L"securityhealthservice.exe",
        L"memoryassist.exe"
    };
    for (const wchar_t* protectedName : protectedNames) {
        if (_wcsicmp(name, protectedName) == 0) return true;
    }
    return false;
}

static bool IsUnnecessaryProcess(const wchar_t* name)
{
    static const wchar_t* names[] = {
        // Optional game launchers that often sit in the notification area.
        L"steam.exe", L"epicgameslauncher.exe", L"epicwebhelper.exe",
        L"battle.net.exe", L"ubisoftconnect.exe", L"galaxyclient.exe",
        L"eadesktop.exe", L"origin.exe", L"riotclientservices.exe",
        // Xbox Game Bar background pieces.
        L"gamebar.exe", L"gamebarftserver.exe",
        // Common updater / telemetry helpers.
        L"adobearm.exe", L"adobeupdateservice.exe", L"adobeacrobatupdateservice.exe",
        L"googleupdate.exe", L"googlecrashhandler.exe", L"googlecrashhandler64.exe",
        L"microsoftedgeupdate.exe", L"officeclicktorun.exe",
        L"officebackgroundtaskhandler.exe", L"jusched.exe", L"sogoucloud.exe"
    };
    for (const wchar_t* candidate : names) {
        if (_wcsicmp(name, candidate) == 0) return true;
    }
    return false;
}

struct WindowSearch {
    DWORD pid;
    BOOL found;
};

static BOOL CALLBACK FindVisibleWindowProc(HWND hwnd, LPARAM parameter)
{
    WindowSearch* search = (WindowSearch*)parameter;
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != search->pid) return TRUE;
    if (!IsWindowVisible(hwnd)) return TRUE;
    RECT rect = {};
    if (!GetWindowRect(hwnd, &rect)) return TRUE;
    if (rect.right <= rect.left || rect.bottom <= rect.top) return TRUE;
    search->found = TRUE;
    return FALSE;
}

static bool HasVisibleWindow(DWORD pid)
{
    WindowSearch search = { pid, FALSE };
    EnumWindows(FindVisibleWindowProc, (LPARAM)&search);
    return search.found != FALSE;
}

struct CloseWindowSearch {
    DWORD pid;
};

static BOOL CALLBACK CloseProcessWindowProc(HWND hwnd, LPARAM parameter)
{
    CloseWindowSearch* search = (CloseWindowSearch*)parameter;
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid == search->pid) {
        PostMessageW(hwnd, WM_CLOSE, 0, 0);
    }
    return TRUE;
}

static int CloseUnnecessaryProcesses()
{
    struct Candidate {
        HANDLE process;
        DWORD pid;
    };

    const int kMaxCandidates = 12;
    Candidate candidates[kMaxCandidates] = {};
    int candidateCount = 0;

    DWORD currentSession = 0;
    if (!ProcessIdToSessionId(GetCurrentProcessId(), &currentSession)) return 0;

    DWORD foregroundPid = 0;
    HWND foreground = GetForegroundWindow();
    if (foreground) GetWindowThreadProcessId(foreground, &foregroundPid);

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) return 0;

    PROCESSENTRY32W entry = {};
    entry.dwSize = sizeof(entry);
    DWORD self = GetCurrentProcessId();

    if (Process32FirstW(snapshot, &entry)) {
        do {
            if (candidateCount >= kMaxCandidates) break;
            DWORD pid = entry.th32ProcessID;
            if (pid == 0 || pid == 4 || pid == self) continue;
            if (pid == foregroundPid) continue;
            if (IsProtectedProcess(entry.szExeFile)) continue;
            if (!IsUnnecessaryProcess(entry.szExeFile)) continue;

            DWORD session = 0;
            if (!ProcessIdToSessionId(pid, &session) || session != currentSession) continue;

            // Never touch an app that still has a visible window. Minimized
            // windows count as visible, so actively used apps are protected.
            if (HasVisibleWindow(pid)) continue;

            HANDLE process = OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE, FALSE, pid);
            if (!process) continue;
            if (WaitForSingleObject(process, 0) == WAIT_OBJECT_0) {
                CloseHandle(process);
                continue;
            }
            candidates[candidateCount].process = process;
            candidates[candidateCount].pid = pid;
            ++candidateCount;
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);

    if (candidateCount == 0) return 0;

    // Ask each process to exit gracefully through its top-level windows first.
    for (int i = 0; i < candidateCount; ++i) {
        CloseWindowSearch search = { candidates[i].pid };
        EnumWindows(CloseProcessWindowProc, (LPARAM)&search);
    }

    Sleep(700);

    int closed = 0;
    for (int i = 0; i < candidateCount; ++i) {
        HANDLE process = candidates[i].process;
        if (WaitForSingleObject(process, 0) == WAIT_OBJECT_0) {
            ++closed;
        } else if (TerminateProcess(process, 0)) {
            WaitForSingleObject(process, 500);
            ++closed;
        }
        CloseHandle(process);
    }
    if (closed > 0) Sleep(150);
    return closed;
}

// ---------------------------------------------------------------------------
// Tencent ACE resource limiter
// ---------------------------------------------------------------------------
static bool IsAceProcessName(const wchar_t* name)
{
    static const wchar_t* names[] = {
        L"SGuard64.exe", L"SGuardSvc64.exe", L"SGuard.exe",
        L"ACE-Guard Client.exe", L"ACE-Guard Client64.exe",
        L"ACE-Guard.exe", L"ACE-Tray.exe", L"ACE-Client.exe",
        L"ACE-Service.exe", L"ACE-Game.exe", L"AntiCheatExpert.exe",
        L"AntiCheatExpert Service.exe"
    };
    for (const wchar_t* candidate : names) {
        if (_wcsicmp(name, candidate) == 0) return true;
    }
    if (_wcsnicmp(name, L"SGuard", 6) == 0) return true;
    if (_wcsnicmp(name, L"AntiCheatExpert", 15) == 0) return true;
    if (_wcsnicmp(name, L"ACE-", 4) == 0) {
        if (wcsstr(name, L"Guard") || wcsstr(name, L"Tray") ||
            wcsstr(name, L"Client") || wcsstr(name, L"Service") ||
            wcsstr(name, L"Base")) {
            return true;
        }
    }
    return false;
}

static bool IsAceProcessPath(const wchar_t* path)
{
    if (!path || !path[0]) return false;
    wchar_t lower[1024] = {};
    StringCchCopyW(lower, 1024, path);
    CharLowerBuffW(lower, (DWORD)wcslen(lower));
    return wcsstr(lower, L"\\anticheatexpert\\") != nullptr ||
           wcsstr(lower, L"\\ace\\") != nullptr ||
           wcsstr(lower, L"\\ace-guard") != nullptr ||
           wcsstr(lower, L"\\sguard\\") != nullptr ||
           wcsstr(lower, L"\\tencent\\ace") != nullptr ||
           wcsstr(lower, L"\\acebase\\") != nullptr;
}

static bool QueryAceImagePath(HANDLE process, wchar_t* path, DWORD capacity)
{
    DWORD size = capacity;
    path[0] = 0;
    return QueryFullProcessImageNameW(process, 0, path, &size) != FALSE;
}

static bool SetProcessIoPriority(HANDLE process, ULONG priority)
{
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (!ntdll) return false;
    typedef LONG(WINAPI* NtSetInformationProcessFn)(HANDLE, ULONG, PVOID, ULONG);
    static NtSetInformationProcessFn fn = nullptr;
    if (!fn) {
        fn = (NtSetInformationProcessFn)GetProcAddress(ntdll, "NtSetInformationProcess");
    }
    if (!fn) return false;
    // ProcessIoPriority = 33; 0 = very low, 2 = normal.
    LONG status = fn(process, 33, &priority, sizeof(priority));
    return status >= 0;
}

static void RemoveAceState(int index)
{
    if (index < 0 || index >= g_aceStateCount) return;
    if (g_aceStates[index].process) {
        CloseHandle(g_aceStates[index].process);
    }
    g_aceStates[index] = g_aceStates[g_aceStateCount - 1];
    g_aceStates[g_aceStateCount - 1] = {};
    --g_aceStateCount;
}

static int FindAceState(DWORD pid)
{
    for (int i = 0; i < g_aceStateCount; ++i) {
        if (g_aceStates[i].pid == pid) return i;
    }
    return -1;
}

static void CleanupAceStates()
{
    for (int i = g_aceStateCount - 1; i >= 0; --i) {
        HANDLE process = g_aceStates[i].process;
        if (!process || WaitForSingleObject(process, 0) == WAIT_OBJECT_0) {
            RemoveAceState(i);
        }
    }
}

static bool ApplyAceRestrictions(AceProcessState& state)
{
    HANDLE process = state.process;
    if (!process) return false;

    DWORD priorityClass = g_acePriority == 0 ? BELOW_NORMAL_PRIORITY_CLASS
                                             : IDLE_PRIORITY_CLASS;
    bool priorityApplied = SetPriorityClass(process, priorityClass) != FALSE;
    SetProcessPriorityBoost(process, TRUE);

    if (g_aceAffinity) {
        ULONG_PTR processMask = 0;
        ULONG_PTR systemMask = 0;
        if (GetProcessAffinityMask(process, &processMask, &systemMask)) {
            if (!state.affinitySaved) {
                state.originalAffinity = processMask;
                state.affinitySaved = true;
            }
            int lastCore = -1;
            for (int bit = 0; bit < (int)(sizeof(ULONG_PTR) * 8); ++bit) {
                if (systemMask & ((ULONG_PTR)1 << bit)) lastCore = bit;
            }
            if (lastCore >= 0) {
                ULONG_PTR target = (ULONG_PTR)1 << lastCore;
                if (SetProcessAffinityMask(process, target)) {
                    state.affinityApplied = true;
                }
            }
        }
    } else if (state.affinityApplied && state.affinitySaved) {
        SetProcessAffinityMask(process, state.originalAffinity);
        state.affinityApplied = false;
    }

    PROCESS_POWER_THROTTLING_STATE throttling = {};
    throttling.Version = PROCESS_POWER_THROTTLING_CURRENT_VERSION;
    throttling.ControlMask = PROCESS_POWER_THROTTLING_EXECUTION_SPEED;
    throttling.StateMask = g_aceEcoQos ? PROCESS_POWER_THROTTLING_EXECUTION_SPEED : 0;
    SetProcessInformation(process, ProcessPowerThrottling, &throttling, sizeof(throttling));

    MEMORY_PRIORITY_INFORMATION memoryPriority = {};
    memoryPriority.MemoryPriority = g_aceMemoryPriority ? MEMORY_PRIORITY_LOW
                                                        : MEMORY_PRIORITY_NORMAL;
    SetProcessInformation(process, ProcessMemoryPriority, &memoryPriority, sizeof(memoryPriority));

    SetProcessIoPriority(process, g_aceIoPriority ? 0 : 2);

    ULONGLONG now = GetTickCount64();
    if (g_aceTrimWorkingSet && now - state.lastTrim >= 5000) {
        EmptyWorkingSet(process);
        state.lastTrim = now;
    }

    return priorityApplied;
}

static void RestoreAceProcesses()
{
    for (int i = 0; i < g_aceStateCount; ++i) {
        AceProcessState& state = g_aceStates[i];
        HANDLE process = state.process;
        if (!process) continue;
        if (WaitForSingleObject(process, 0) == WAIT_TIMEOUT) {
            if (state.originalPriority) {
                SetPriorityClass(process, state.originalPriority);
            }
            SetProcessPriorityBoost(process, FALSE);
            if (state.affinityApplied && state.affinitySaved) {
                SetProcessAffinityMask(process, state.originalAffinity);
            }
            PROCESS_POWER_THROTTLING_STATE throttling = {};
            throttling.Version = PROCESS_POWER_THROTTLING_CURRENT_VERSION;
            throttling.ControlMask = PROCESS_POWER_THROTTLING_EXECUTION_SPEED;
            throttling.StateMask = 0;
            SetProcessInformation(process, ProcessPowerThrottling, &throttling, sizeof(throttling));
            MEMORY_PRIORITY_INFORMATION memoryPriority = {};
            memoryPriority.MemoryPriority = MEMORY_PRIORITY_NORMAL;
            SetProcessInformation(process, ProcessMemoryPriority, &memoryPriority, sizeof(memoryPriority));
            SetProcessIoPriority(process, 2);
        }
        CloseHandle(process);
        state = {};
    }
    g_aceStateCount = 0;
    g_aceDetected = 0;
    g_aceLimited = 0;
}

static void RefreshAceProcesses()
{
    CleanupAceStates();

    int detected = 0;
    int limited = 0;
    DWORD self = GetCurrentProcessId();

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        g_aceDetected = 0;
        g_aceLimited = 0;
        return;
    }

    PROCESSENTRY32W entry = {};
    entry.dwSize = sizeof(entry);
    if (Process32FirstW(snapshot, &entry)) {
        do {
            DWORD pid = entry.th32ProcessID;
            if (pid == 0 || pid == 4 || pid == self) continue;

            bool nameMatched = IsAceProcessName(entry.szExeFile);
            wchar_t imagePath[1024] = {};
            bool pathMatched = false;

            HANDLE probe = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
            if (probe) {
                QueryAceImagePath(probe, imagePath, 1024);
                pathMatched = IsAceProcessPath(imagePath);
                CloseHandle(probe);
            }
            if (!nameMatched && !pathMatched) continue;

            ++detected;
            int index = FindAceState(pid);
            if (index < 0) {
                if (g_aceStateCount >= (int)(sizeof(g_aceStates) / sizeof(g_aceStates[0]))) {
                    continue;
                }
                HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION |
                                                 PROCESS_SET_INFORMATION |
                                                 PROCESS_SET_QUOTA |
                                                 SYNCHRONIZE,
                                             FALSE, pid);
                if (!process) continue;

                index = g_aceStateCount++;
                AceProcessState& state = g_aceStates[index];
                state = {};
                state.pid = pid;
                state.process = process;
                state.originalPriority = GetPriorityClass(process);
                if (!state.originalPriority) state.originalPriority = NORMAL_PRIORITY_CLASS;
            }

            AceProcessState& state = g_aceStates[index];
            if (state.process &&
                WaitForSingleObject(state.process, 0) != WAIT_TIMEOUT) {
                RemoveAceState(index);
                continue;
            }
            if (ApplyAceRestrictions(state)) {
                ++limited;
            }
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);

    g_aceDetected = detected;
    g_aceLimited = limited;
}

static void UpdateAceMode()
{
    if (!g_aceMode) return;
    ULONGLONG now = GetTickCount64();
    if (!g_aceForceApply && now < g_aceNextScan) return;
    g_aceForceApply = false;
    g_aceNextScan = now + 2000;
    RefreshAceProcesses();
}

static int TrimProcessWorkingSets()
{
    int trimmed = 0;
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) return 0;

    PROCESSENTRY32W entry = {};
    entry.dwSize = sizeof(entry);
    DWORD self = GetCurrentProcessId();

    if (Process32FirstW(snapshot, &entry)) {
        do {
            DWORD pid = entry.th32ProcessID;
            if (pid == 0 || pid == 4 || pid == self) continue;
            if (IsProtectedProcess(entry.szExeFile)) continue;

            DWORD session = 0;
            if (ProcessIdToSessionId(pid, &session) && session == 0) continue;

            HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_SET_QUOTA,
                                         FALSE, pid);
            if (!process) continue;
            if (EmptyWorkingSet(process)) ++trimmed;
            CloseHandle(process);
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);
    return trimmed;
}

static CleanupResult* PerformCleanup(bool closeProcesses)
{
    CleanupResult* result = (CleanupResult*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY,
                                                      sizeof(CleanupResult));
    if (!result) return nullptr;

    MEMORYSTATUSEX mem = {};
    mem.dwLength = sizeof(mem);
    GlobalMemoryStatusEx(&mem);
    result->availBefore = mem.ullAvailPhys;
    result->closeRequested = closeProcesses ? TRUE : FALSE;

    if (closeProcesses) {
        result->closed = CloseUnnecessaryProcesses();
    }

    result->trimmed = TrimProcessWorkingSets();

    if (g_elevated) {
        result->standbyPurged = PurgeStandbyList() ? TRUE : FALSE;
    }

    // Let Windows settle before measuring the result.
    Sleep(350);
    mem.dwLength = sizeof(mem);
    GlobalMemoryStatusEx(&mem);
    result->availAfter = mem.ullAvailPhys;

    // Keep our own footprint tiny as well.
    SetProcessWorkingSetSize(GetCurrentProcess(), (SIZE_T)-1, (SIZE_T)-1);

    return result;
}

static DWORD WINAPI CleanupThreadProc(LPVOID parameter)
{
    ULONG_PTR flags = (ULONG_PTR)parameter;
    bool automatic = (flags & 1) != 0;
    bool closeProcesses = (flags & 2) != 0;
    CleanupResult* result = PerformCleanup(closeProcesses);
    if (!result) {
        if (g_hwnd) {
            PostMessageW(g_hwnd, WM_APP_CLEAN_DONE, automatic ? 1 : 0, 0);
        }
        return 0;
    }
    if (!g_hwnd || !PostMessageW(g_hwnd, WM_APP_CLEAN_DONE, automatic ? 1 : 0,
                                 (LPARAM)result)) {
        HeapFree(GetProcessHeap(), 0, result);
    }
    return 0;
}

static void StartCleanup(bool automatic)
{
    if (g_busy || g_closing) return;
    bool closeProcesses = automatic ? g_closeAuto : g_closeManual;
    g_busy = true;
    g_pressedTrim = false;
    g_pressedToggle = false;
    g_pressedCloseAuto = false;
    g_pressedCloseManual = false;
    g_pressedAceToggle = false;
    g_pressedAceSettings = false;
    g_pressedCompact = false;
    g_pressedMinimal = false;
    g_pressedSingleSwitch = false;
    g_pressedMultiSwitch = false;
    g_pressedSingleField = false;
    g_pressedMultiField = false;
    g_pressedBackground = false;
    g_pressedExpand = false;
    g_pressedCompactClose = false;
    g_pressedMinimalExpand = false;
    g_compactDragging = false;
    g_dragging = false;
    g_lastClosed = 0;
    g_lastCloseRequested = false;
    g_status2[0] = 0;
    StringCchCopyW(g_status1, 160, L"正在整理内存…");
    StringCchCopyW(g_status2, 160,
                   closeProcesses ? L"正在关闭后台进程并回收内存"
                                  : L"正在回收工作集与待机缓存");
    InvalidateRect(g_hwnd, nullptr, FALSE);

    ULONG_PTR flags = (automatic ? 1 : 0) | (closeProcesses ? 2 : 0);
    HANDLE thread = CreateThread(nullptr, 0, CleanupThreadProc,
                                 (LPVOID)flags, 0, nullptr);
    if (thread) {
        CloseHandle(thread);
    } else {
        g_busy = false;
        StringCchCopyW(g_status1, 160, L"无法开始整理");
        StringCchCopyW(g_status2, 160, L"请稍后重试");
        InvalidateRect(g_hwnd, nullptr, FALSE);
    }
}

static void UpdateWarningText()
{
    const wchar_t* suffix = g_elevated ? L"请关闭大型程序后重试。"
                                       : L"请关闭大型程序或提升权限后重试。";
    if (g_auto) {
        StringCchPrintfW(g_warnDetail, 320,
                         L"当前占用 %d%%，阈值 %d%%。自动整理已暂停，%ls",
                         g_metrics.memPercent, g_threshold, suffix);
    } else {
        StringCchPrintfW(g_warnDetail, 320,
                         L"当前占用 %d%%，阈值 %d%%。%ls",
                         g_metrics.memPercent, g_threshold, suffix);
    }
}

static void FinishCleanup(bool automatic, CleanupResult* result)
{
    g_busy = false;
    SampleMemory();

    bool wasWarning = g_warning;
    long long freed = 0;
    g_lastClosed = 0;
    g_lastCloseRequested = false;
    if (result) {
        freed = (long long)result->availAfter - (long long)result->availBefore;
        g_lastFreed = freed;
        g_lastClosed = result->closed;
        g_lastCloseRequested = result->closeRequested != FALSE;
        g_lastCleanupTick = GetTickCount64();

        SYSTEMTIME now = {};
        GetLocalTime(&now);
        bool deep = result->standbyPurged != FALSE;
        if (automatic) {
            StringCchPrintfW(g_status1, 160, deep ? L"自动深度整理 · %02d:%02d"
                                                  : L"自动整理 · %02d:%02d",
                             now.wHour, now.wMinute);
        } else {
            StringCchPrintfW(g_status1, 160, deep ? L"深度整理 · %02d:%02d"
                                                  : L"上次整理 · %02d:%02d",
                             now.wHour, now.wMinute);
        }

        wchar_t freedText[48] = {};
        if (result->closed > 0) {
            if (freed > 10LL * 1024LL * 1024LL) {
                FormatDelta(freed, freedText, 48);
                StringCchPrintfW(g_status2, 160, L"释放 %ls · 关闭 %d 个",
                                 freedText, result->closed);
            } else {
                StringCchPrintfW(g_status2, 160, L"已关闭 %d 个后台程序", result->closed);
            }
        } else if (freed > 10LL * 1024LL * 1024LL) {
            FormatDelta(freed, freedText, 48);
            StringCchPrintfW(g_status2, 160, L"释放 %ls · %d 个进程", freedText, result->trimmed);
        } else if (result->trimmed > 0) {
            StringCchPrintfW(g_status2, 160, L"已整理 %d 个进程", result->trimmed);
        } else {
            StringCchCopyW(g_status2, 160, L"整理完成 · 没有可整理的进程");
        }

        HeapFree(GetProcessHeap(), 0, result);
    } else {
        StringCchCopyW(g_status1, 160, L"整理失败");
        StringCchCopyW(g_status2, 160, L"请稍后重试");
    }

    bool stillHigh = g_metrics.memPercent >= g_threshold;
    g_warning = stillHigh;
    if (stillHigh) {
        UpdateWarningText();
        if (g_auto) g_autoBlocked = true;
        if (!wasWarning && GetForegroundWindow() != g_hwnd) {
            MessageBeep(MB_ICONWARNING);
            FLASHWINFO info = {};
            info.cbSize = sizeof(info);
            info.hwnd = g_hwnd;
            info.dwFlags = FLASHW_ALL | FLASHW_TIMERNOFG;
            info.uCount = 3;
            FlashWindowEx(&info);
        }
    } else {
        g_autoBlocked = false;
    }

    InvalidateRect(g_hwnd, nullptr, FALSE);
}

// ---------------------------------------------------------------------------
// Painting
// ---------------------------------------------------------------------------
static COLORREF SelectedBackgroundColor()
{
    if (g_bgPreset < 0 || g_bgPreset >= kBackgroundPresetCount) return kBg;
    return kBackgroundPresets[g_bgPreset].color;
}

static bool HasTintedBackground()
{
    return !g_bgUseImage && g_bgPreset > 0;
}

static void FreeBackgroundBitmap()
{
    if (g_bgImageBitmap) {
        DeleteObject(g_bgImageBitmap);
        g_bgImageBitmap = nullptr;
    }
    g_bgBitmapWidth = 0;
    g_bgBitmapHeight = 0;
}

static bool BuildBackgroundBitmap(int width, int height)
{
    if (!g_bgUseImage || !g_bgImagePath[0] || width <= 0 || height <= 0) return false;
    if (g_bgImageBitmap && g_bgBitmapWidth == width && g_bgBitmapHeight == height) {
        return true;
    }
    FreeBackgroundBitmap();

    Gdiplus::GdiplusStartupInput input;
    ULONG_PTR token = 0;
    if (Gdiplus::GdiplusStartup(&token, &input, nullptr) != Gdiplus::Ok) return false;

    HBITMAP bitmap = nullptr;
    bool success = false;
    {
        Gdiplus::Image image(g_bgImagePath);
        if (image.GetLastStatus() == Gdiplus::Ok) {
            int imageWidth = (int)image.GetWidth();
            int imageHeight = (int)image.GetHeight();
            if (imageWidth > 0 && imageHeight > 0) {
                HDC screen = GetDC(nullptr);
                HDC memory = screen ? CreateCompatibleDC(screen) : nullptr;
                bitmap = (screen && memory)
                             ? CreateCompatibleBitmap(screen, width, height)
                             : nullptr;
                if (screen && memory && bitmap) {
                    HGDIOBJ oldBitmap = SelectObject(memory, bitmap);
                    {
                        Gdiplus::Graphics graphics(memory);
                        graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
                        graphics.SetPixelOffsetMode(Gdiplus::PixelOffsetModeHighQuality);
                        graphics.SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);

                        double scaleX = (double)width / (double)imageWidth;
                        double scaleY = (double)height / (double)imageHeight;
                        double scale = scaleX > scaleY ? scaleX : scaleY;
                        double drawWidth = imageWidth * scale;
                        double drawHeight = imageHeight * scale;
                        double x = ((double)width - drawWidth) * 0.5;
                        double y = ((double)height - drawHeight) * 0.5;
                        Gdiplus::RectF destination((Gdiplus::REAL)x, (Gdiplus::REAL)y,
                                                   (Gdiplus::REAL)drawWidth,
                                                   (Gdiplus::REAL)drawHeight);
                        graphics.DrawImage(&image, destination, 0.0f, 0.0f,
                                           (Gdiplus::REAL)imageWidth,
                                           (Gdiplus::REAL)imageHeight,
                                           Gdiplus::UnitPixel);
                        Gdiplus::SolidBrush veil(Gdiplus::Color(kSpecialTheme ? 120 : 190,
                                                                245, 247, 251));
                        graphics.FillRectangle(&veil, 0, 0, width, height);
                        graphics.Flush();
                    }
                    SelectObject(memory, oldBitmap);
                    success = true;
                }
                if (memory) DeleteDC(memory);
                if (screen) ReleaseDC(nullptr, screen);
            }
        }
    }
    Gdiplus::GdiplusShutdown(token);

    if (!success) {
        if (bitmap) DeleteObject(bitmap);
        return false;
    }

    g_bgImageBitmap = bitmap;
    g_bgBitmapWidth = width;
    g_bgBitmapHeight = height;
    return true;
}

static void PaintAppBackground(HDC dc, int width, int height)
{
    if (g_bgUseImage && BuildBackgroundBitmap(width, height)) {
        HDC memory = CreateCompatibleDC(dc);
        HGDIOBJ oldBitmap = SelectObject(memory, g_bgImageBitmap);
        BitBlt(dc, 0, 0, width, height, memory, 0, 0, SRCCOPY);
        SelectObject(memory, oldBitmap);
        DeleteDC(memory);
        return;
    }
    RECT full = { 0, 0, width, height };
    FillColor(dc, full, SelectedBackgroundColor());
}

static void FreeWatermarkBitmap()
{
    if (g_watermarkBitmap) {
        DeleteObject(g_watermarkBitmap);
        g_watermarkBitmap = nullptr;
    }
    g_watermarkWidth = 0;
    g_watermarkHeight = 0;
}

static void CreateWatermarkBitmap(HDC reference)
{
    if (g_watermarkBitmap) return;
    const wchar_t* text = L"Jiuzhu@1335";
    int textWidth = MeasureString(reference, g_fFooter, text);
    int width = textWidth + S(6);
    int height = S(16);
    if (width < S(20)) width = S(20);

    BITMAPINFO info = {};
    info.bmiHeader.biSize = sizeof(info.bmiHeader);
    info.bmiHeader.biWidth = width;
    info.bmiHeader.biHeight = -height;
    info.bmiHeader.biPlanes = 1;
    info.bmiHeader.biBitCount = 32;
    info.bmiHeader.biCompression = BI_RGB;
    void* pixels = nullptr;
    HBITMAP bitmap = CreateDIBSection(reference, &info, DIB_RGB_COLORS, &pixels, nullptr, 0);
    if (!bitmap || !pixels) {
        if (bitmap) DeleteObject(bitmap);
        return;
    }
    memset(pixels, 0, (size_t)width * height * 4);

    HDC memory = CreateCompatibleDC(reference);
    HGDIOBJ oldBitmap = SelectObject(memory, bitmap);
    HGDIOBJ oldFont = SelectObject(memory, g_fFooter);
    SetBkMode(memory, TRANSPARENT);
    SetTextColor(memory, RGB(1, 1, 1));
    TextOutW(memory, S(1), S(1), text, (int)wcslen(text));
    SetTextColor(memory, RGB(255, 255, 255));
    TextOutW(memory, 0, 0, text, (int)wcslen(text));
    GdiFlush();
    SelectObject(memory, oldFont);
    SelectObject(memory, oldBitmap);
    DeleteDC(memory);

    unsigned char* data = (unsigned char*)pixels;
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            unsigned char* pixel = data + ((size_t)y * width + x) * 4;
            int maximum = pixel[0];
            if (pixel[1] > maximum) maximum = pixel[1];
            if (pixel[2] > maximum) maximum = pixel[2];
            int alpha = 0;
            if (maximum > 0) {
                alpha = maximum >= 200 ? 120 : 45 + maximum * 75 / 255;
                if (alpha > 140) alpha = 140;
                if (alpha < 38) alpha = 38;
            }
            pixel[3] = (unsigned char)alpha;
        }
    }

    g_watermarkBitmap = bitmap;
    g_watermarkWidth = width;
    g_watermarkHeight = height;
}

static void DrawSpecialWatermark(HDC dc, int width, int height)
{
    if (!kSpecialTheme) return;
    CreateWatermarkBitmap(dc);
    if (!g_watermarkBitmap) return;
    int x = width - g_watermarkWidth - S(10);
    int y = height - g_watermarkHeight - S(1);
    if (!g_compact) {
        Layout l = GetLayout();
        x = l.backgroundButton.left - g_watermarkWidth - S(8);
        y = l.backgroundButton.top + (l.backgroundButton.bottom - l.backgroundButton.top -
                                      g_watermarkHeight) / 2;
    }
    HDC memory = CreateCompatibleDC(dc);
    HGDIOBJ oldBitmap = SelectObject(memory, g_watermarkBitmap);
    BLENDFUNCTION blend = {};
    blend.BlendOp = AC_SRC_OVER;
    blend.SourceConstantAlpha = 255;
    blend.AlphaFormat = AC_SRC_ALPHA;
    AlphaBlend(dc, x, y, g_watermarkWidth, g_watermarkHeight,
               memory, 0, 0, g_watermarkWidth, g_watermarkHeight, blend);
    SelectObject(memory, oldBitmap);
    DeleteDC(memory);
}

static void DrawSparkle(HDC dc, int cx, int cy, int radius, COLORREF color)
{
    int inner = radius * 22 / 100;
    POINT points[8] = {
        { cx, cy - radius },
        { cx + inner, cy - inner },
        { cx + radius, cy },
        { cx + inner, cy + inner },
        { cx, cy + radius },
        { cx - inner, cy + inner },
        { cx - radius, cy },
        { cx - inner, cy - inner }
    };
    HBRUSH brush = CreateSolidBrush(color);
    HPEN pen = CreatePen(PS_SOLID, 1, color);
    HGDIOBJ oldBrush = SelectObject(dc, brush);
    HGDIOBJ oldPen = SelectObject(dc, pen);
    Polygon(dc, points, 8);
    SelectObject(dc, oldBrush);
    SelectObject(dc, oldPen);
    DeleteObject(brush);
    DeleteObject(pen);
}

static void DrawPermissionChip(HDC dc)
{
    Layout l = GetLayout();
    RECT r = l.adminChip;
    if (g_elevated) {
        DrawSurface(dc, r, 15, kGreenPale, kGreenBorder);
        RECT dot = { r.left + S(14), r.top + S(12), r.left + S(20), r.top + S(18) };
        HBRUSH brush = CreateSolidBrush(kGreen);
        HGDIOBJ old = SelectObject(dc, brush);
        HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
        Ellipse(dc, dot.left, dot.top, dot.right, dot.bottom);
        SelectObject(dc, old);
        SelectObject(dc, oldPen);
        DeleteObject(brush);
        RECT text = { r.left + S(26), r.top, r.right - S(10), r.bottom };
        DrawString(dc, L"管理员模式", text, g_fChip, RGB(6, 95, 70));
    } else {
        COLORREF border = (g_hover == HOVER_ADMIN) ? RGB(245, 202, 135) : kAmberBorder;
        DrawSurface(dc, r, 15, kAmberPale, border);
        RECT dot = { r.left + S(14), r.top + S(12), r.left + S(20), r.top + S(18) };
        HBRUSH brush = CreateSolidBrush(kAmber);
        HGDIOBJ old = SelectObject(dc, brush);
        HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
        Ellipse(dc, dot.left, dot.top, dot.right, dot.bottom);
        SelectObject(dc, old);
        SelectObject(dc, oldPen);
        DeleteObject(brush);
        RECT text = { r.left + S(26), r.top, r.right - S(8), r.bottom };
        DrawString(dc, L"标准权限 · 点击提升", text, g_fChip, RGB(146, 88, 12));
    }
}

static void DrawMetricCard(HDC dc, const RECT& card, int index)
{
    DrawSurface(dc, card, 15, kCard, SurfaceBorder());

    const wchar_t* label = L"";
    const wchar_t* detail = L"";
    const wchar_t* trailing = L"";
    const wchar_t* unit = L"%";
    COLORREF accent = kBlue;
    COLORREF detailColor = kMuted;
    double barPercent = 0.0;
    int displayValue = 0;
    bool valid = true;

    if (index == 0) {
        label = L"CPU 使用率";
        detail = g_cpuDetail;
        accent = kAmber;
        barPercent = g_metrics.cpu;
        displayValue = (int)std::lround(g_metrics.cpu);
    } else if (index == 1) {
        label = L"内存占用";
        detail = g_memDetail;
        accent = (g_metrics.memPercent >= g_threshold) ? kRed : kBlue;
        barPercent = (double)g_metrics.memPercent;
        displayValue = g_metrics.memPercent;
        static wchar_t thresholdText[32] = {};
        if (g_metrics.memPercent >= g_threshold) {
            StringCchCopyW(thresholdText, 32, L"已达阈值");
        } else {
            StringCchPrintfW(thresholdText, 32, L"阈值 %d%%", g_threshold);
        }
        trailing = thresholdText;
    } else if (index == 2) {
        label = L"GPU 使用率";
        detail = g_gpuDetail;
        accent = kViolet;
        barPercent = g_metrics.gpu;
        displayValue = (int)std::lround(g_metrics.gpu);
        valid = g_metrics.gpuValid;
    } else {
        label = L"前台帧率";
        accent = kGreen;
        unit = L"FPS";
        valid = g_fpsValid;
        displayValue = g_fpsValue;
        barPercent = g_fpsValue > 144 ? 100.0 : (double)g_fpsValue * 100.0 / 144.0;
        if (!g_fpsAvailable) {
            detail = g_fpsNeedsAdmin ? L"需管理员权限" : L"帧率不可用";
            detailColor = g_fpsNeedsAdmin ? kAmberText : kMuted;
        } else if (!g_fpsValid) {
            detail = L"等待前台程序";
        } else {
            detail = L"最近 1 秒";
        }
    }

    RECT dot = { card.left + S(20), card.top + S(24), card.left + S(28), card.top + S(32) };
    HBRUSH dotBrush = CreateSolidBrush(accent);
    HGDIOBJ oldBrush = SelectObject(dc, dotBrush);
    HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
    Ellipse(dc, dot.left, dot.top, dot.right, dot.bottom);
    SelectObject(dc, oldBrush);
    SelectObject(dc, oldPen);
    DeleteObject(dotBrush);

    RECT labelRect = { card.left + S(36), card.top + S(14), card.right - S(12), card.top + S(38) };
    DrawString(dc, label, labelRect, g_fCardLabel, kTextSoft);

    wchar_t number[24] = {};
    if (valid) {
        StringCchPrintfW(number, 24, L"%d", displayValue);
    } else {
        StringCchCopyW(number, 24, L"--");
    }

    RECT valueRect = { card.left + S(20), card.top + S(38), card.right - S(16), card.top + S(94) };
    DrawString(dc, number, valueRect, g_fValue, valid ? kText : kFaint);

    if (valid) {
        int numberWidth = MeasureString(dc, g_fValue, number);
        RECT unitRect = { card.left + S(20) + numberWidth + S(3), card.top + S(52),
                          card.right - S(12), card.top + S(90) };
        DrawString(dc, unit, unitRect, g_fUnit, kTextSoft);
    }

    RECT detailRect = { card.left + S(20), card.top + S(94), card.right - S(20), card.top + S(112) };
    DrawString(dc, detail, detailRect, g_fDetail, detailColor,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    if (trailing[0]) {
        RECT trailingRect = { card.left + S(92), card.top + S(94), card.right - S(20), card.top + S(112) };
        DrawString(dc, trailing, trailingRect, g_fDetail,
                   (index == 1 && g_metrics.memPercent >= g_threshold) ? kRed : kFaint,
                   DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
    }

    RECT track = { card.left + S(20), card.top + S(120), card.right - S(20), card.top + S(128) };
    if (kSpecialTheme) {
        DrawHollowRound(dc, track, 4, RGB(160, 174, 192));
    } else {
        RoundFill(dc, track, 4, kTrack, kTrack);
    }
    if (valid && barPercent > 0.0) {
        double clamped = barPercent > 100.0 ? 100.0 : barPercent;
        int width = (int)std::lround((double)(track.right - track.left) * clamped / 100.0);
        if (width < S(8)) width = S(8);
        RECT fill = { track.left, track.top, track.left + width, track.bottom };
        if (fill.right > track.right) fill.right = track.right;
        RoundFill(dc, fill, 4, accent, accent);
    }
}

static void DrawHeader(HDC dc)
{
    RECT icon = R(42, 22, 42, 42);
    RoundFill(dc, icon, 13, kBlue, kBlue);
    DrawSparkle(dc, icon.left + S(21), icon.top + S(21), S(11), RGB(255, 255, 255));
    DrawSparkle(dc, icon.left + S(31), icon.top + S(11), S(4), RGB(191, 219, 254));

    RECT title = R(96, 21, 380, 31);
    DrawString(dc, kSpecialTheme ? g_displayName : L"内存整理助手", title, g_fTitle, kText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    RECT subtitle = R(97, 50, 380, 20);
    DrawString(dc, L"CPU · 内存 · GPU · FPS 实时监控", subtitle, g_fSubtitle, kMuted);

    DrawPermissionChip(dc);

    Layout l = GetLayout();
    RECT compact = l.compactButton;
    COLORREF compactBg = (g_hover == HOVER_COMPACT) ? kBluePale : RGB(248, 250, 253);
    COLORREF compactBorder = (g_hover == HOVER_COMPACT) ? kBlueBorder : kCardBorder;
    DrawSurface(dc, compact, 10, compactBg, compactBorder);
    DrawString(dc, L"小窗", compact, g_fChip, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT minimal = l.minimalButton;
    COLORREF minimalBg = (g_hover == HOVER_MINIMAL) ? kBluePale : RGB(248, 250, 253);
    COLORREF minimalBorder = (g_hover == HOVER_MINIMAL) ? kBlueBorder : kCardBorder;
    DrawSurface(dc, minimal, 10, minimalBg, minimalBorder);
    DrawString(dc, L"极简", minimal, g_fChip, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void DrawSwitch(HDC dc, const RECT& toggle, bool on, bool hovered)
{
    COLORREF background = on ? kBlue : RGB(203, 213, 225);
    if (hovered) background = on ? kBlueHover : RGB(186, 198, 214);
    if (kSpecialTheme) {
        DrawHollowRound(dc, toggle, 12,
                        on ? (hovered ? kBlueHover : kBlue) : RGB(148, 163, 184));
    } else {
        RoundFill(dc, toggle, 12, background, background);
    }

    int knobSize = S(20);
    int knobX = on ? toggle.right - S(2) - knobSize : toggle.left + S(2);
    RECT knob = { knobX, toggle.top + S(2), knobX + knobSize, toggle.bottom - S(2) };
    HBRUSH knobBrush = CreateSolidBrush(RGB(255, 255, 255));
    HPEN knobPen = CreatePen(PS_SOLID, S(1),
                            kSpecialTheme ? (on ? kBlue : RGB(148, 163, 184))
                                          : RGB(255, 255, 255));
    HGDIOBJ oldBrush = SelectObject(dc, knobBrush);
    HGDIOBJ oldPen = SelectObject(dc, kSpecialTheme ? knobPen : GetStockObject(NULL_PEN));
    Ellipse(dc, knob.left, knob.top, knob.right, knob.bottom);
    SelectObject(dc, oldBrush);
    SelectObject(dc, oldPen);
    DeleteObject(knobBrush);
    DeleteObject(knobPen);
}

static void DrawControlCard(HDC dc)
{
    Layout l = GetLayout();
    RECT card = l.control;
    DrawSurface(dc, card, 16, kCard, SurfaceBorder());

    RECT autoLabel = R(62, 266, 160, 24);
    DrawString(dc, L"自动整理", autoLabel, g_fSection, kText);
    DrawSwitch(dc, l.toggle, g_auto, g_hover == HOVER_TOGGLE);

    RECT autoHint = R(62, 296, 330, 18);
    DrawString(dc, g_auto ? L"达到阈值时自动回收内存" : L"当前已关闭",
               autoHint, g_fBody, kMuted);

    RECT closeAutoLabel = R(62, 320, 300, 24);
    DrawString(dc, L"关闭不必要进程", closeAutoLabel, g_fBody, kText);
    DrawSwitch(dc, l.toggleCloseAuto, g_closeAuto, g_hover == HOVER_CLOSE_AUTO);

    RECT closeAutoHint = R(62, 348, 330, 16);
    DrawString(dc, L"自动整理时生效 · 仅关闭无窗口的后台程序",
               closeAutoHint, g_fSmall, kFaint);

    RECT thresholdLabel = R(62, 376, 78, 24);
    DrawString(dc, L"触发阈值", thresholdLabel, g_fBody, kTextSoft);

    RECT slider = l.slider;
    int trackY = (slider.top + slider.bottom) / 2;
    RECT track = { slider.left, trackY - S(2), slider.right, trackY + S(3) };
    if (kSpecialTheme) {
        DrawHollowRound(dc, track, 3, RGB(160, 174, 192));
    } else {
        RoundFill(dc, track, 3, RGB(226, 232, 240), RGB(226, 232, 240));
    }
    double fraction = (double)(g_threshold - kMinThreshold) /
                      (double)(kMaxThreshold - kMinThreshold);
    int thumbX = slider.left + (int)std::lround((double)(slider.right - slider.left) * fraction);
    if (thumbX > track.left) {
        RECT fill = { track.left, track.top, thumbX, track.bottom };
        RoundFill(dc, fill, 3, kBlue, kBlue);
    }
    int thumbRadius = (g_hover == HOVER_SLIDER || g_dragging) ? S(8) : S(7);
    RECT thumb = { thumbX - thumbRadius, trackY - thumbRadius,
                   thumbX + thumbRadius, trackY + thumbRadius };
    HBRUSH thumbBrush = CreateSolidBrush(RGB(255, 255, 255));
    HPEN thumbPen = CreatePen(PS_SOLID, S(2), kBlue);
    HGDIOBJ oldThumbBrush = SelectObject(dc, thumbBrush);
    HGDIOBJ oldThumbPen = SelectObject(dc, thumbPen);
    Ellipse(dc, thumb.left, thumb.top, thumb.right, thumb.bottom);
    SelectObject(dc, oldThumbBrush);
    SelectObject(dc, oldThumbPen);
    DeleteObject(thumbBrush);
    DeleteObject(thumbPen);

    RECT minLabel = R(142, 404, 30, 14);
    DrawString(dc, L"50", minLabel, g_fSmall, kFaint);
    RECT maxLabel = R(312, 404, 30, 14);
    DrawString(dc, L"95", maxLabel, g_fSmall, kFaint,
               DT_RIGHT | DT_VCENTER | DT_SINGLELINE);

    wchar_t thresholdValue[16] = {};
    StringCchPrintfW(thresholdValue, 16, L"%d%%", g_threshold);
    RECT valueRect = R(354, 376, 70, 24);
    DrawString(dc, thresholdValue, valueRect, g_fSection, kBlue);

    RECT note = R(62, 430, 410, 18);
    DrawString(dc, L"自动整理最小间隔 60 秒 · 关闭进程仅限后台启动器/更新器",
               note, g_fSmall, kFaint);

    RECT divider = { S(500), S(270), S(501), S(440) };
    FillColor(dc, divider, kSpecialTheme ? RGB(160, 174, 192) : RGB(237, 240, 246));

    RECT button = l.trimButton;
    COLORREF buttonBg = kBlue;
    if (g_busy) {
        buttonBg = RGB(165, 184, 232);
    } else if (g_pressedTrim) {
        buttonBg = kBlueHover;
    } else if (g_hover == HOVER_TRIM) {
        buttonBg = RGB(45, 110, 245);
    }
    COLORREF buttonBorder = g_busy ? RGB(165, 184, 232) : kBlue;
    DrawSurface(dc, button, 15, buttonBg, buttonBorder);
    DrawString(dc, g_busy ? L"正在整理…" : L"立即整理内存",
               button, g_fButton, kSpecialTheme ? (g_busy ? kMuted : kBlue) : RGB(255, 255, 255),
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT closeManualLabel = R(520, 334, 170, 24);
    DrawString(dc, L"整理时关闭不必要进程", closeManualLabel, g_fBody, kText);
    DrawSwitch(dc, l.toggleCloseManual, g_closeManual, g_hover == HOVER_CLOSE_MANUAL);

    RECT status1 = R(520, 366, 238, 18);
    DrawString(dc, g_status1, status1, g_fBody, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    COLORREF statusColor = kMuted;
    if (g_lastFreed > 10LL * 1024LL * 1024LL || g_lastClosed > 0) statusColor = kGreen;
    if (g_warning) statusColor = kRed;
    RECT status2 = R(520, 386, 238, 18);
    DrawString(dc, g_status2, status2, g_fBody, statusColor,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    const wchar_t* hintText = L"整理可能使程序短暂卡顿";
    COLORREF hintColor = kFaint;
    if (g_warning) {
        hintText = L"建议关闭大型程序后重试";
    } else if (g_lastCloseRequested) {
        if (g_lastClosed > 0) {
            hintText = L"已关闭无窗口的后台启动器/更新器";
            hintColor = kGreen;
        } else {
            hintText = L"未发现可关闭的后台程序";
            hintColor = kMuted;
        }
    }
    RECT hint = R(520, 412, 238, 18);
    DrawString(dc, hintText, hint, g_fSmall, hintColor,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
}

static void DrawTencentCard(HDC dc)
{
    Layout l = GetLayout();
    RECT card = l.tencent;
    DrawSurface(dc, card, 15, kCard, SurfaceBorder());

    RECT badge = R(62, 498, 36, 36);
    DrawSurface(dc, badge, 10, g_aceMode ? kBlue : kBluePale,
                g_aceMode ? kBlue : kBlueBorder);
    RECT badgeText = { badge.left, badge.top, badge.right, badge.bottom };
    DrawString(dc, L"ACE", badgeText, g_fChip,
               g_aceMode ? (kSpecialTheme ? kBlue : RGB(255, 255, 255)) : kBlue,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT title = R(112, 482, 270, 24);
    DrawString(dc, L"腾讯游戏模式（全ACE限制）", title, g_fSection, kText);

    wchar_t status[160] = {};
    COLORREF statusColor = kMuted;
    if (!g_aceMode) {
        StringCchCopyW(status, 160, L"已关闭 · 不会结束、挂起或注入 ACE 进程");
    } else if (g_aceDetected == 0) {
        StringCchCopyW(status, 160, L"已开启 · 等待 ACE 进程启动");
    } else if (g_aceLimited == 0) {
        StringCchPrintfW(status, 160, L"检测 %d 个 ACE 进程 · 权限不足，建议管理员",
                         g_aceDetected);
        statusColor = kAmberText;
    } else if (g_aceLimited < g_aceDetected) {
        StringCchPrintfW(status, 160, L"检测 %d 个 · 已限制 %d 个 · 建议管理员权限",
                         g_aceDetected, g_aceLimited);
        statusColor = kAmberText;
    } else {
        StringCchPrintfW(status, 160, L"已限制 %d 个 ACE 进程 · 仅调整系统资源调度",
                         g_aceLimited);
        statusColor = kGreen;
    }
    RECT statusRect = R(112, 506, 270, 18);
    DrawString(dc, status, statusRect, g_fSmall, statusColor,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    DrawSwitch(dc, l.aceToggle, g_aceMode, g_hover == HOVER_ACE_TOGGLE);

    RECT divider = { S(500), S(490), S(501), S(542) };
    FillColor(dc, divider, kSpecialTheme ? RGB(160, 174, 192) : RGB(237, 240, 246));

    RECT priorityCaption = R(520, 486, 130, 18);
    DrawString(dc, L"ACE 优先级", priorityCaption, g_fSmall, kMuted);
    RECT priorityValue = R(520, 506, 130, 20);
    DrawString(dc, g_acePriority == 0 ? L"低于正常" : L"最低",
               priorityValue, g_fBody, kText);

    RECT settings = l.aceSettings;
    COLORREF settingsBg = (g_hover == HOVER_ACE_SETTINGS) ? kBluePale : RGB(246, 248, 252);
    COLORREF settingsBorder = (g_hover == HOVER_ACE_SETTINGS) ? kBlueBorder : kCardBorder;
    DrawSurface(dc, settings, 10, settingsBg, settingsBorder);
    DrawString(dc, L"设置", settings, g_fBody, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void DrawAppModeBar(HDC dc)
{
    Layout l = GetLayout();
    RECT card = l.appModeCard;
    DrawSurface(dc, card, 14, kCard, g_warning ? kAmberBorder : SurfaceBorder());

    DrawSwitch(dc, l.singleSwitch, g_appMode == 1, g_hover == HOVER_SINGLE_SWITCH);
    RECT singleLabel = R(112, 584, 60, 32);
    DrawString(dc, L"单应用", singleLabel, g_fBody, kText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    RECT single = l.singleField;
    bool singleActive = g_appMode == 1;
    DrawSurface(dc, single, 9,
                singleActive ? kBluePale : RGB(248, 250, 253),
                (g_hover == HOVER_SINGLE_FIELD) ? kBlueBorder
                                                : (singleActive ? kBlueBorder : SurfaceBorder()));
    RECT singleText = { single.left + S(12), single.top, single.right - S(28), single.bottom };
    DrawString(dc, g_singleFieldText, singleText, g_fSmall,
               singleActive ? kBlue : kTextSoft,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    RECT singleChevron = { single.right - S(24), single.top, single.right - S(8), single.bottom };
    DrawString(dc, L"▾", singleChevron, g_fSmall, kMuted,
               DT_RIGHT | DT_VCENTER | DT_SINGLELINE);

    RECT divider = { S(410), S(584), S(411), S(616) };
    FillColor(dc, divider, kSpecialTheme ? RGB(160, 174, 192) : RGB(237, 240, 246));

    DrawSwitch(dc, l.multiSwitch, g_appMode == 2, g_hover == HOVER_MULTI_SWITCH);
    RECT multiLabel = R(480, 584, 58, 32);
    DrawString(dc, L"多开", multiLabel, g_fBody, kText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    RECT multi = l.multiField;
    bool multiActive = g_appMode == 2;
    DrawSurface(dc, multi, 9,
                multiActive ? kBluePale : RGB(248, 250, 253),
                (g_hover == HOVER_MULTI_FIELD) ? kBlueBorder
                                               : (multiActive ? kBlueBorder : SurfaceBorder()));
    RECT multiText = { multi.left + S(12), multi.top, multi.right - S(28), multi.bottom };
    DrawString(dc, g_multiFieldText, multiText, g_fSmall,
               multiActive ? kBlue : kTextSoft,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    RECT multiChevron = { multi.right - S(24), multi.top, multi.right - S(8), multi.bottom };
    DrawString(dc, L"▾", multiChevron, g_fSmall, kMuted,
               DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
}

#ifndef SPECIAL_VERSION
static int ClipboardRowHeight(bool compact)
{
    return compact ? S(20) : S(34);
}

static int ClipboardRowsTop(const RECT& card, bool compact)
{
    return card.top + (compact ? S(28) : S(40));
}

static int ClipboardVisibleRows()
{
    return 5;
}

static RECT ClipboardRowRect(int row, bool compact)
{
    CompactLayout compactLayout = {};
    RECT card = {};
    if (compact) {
        compactLayout = GetCompactLayout();
        card = compactLayout.clipboardCard;
    } else {
        card = GetLayout().clipboardCard;
    }
    int top = ClipboardRowsTop(card, compact);
    int height = ClipboardRowHeight(compact);
    RECT r = { card.left + S(10), top + row * height,
               card.right - S(14), top + (row + 1) * height - S(2) };
    return r;
}

static int ClipboardHistoryIndexAt(int x, int y, bool compact)
{
    RECT card = compact ? GetCompactLayout().clipboardCard : GetLayout().clipboardCard;
    if (!PointIn(card, x, y)) return -1;
    int top = ClipboardRowsTop(card, compact);
    int height = ClipboardRowHeight(compact);
    int row = (y - top) / height;
    if (row < 0 || row >= ClipboardVisibleRows()) return -1;
    int index = g_clipboardCount - 1 - g_clipboardScroll - row;
    return (index >= 0 && index < g_clipboardCount) ? index : -1;
}

static int QuickAppAt(int x, int y)
{
    if (g_compact) {
        CompactLayout l = GetCompactLayout();
        for (int i = 0; i < 3; ++i) {
            if (PointIn(l.quickButton[i], x, y)) return i;
        }
        return -1;
    }
    Layout l = GetLayout();
    if (!PointIn(l.quickCard, x, y)) return -1;
    int top = l.quickCard.top + S(34);
    int row = (y - top) / S(28);
    if (row < 0 || row >= 6) return -1;
    return row;
}

static void FlattenClipboardText(const wchar_t* source, wchar_t* out, size_t capacity)
{
    size_t written = 0;
    bool lastSpace = false;
    for (const wchar_t* p = source; p && *p && written + 1 < capacity; ++p) {
        wchar_t c = *p;
        if (c == L'\r' || c == L'\n' || c == L'\t') c = L' ';
        if (c == L' ') {
            if (lastSpace) continue;
            lastSpace = true;
        } else {
            lastSpace = false;
        }
        out[written++] = c;
    }
    out[written] = 0;
}

static void DrawClipboardCard(HDC dc, bool compact)
{
    RECT card = compact ? GetCompactLayout().clipboardCard : GetLayout().clipboardCard;
    RoundFill(dc, card, compact ? 9 : 14, kCard, SurfaceBorder());
    RECT title = { card.left + S(12), card.top + S(4),
                   card.right - S(12), card.top + (compact ? S(24) : S(34)) };
    wchar_t header[32] = {};
    StringCchPrintfW(header, 32, L"剪贴板 · %d", g_clipboardCount);
    DrawString(dc, header, title, compact ? g_fSmall : g_fSection, kText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    int visible = ClipboardVisibleRows();
    for (int row = 0; row < visible; ++row) {
        int index = g_clipboardCount - 1 - g_clipboardScroll - row;
        RECT rowRect = ClipboardRowRect(row, compact);
        if (index < 0 || index >= g_clipboardCount) break;
        ClipboardEntry& entry = g_clipboardHistory[index];
        if (row == g_clipboardHoverRow) {
            FillColor(dc, rowRect, RGB(246, 249, 253));
        }
        wchar_t preview[512] = {};
        const wchar_t* display = entry.text;
        if (entry.kind == CLIPBOARD_IMAGE) {
            display = L"（图片）";
        } else if (entry.kind == CLIPBOARD_OTHER) {
            display = L"（特殊格式）";
        } else {
            FlattenClipboardText(entry.text, preview, 512);
            display = preview;
        }
        if (!display || !display[0]) display = L"（空）";
        RECT label = { rowRect.left + S(8), rowRect.top, rowRect.right, rowRect.bottom };
        DrawString(dc, display, label, g_fSmall,
                   entry.kind == CLIPBOARD_IMAGE ? kBlue :
                   (entry.kind == CLIPBOARD_OTHER ? kMuted : kTextSoft),
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    }

    if (g_clipboardCount == 0) {
        RECT empty = { card.left + S(12), card.top + S(44), card.right - S(12), card.bottom - S(24) };
        DrawString(dc, L"暂无剪贴板记录", empty, g_fSmall, kMuted,
                   DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }

    RECT hint = { card.left + S(12), card.bottom - (compact ? S(18) : S(24)),
                  card.right - S(12), card.bottom - S(4) };
    DrawString(dc, L"点击文本复制 · 图片可预览", hint, g_fFooter, kFaint,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    if (g_clipboardCount > visible) {
        int top = ClipboardRowsTop(card, compact);
        int height = ClipboardRowHeight(compact);
        RECT track = { card.right - S(8), top, card.right - S(5),
                       top + visible * height - S(2) };
        FillColor(dc, track, RGB(236, 241, 248));
        int maxScroll = g_clipboardCount - visible;
        int thumbHeight = (track.bottom - track.top) * visible / g_clipboardCount;
        if (thumbHeight < S(14)) thumbHeight = S(14);
        int offset = maxScroll > 0
                         ? (track.bottom - track.top - thumbHeight) * g_clipboardScroll / maxScroll
                         : 0;
        RECT thumb = { track.left, track.top + offset, track.right,
                       track.top + offset + thumbHeight };
        FillColor(dc, thumb, RGB(148, 163, 184));
    }
}

static bool SaveBitmapAsBmp(HBITMAP bitmap, const wchar_t* path)
{
    if (!bitmap || !path) return false;
    BITMAP info = {};
    if (!GetObjectW(bitmap, sizeof(info), &info) || info.bmWidth <= 0 || info.bmHeight <= 0) {
        return false;
    }
    BITMAPINFOHEADER header = {};
    header.biSize = sizeof(header);
    header.biWidth = info.bmWidth;
    header.biHeight = info.bmHeight;
    header.biPlanes = 1;
    header.biBitCount = 24;
    header.biCompression = BI_RGB;
    int stride = ((info.bmWidth * 3 + 3) / 4) * 4;
    header.biSizeImage = (DWORD)stride * info.bmHeight;
    BYTE* pixels = new BYTE[header.biSizeImage];
    BITMAPINFO dib = {};
    dib.bmiHeader = header;
    HDC screen = GetDC(nullptr);
    int lines = GetDIBits(screen, bitmap, 0, info.bmHeight, pixels, &dib, DIB_RGB_COLORS);
    ReleaseDC(nullptr, screen);
    if (lines != info.bmHeight) {
        delete[] pixels;
        return false;
    }

    BITMAPFILEHEADER fileHeader = {};
    fileHeader.bfType = 0x4D42;
    fileHeader.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    fileHeader.bfSize = fileHeader.bfOffBits + header.biSizeImage;
    HANDLE file = CreateFileW(path, GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        delete[] pixels;
        return false;
    }
    DWORD written = 0;
    bool ok = WriteFile(file, &fileHeader, sizeof(fileHeader), &written, nullptr) != FALSE;
    ok = ok && WriteFile(file, &header, sizeof(header), &written, nullptr) != FALSE;
    ok = ok && WriteFile(file, pixels, header.biSizeImage, &written, nullptr) != FALSE;
    CloseHandle(file);
    delete[] pixels;
    return ok;
}

static RECT PreviewSaveRect(HWND hwnd)
{
    RECT client = {};
    GetClientRect(hwnd, &client);
    RECT r = { client.right - S(126), client.bottom - S(46),
               client.right - S(18), client.bottom - S(14) };
    return r;
}

static LRESULT CALLBACK ClipboardPreviewProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
    case WM_PAINT: {
        PAINTSTRUCT ps = {};
        HDC dc = BeginPaint(hwnd, &ps);
        RECT client = {};
        GetClientRect(hwnd, &client);
        FillColor(dc, client, RGB(15, 23, 42));
        if (g_previewImage && g_previewImageWidth > 0 && g_previewImageHeight > 0) {
            int availableW = client.right - S(32);
            int availableH = client.bottom - S(74);
            double scaleX = (double)availableW / g_previewImageWidth;
            double scaleY = (double)availableH / g_previewImageHeight;
            double scale = scaleX < scaleY ? scaleX : scaleY;
            int drawW = (int)(g_previewImageWidth * scale);
            int drawH = (int)(g_previewImageHeight * scale);
            int x = (client.right - drawW) / 2;
            int y = S(16) + (availableH - drawH) / 2;
            HDC memory = CreateCompatibleDC(dc);
            HGDIOBJ old = SelectObject(memory, g_previewImage);
            SetStretchBltMode(dc, HALFTONE);
            StretchBlt(dc, x, y, drawW, drawH, memory, 0, 0,
                       g_previewImageWidth, g_previewImageHeight, SRCCOPY);
            SelectObject(memory, old);
            DeleteDC(memory);
        }
        RECT save = PreviewSaveRect(hwnd);
        RoundFill(dc, save, 8, RGB(37, 99, 235), RGB(37, 99, 235));
        DrawString(dc, L"保存图片", save, g_fBody, RGB(255, 255, 255),
                   DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_LBUTTONUP: {
        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);
        RECT save = PreviewSaveRect(hwnd);
        if (PointIn(save, x, y)) {
            wchar_t path[MAX_PATH] = L"clipboard.bmp";
            OPENFILENAMEW ofn = {};
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner = hwnd;
            ofn.lpstrFilter = L"BMP 图片 (*.bmp)\0*.bmp\0所有文件 (*.*)\0*.*\0\0";
            ofn.lpstrFile = path;
            ofn.nMaxFile = MAX_PATH;
            ofn.lpstrDefExt = L"bmp";
            ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
            if (GetSaveFileNameW(&ofn)) {
                if (SaveBitmapAsBmp(g_previewImage, path)) {
                    MessageBoxW(hwnd, L"图片已保存。", L"保存成功", MB_OK | MB_ICONINFORMATION);
                } else {
                    MessageBoxW(hwnd, L"图片保存失败。", L"保存失败", MB_OK | MB_ICONERROR);
                }
            }
        }
        return 0;
    }
    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        if (hwnd == g_previewHwnd) {
            g_previewHwnd = nullptr;
            if (g_previewImage && g_previewOwnsImage) {
                DeleteObject(g_previewImage);
            }
            g_previewImage = nullptr;
            g_previewOwnsImage = false;
            g_previewImageWidth = 0;
            g_previewImageHeight = 0;
        }
        return 0;
    }
    return DefWindowProcW(hwnd, message, wParam, lParam);
}

static void ShowClipboardImage(HBITMAP bitmap)
{
    if (!bitmap) return;
    if (g_previewHwnd) {
        DestroyWindow(g_previewHwnd);
        g_previewHwnd = nullptr;
    }
    BITMAP info = {};
    if (!GetObjectW(bitmap, sizeof(info), &info)) return;
    HBITMAP copy = (HBITMAP)CopyImage(bitmap, IMAGE_BITMAP, 0, 0, 0);
    bool owns = copy != nullptr;
    if (!copy) copy = bitmap;

    static bool registered = false;
    const wchar_t* className = L"MemoryAssist.ClipboardPreview.v1";
    if (!registered) {
        WNDCLASSEXW wc = {};
        wc.cbSize = sizeof(wc);
        wc.style = CS_DBLCLKS;
        wc.lpfnWndProc = ClipboardPreviewProc;
        wc.hInstance = GetModuleHandleW(nullptr);
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = nullptr;
        wc.lpszClassName = className;
        if (!RegisterClassExW(&wc)) {
            DeleteObject(copy);
            return;
        }
        registered = true;
    }

    g_previewImage = copy;
    g_previewOwnsImage = owns;
    g_previewImageWidth = info.bmWidth;
    g_previewImageHeight = info.bmHeight;
    int width = S(860);
    int height = S(620);
    RECT work = {};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
    int x = work.left + ((work.right - work.left) - width) / 2;
    int y = work.top + ((work.bottom - work.top) - height) / 2;
    g_previewHwnd = CreateWindowExW(WS_EX_TOPMOST, className, L"图片预览",
                                    WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
                                    x, y, width, height, g_hwnd, nullptr,
                                    GetModuleHandleW(nullptr), nullptr);
    if (!g_previewHwnd) {
        if (owns) DeleteObject(copy);
        g_previewImage = nullptr;
        g_previewOwnsImage = false;
        return;
    }
    ShowWindow(g_previewHwnd, SW_SHOW);
    UpdateWindow(g_previewHwnd);
}

static void DrawQuickApps(HDC dc)
{
    if (g_compact) {
        CompactLayout l = GetCompactLayout();
        for (int i = 0; i < 3; ++i) {
            RECT button = l.quickButton[i];
            RoundFill(dc, button, 8,
                      i == g_quickHover ? kBluePale : kCard,
                      i == g_quickHover ? kBlueBorder : SurfaceBorder());
            const wchar_t* name = i < g_quickAppCount ? g_quickApps[i].name : L"—";
            DrawString(dc, name, button, g_fSmall, kTextSoft,
                       DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        }
        return;
    }

    Layout l = GetLayout();
    RECT card = l.quickCard;
    RoundFill(dc, card, 14, kCard, SurfaceBorder());
    RECT title = { card.left + S(12), card.top + S(4), card.right - S(12), card.top + S(30) };
    DrawString(dc, L"常用应用", title, g_fSection, kText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    for (int i = 0; i < 6; ++i) {
        RECT row = { card.left + S(8), card.top + S(34) + i * S(28),
                     card.right - S(8), card.top + S(34) + (i + 1) * S(28) - S(2) };
        if (i == g_quickHover) FillColor(dc, row, RGB(246, 249, 253));
        const wchar_t* name = i < g_quickAppCount ? g_quickApps[i].name : L"—";
        DrawString(dc, name, row, g_fSmall,
                   i < g_quickAppCount ? kTextSoft : kFaint,
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    }
}

static void DrawForegroundInfo(HDC dc)
{
    if (g_compact) {
        CompactLayout l = GetCompactLayout();
        DrawString(dc, g_foregroundText, l.foreground, g_fSmall, kMuted,
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    } else {
        Layout l = GetLayout();
        DrawString(dc, g_foregroundText, l.foreground, g_fSmall, kMuted,
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    }
}
#endif

static void DrawAppPicker(HDC dc)
{
    if (!g_pickerOpen) return;
    RECT r = GetPickerRect();
    RoundFill(dc, r, 12, kCard, RGB(203, 213, 225));

    RECT header = { r.left, r.top, r.right, r.top + GetPickerHeaderHeight() };
    FillColor(dc, header, RGB(248, 250, 253));
    RECT title = { r.left + S(14), r.top, r.right - S(42), r.top + GetPickerHeaderHeight() };
    DrawString(dc, g_pickerMode == 1 ? L"选择单应用" : L"选择多开应用（可多选）",
               title, g_fBody, kText, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT close = { r.right - S(32), r.top + S(6), r.right - S(8), r.top + S(30) };
    RoundFill(dc, close, 5,
              (g_hover == HOVER_PICKER_CLOSE) ? kBluePale : RGB(248, 250, 253),
              (g_hover == HOVER_PICKER_CLOSE) ? kBlueBorder : RGB(248, 250, 253));
    DrawString(dc, L"×", close, g_fWarnTitle, kMuted,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    int rowHeight = GetPickerRowHeight();
    int rowsTop = r.top + GetPickerHeaderHeight();
    int visibleRows = GetPickerVisibleRows();
    if (g_appCount == 0) {
        RECT empty = { r.left + S(16), rowsTop, r.right - S(16),
                       rowsTop + rowHeight * 2 };
        DrawString(dc, L"没有检测到带可见窗口的应用",
                   empty, g_fSmall, kMuted, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }

    for (int row = 0; row < visibleRows; ++row) {
        int index = g_pickerScroll + row;
        if (index >= g_appCount) break;
        RECT rowRect = { r.left + S(4), rowsTop + row * rowHeight,
                         r.right - S(14), rowsTop + (row + 1) * rowHeight };
        bool selected = (g_pickerMode == 2)
                            ? g_pickerChecked[index]
                            : SamePath(g_apps[index].path, g_singleAppPath);
        if (selected) {
            FillColor(dc, rowRect, kBluePale);
        } else if (index == g_pickerHoverRow) {
            FillColor(dc, rowRect, RGB(247, 249, 252));
        }

        int markX = rowRect.left + S(10);
        int markY = rowRect.top + S(8);
        if (g_pickerMode == 2) {
            RECT box = { markX, markY, markX + S(14), markY + S(14) };
            if (g_pickerChecked[index]) {
                RoundFill(dc, box, 3, kBlue, kBlue);
                DrawString(dc, L"✓", box, g_fSmall, RGB(255, 255, 255),
                           DT_CENTER | DT_VCENTER | DT_SINGLELINE);
            } else {
                RoundFill(dc, box, 3, kCard, RGB(190, 201, 218));
            }
        } else {
            RECT radio = { markX, markY, markX + S(14), markY + S(14) };
            HBRUSH fillBrush = CreateSolidBrush(selected ? kBlue : kCard);
            HGDIOBJ oldBrush = SelectObject(dc, fillBrush);
            HPEN pen = CreatePen(PS_SOLID, S(1), selected ? kBlue : RGB(190, 201, 218));
            HGDIOBJ oldPen = SelectObject(dc, pen);
            Ellipse(dc, radio.left, radio.top, radio.right, radio.bottom);
            SelectObject(dc, oldBrush);
            SelectObject(dc, oldPen);
            DeleteObject(fillBrush);
            DeleteObject(pen);
            if (selected) {
                RECT dot = { radio.left + S(4), radio.top + S(4),
                             radio.right - S(4), radio.bottom - S(4) };
                HBRUSH dotBrush = CreateSolidBrush(RGB(255, 255, 255));
                oldBrush = SelectObject(dc, dotBrush);
                oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
                Ellipse(dc, dot.left, dot.top, dot.right, dot.bottom);
                SelectObject(dc, oldBrush);
                SelectObject(dc, oldPen);
                DeleteObject(dotBrush);
            }
        }

        RECT nameRect = { rowRect.left + S(32), rowRect.top, rowRect.left + S(152), rowRect.bottom };
        DrawString(dc, g_apps[index].name, nameRect, g_fBody, kText,
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        RECT appTitle = { rowRect.left + S(154), rowRect.top, rowRect.right - S(6), rowRect.bottom };
        DrawString(dc, g_apps[index].title, appTitle, g_fSmall, kMuted,
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    }

    if (g_appCount > visibleRows) {
        RECT track = { r.right - S(9), rowsTop + S(2), r.right - S(6),
                       rowsTop + visibleRows * rowHeight - S(2) };
        FillColor(dc, track, RGB(235, 239, 246));
        int thumbHeight = track.bottom - track.top;
        if (g_appCount > 0) {
            thumbHeight = (track.bottom - track.top) * visibleRows / g_appCount;
        }
        if (thumbHeight < S(18)) thumbHeight = S(18);
        int maxScroll = g_appCount - visibleRows;
        int offset = 0;
        if (maxScroll > 0) {
            offset = (track.bottom - track.top - thumbHeight) * g_pickerScroll / maxScroll;
        }
        RECT thumb = { track.left, track.top + offset, track.right, track.top + offset + thumbHeight };
        FillColor(dc, thumb, RGB(148, 163, 184));
    }

    int footerTop = r.bottom - GetPickerFooterHeight();
    RECT footer = { r.left, footerTop, r.right, r.bottom };
    FillColor(dc, footer, RGB(248, 250, 253));

    RECT clear = { r.left + S(10), footerTop + S(6), r.left + S(94), footerTop + S(30) };
    RoundFill(dc, clear, 5,
              (g_hover == HOVER_PICKER_CLEAR) ? kBluePale : RGB(248, 250, 253),
              kCardBorder);
    DrawString(dc, L"清除选择", clear, g_fSmall, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT done = { r.right - S(76), footerTop + S(6), r.right - S(10), footerTop + S(30) };
    RoundFill(dc, done, 5,
              (g_hover == HOVER_PICKER_DONE) ? kBlueHover : kBlue,
              (g_hover == HOVER_PICKER_DONE) ? kBlueHover : kBlue);
    DrawString(dc, g_pickerMode == 2 ? L"完成" : L"关闭", done, g_fSmall, RGB(255, 255, 255),
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static RECT GetBackgroundPanelRect()
{
    Layout l = GetLayout();
    int width = S(340);
    int height = S(kSpecialTheme ? 286 : 238);
    int right = kSpecialTheme ? S(778) : S(1138);
    RECT r = { right - width, l.backgroundButton.top - height - S(6),
               right, l.backgroundButton.top - S(6) };
    return r;
}

static RECT GetBackgroundSwatchRect(int index)
{
    RECT panel = GetBackgroundPanelRect();
    int column = index % 4;
    int row = index / 4;
    int x = panel.left + S(14) + column * S(80);
    int y = panel.top + S(64) + row * S(48);
    RECT r = { x, y, x + S(54), y + S(24) };
    return r;
}

static RECT GetBackgroundImageButtonRect()
{
    RECT panel = GetBackgroundPanelRect();
    RECT r = { panel.left + S(14), panel.bottom - S(42),
               panel.left + S(204), panel.bottom - S(12) };
    return r;
}

static RECT GetBackgroundResetButtonRect()
{
    RECT panel = GetBackgroundPanelRect();
    RECT r = { panel.left + S(214), panel.bottom - S(42),
               panel.right - S(14), panel.bottom - S(12) };
    return r;
}

static RECT GetBackgroundNameEditRect()
{
    RECT panel = GetBackgroundPanelRect();
    RECT r = { panel.left + S(64), panel.top + S(196),
               panel.left + S(244), panel.top + S(220) };
    return r;
}

static RECT GetBackgroundNameSaveRect()
{
    RECT panel = GetBackgroundPanelRect();
    RECT r = { panel.left + S(250), panel.top + S(196),
               panel.right - S(14), panel.top + S(220) };
    return r;
}

static void DrawBackgroundPanel(HDC dc)
{
    if (!g_bgPanelOpen) return;
    RECT panel = GetBackgroundPanelRect();
    RoundFill(dc, panel, 12, kCard, RGB(203, 213, 225));

    RECT title = { panel.left + S(14), panel.top + S(8), panel.right - S(34), panel.top + S(34) };
    DrawString(dc, L"背景设置", title, g_fBody, kText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT close = { panel.right - S(32), panel.top + S(8), panel.right - S(8), panel.top + S(32) };
    if (g_hover == HOVER_BG_PANEL_CLOSE) {
        RoundFill(dc, close, 5, kBluePale, kBlueBorder);
    }
    DrawString(dc, L"×", close, g_fWarnTitle,
               (g_hover == HOVER_BG_PANEL_CLOSE) ? kBlue : kMuted,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT presetLabel = { panel.left + S(14), panel.top + S(40), panel.right - S(14), panel.top + S(58) };
    DrawString(dc, L"纯色预设", presetLabel, g_fSmall, kMuted,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    for (int i = 0; i < kBackgroundPresetCount; ++i) {
        RECT swatch = GetBackgroundSwatchRect(i);
        COLORREF color = kBackgroundPresets[i].color;
        bool selected = !g_bgUseImage && g_bgPreset == i;
        RoundFill(dc, swatch, 6, color, selected ? kBlue : RGB(203, 213, 225));
        RECT nameRect = { swatch.left, swatch.bottom, swatch.right, swatch.bottom + S(18) };
        DrawString(dc, kBackgroundPresets[i].name, nameRect, g_fSmall,
                   selected ? kBlue : kMuted,
                   DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }

    RECT status = kSpecialTheme
                      ? RECT{ panel.left + S(14), panel.top + S(172),
                              panel.right - S(14), panel.top + S(190) }
                      : RECT{ panel.left + S(14), panel.bottom - S(64),
                              panel.right - S(14), panel.bottom - S(46) };
    wchar_t statusText[160] = {};
    if (g_bgUseImage) {
        StringCchCopyW(statusText, 160, L"当前：自定义图片（仅完整窗口）");
    } else {
        StringCchPrintfW(statusText, 160, L"当前：%ls · 纯色同步用于小窗/极简",
                         kBackgroundPresets[g_bgPreset].name);
    }
    DrawString(dc, statusText, status, g_fSmall, g_bgUseImage ? kBlue : kMuted,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    if (kSpecialTheme) {
        RECT nameLabel = { panel.left + S(14), panel.top + S(196),
                           panel.left + S(60), panel.top + S(220) };
        DrawString(dc, L"名称", nameLabel, g_fSmall, kTextSoft,
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        RECT save = GetBackgroundNameSaveRect();
        RoundFill(dc, save, 6,
                  (g_hover == HOVER_BG_NAME) ? kBluePale : RGB(248, 250, 253),
                  (g_hover == HOVER_BG_NAME) ? kBlueBorder : kCardBorder);
        DrawString(dc, L"保存名称", save, g_fSmall, kTextSoft,
                   DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        RECT watermarkNote = { panel.left + S(14), panel.top + S(228),
                               panel.right - S(14), panel.top + S(242) };
        DrawString(dc, L"水印：Jiuzhu@1335（固定）", watermarkNote, g_fSmall, kFaint,
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    }

    RECT image = GetBackgroundImageButtonRect();
    RoundFill(dc, image, 7,
              (g_hover == HOVER_BG_IMAGE) ? kBluePale : RGB(248, 250, 253),
              (g_hover == HOVER_BG_IMAGE) ? kBlueBorder : kCardBorder);
    DrawString(dc, L"选择图片…", image, g_fSmall, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT reset = GetBackgroundResetButtonRect();
    RoundFill(dc, reset, 7,
              (g_hover == HOVER_BG_RESET) ? kBluePale : RGB(248, 250, 253),
              (g_hover == HOVER_BG_RESET) ? kBlueBorder : kCardBorder);
    DrawString(dc, L"恢复默认", reset, g_fSmall, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void DrawInfoBanner(HDC dc)
{
    Layout l = GetLayout();
    RECT r = l.info;
    if (g_warning) {
        RoundFill(dc, r, 13, kAmberPale, kAmberBorder);
        RECT circle = { r.left + S(20), r.top + S(15), r.left + S(46), r.top + S(41) };
        HBRUSH brush = CreateSolidBrush(kAmber);
        HGDIOBJ oldBrush = SelectObject(dc, brush);
        HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
        Ellipse(dc, circle.left, circle.top, circle.right, circle.bottom);
        SelectObject(dc, oldBrush);
        SelectObject(dc, oldPen);
        DeleteObject(brush);
        RECT bang = { circle.left, circle.top + S(1), circle.right, circle.bottom };
        DrawString(dc, L"!", bang, g_fWarnTitle, RGB(255, 255, 255),
                   DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        RECT title = { r.left + S(58), r.top + S(7), r.right - S(18), r.top + S(27) };
        DrawString(dc, L"整理后内存仍高于阈值", title, g_fWarnTitle, kAmberText);
        RECT detail = { r.left + S(58), r.top + S(28), r.right - S(18), r.top + S(48) };
        DrawString(dc, g_warnDetail, detail, g_fWarnDetail, RGB(180, 83, 9),
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    } else {
        RoundFill(dc, r, 13, kBluePale, kBlueBorder);
        RECT circle = { r.left + S(20), r.top + S(15), r.left + S(46), r.top + S(41) };
        HBRUSH brush = CreateSolidBrush(RGB(59, 130, 246));
        HGDIOBJ oldBrush = SelectObject(dc, brush);
        HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
        Ellipse(dc, circle.left, circle.top, circle.right, circle.bottom);
        SelectObject(dc, oldBrush);
        SelectObject(dc, oldPen);
        DeleteObject(brush);
        RECT info = { circle.left, circle.top + S(1), circle.right, circle.bottom };
        DrawString(dc, L"i", info, g_fWarnTitle, RGB(255, 255, 255),
                   DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        RECT title = { r.left + S(58), r.top + S(7), r.right - S(18), r.top + S(27) };
        DrawString(dc, g_auto ? L"自动整理已开启" : L"自动整理未开启",
                   title, g_fWarnTitle, RGB(30, 58, 138));

        wchar_t detailText[240] = {};
        if (g_auto) {
            if (g_closeAuto) {
                StringCchPrintfW(detailText, 240,
                                 L"内存达到 %d%% 时自动整理，并关闭无窗口的后台启动器/更新器。",
                                 g_threshold);
            } else {
                StringCchPrintfW(detailText, 240,
                                 g_elevated
                                     ? L"内存达到 %d%% 时将自动整理 · 最小间隔 60 秒 · 已启用管理员深度清理"
                                     : L"内存达到 %d%% 时将自动整理 · 最小间隔 60 秒 · 管理员模式可清理待机缓存",
                                 g_threshold);
            }
        } else {
            StringCchPrintfW(detailText, 240,
                             g_closeAuto
                                 ? L"开启后，内存达到 %d%% 时将自动整理并关闭无窗口后台进程。"
                                 : L"开启后，内存达到 %d%% 时将自动整理，自动整理不会关闭程序。",
                             g_threshold);
        }
        RECT detail = { r.left + S(58), r.top + S(28), r.right - S(18), r.top + S(48) };
        DrawString(dc, detailText, detail, g_fWarnDetail, RGB(71, 91, 130),
                   DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    }
}

static void DrawFooter(HDC dc)
{
    Layout l = GetLayout();
    DrawString(dc, g_footerOwn, l.footer, g_fFooter, kFaint,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT center = l.footer;
    const wchar_t* centerText = (g_closeManual || g_closeAuto)
                                    ? L"关闭进程仅限无可见窗口的后台启动器/更新器"
                                    : L"整理仅回收工作集与待机缓存，不会关闭程序";
    COLORREF centerColor = kFaint;
    if (g_warning) {
        centerText = L"内存仍高于阈值，建议关闭大型程序或提升权限";
        centerColor = kRed;
    }
    DrawString(dc, centerText, center, g_fFooter, centerColor,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    RECT background = l.backgroundButton;
    DrawSurface(dc, background, 8,
                (g_hover == HOVER_BACKGROUND) ? kBluePale : RGB(248, 250, 253),
                (g_hover == HOVER_BACKGROUND) ? kBlueBorder : SurfaceBorder());
    DrawString(dc, L"背景", background, g_fSmall, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

static void DrawCompactChip(HDC dc, const RECT& rect, const wchar_t* label, bool on)
{
    COLORREF fill = on ? kGreenPale : RGB(247, 249, 252);
    COLORREF border = on ? kGreenBorder : SurfaceBorder();
    DrawSurface(dc, rect, 9, fill, border);

    RECT dot = { rect.left + S(10), rect.top + S(10),
                 rect.left + S(16), rect.top + S(16) };
    HBRUSH brush = CreateSolidBrush(on ? kGreen : RGB(184, 194, 211));
    HGDIOBJ oldBrush = SelectObject(dc, brush);
    HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
    Ellipse(dc, dot.left, dot.top, dot.right, dot.bottom);
    SelectObject(dc, oldBrush);
    SelectObject(dc, oldPen);
    DeleteObject(brush);

    RECT labelRect = { rect.left + S(22), rect.top, rect.right - S(44), rect.bottom };
    DrawString(dc, label, labelRect, g_fSmall, on ? RGB(6, 95, 70) : kTextSoft,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT stateRect = { rect.right - S(42), rect.top, rect.right - S(10), rect.bottom };
    DrawString(dc, on ? L"开" : L"关", stateRect, g_fSmall,
               on ? kGreen : kMuted,
               DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
}

static void DrawCompactMetric(HDC dc, int x, const wchar_t* label, const wchar_t* value,
                              COLORREF accent, bool alert)
{
    RECT dot = { S(x), S(49), S(x + 6), S(55) };
    HBRUSH brush = CreateSolidBrush(accent);
    HGDIOBJ oldBrush = SelectObject(dc, brush);
    HGDIOBJ oldPen = SelectObject(dc, GetStockObject(NULL_PEN));
    Ellipse(dc, dot.left, dot.top, dot.right, dot.bottom);
    SelectObject(dc, oldBrush);
    SelectObject(dc, oldPen);
    DeleteObject(brush);

    RECT labelRect = { S(x + 12), S(43), S(x + 82), S(59) };
    DrawString(dc, label, labelRect, g_fSmall, kMuted);
    RECT valueRect = { S(x), S(60), S(x + 82), S(94) };
    DrawString(dc, value, valueRect, g_fCompactValue, alert ? kRed : kText);
}

static void PaintCompactContent(HDC dc, int width, int height)
{
    RECT full = { 0, 0, width, height };
    bool tinted = HasTintedBackground();
    COLORREF compactBg = tinted ? SelectedBackgroundColor() : kBg;
    COLORREF compactCard = tinted ? SelectedBackgroundColor() : kCard;
    FillColor(dc, full, compactBg);

    CompactLayout l = GetCompactLayout();
    DrawSurface(dc, l.card, 14, compactCard,
                g_warning ? kAmberBorder : SurfaceBorder());
    DrawSpecialWatermark(dc, width, height);

    RECT icon = R(20, 16, 22, 22);
    RoundFill(dc, icon, 7, kBlue, kBlue);
    DrawSparkle(dc, icon.left + S(11), icon.top + S(11), S(6), RGB(255, 255, 255));

    RECT title = R(50, 12, 186, 24);
    DrawString(dc, kSpecialTheme ? g_displayName : L"内存整理", title, g_fSection, kText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    RECT minimal = l.minimalButton;
    COLORREF minimalBg = (g_hover == HOVER_MINIMAL) ? kBluePale : RGB(248, 250, 253);
    COLORREF minimalBorder = (g_hover == HOVER_MINIMAL) ? kBlueBorder : kCardBorder;
    DrawSurface(dc, minimal, 7, minimalBg, minimalBorder);
    DrawString(dc, L"极简", minimal, g_fSmall, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT expand = l.expandButton;
    COLORREF expandBg = (g_hover == HOVER_EXPAND) ? kBluePale : RGB(248, 250, 253);
    COLORREF expandBorder = (g_hover == HOVER_EXPAND) ? kBlueBorder : kCardBorder;
    DrawSurface(dc, expand, 7, expandBg, expandBorder);
    DrawString(dc, L"展开", expand, g_fSmall, kTextSoft,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT close = l.closeButton;
    COLORREF closeBg = (g_hover == HOVER_COMPACT_CLOSE) ? kRedPale : RGB(248, 250, 253);
    COLORREF closeBorder = (g_hover == HOVER_COMPACT_CLOSE) ? kRedBorder : kCardBorder;
    DrawSurface(dc, close, 7, closeBg, closeBorder);
    DrawString(dc, L"×", close, g_fWarnTitle,
               (g_hover == HOVER_COMPACT_CLOSE) ? kRed : kMuted,
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    wchar_t cpuText[16] = {};
    wchar_t memText[16] = {};
    wchar_t gpuText[16] = {};
    wchar_t fpsText[16] = {};
    StringCchPrintfW(cpuText, 16, L"%d%%", (int)std::lround(g_metrics.cpu));
    StringCchPrintfW(memText, 16, L"%d%%", g_metrics.memPercent);
    if (g_metrics.gpuValid) {
        StringCchPrintfW(gpuText, 16, L"%d%%", (int)std::lround(g_metrics.gpu));
    } else {
        StringCchCopyW(gpuText, 16, L"--");
    }
    if (g_fpsValid) {
        StringCchPrintfW(fpsText, 16, L"%d", g_fpsValue);
    } else {
        StringCchCopyW(fpsText, 16, L"--");
    }

#ifndef SPECIAL_VERSION
    DrawCompactMetric(dc, 20, L"CPU", cpuText, kAmber, false);
    DrawCompactMetric(dc, 150, L"内存", memText, kBlue, g_metrics.memPercent >= g_threshold);
    DrawCompactMetric(dc, 280, L"GPU", gpuText, kViolet, false);
    DrawCompactMetric(dc, 410, L"FPS", fpsText, kGreen, false);
    RECT divider1 = { S(142), S(44), S(143), S(94) };
    RECT divider2 = { S(272), S(44), S(273), S(94) };
    RECT divider3 = { S(402), S(44), S(403), S(94) };
#else
    DrawCompactMetric(dc, 20, L"CPU", cpuText, kAmber, false);
    DrawCompactMetric(dc, 110, L"内存", memText, kBlue, g_metrics.memPercent >= g_threshold);
    DrawCompactMetric(dc, 200, L"GPU", gpuText, kViolet, false);
    DrawCompactMetric(dc, 290, L"FPS", fpsText, kGreen, false);
    RECT divider1 = { S(105), S(44), S(106), S(94) };
    RECT divider2 = { S(195), S(44), S(196), S(94) };
    RECT divider3 = { S(285), S(44), S(286), S(94) };
#endif
    FillColor(dc, divider1, kSpecialTheme ? RGB(160, 174, 192) : RGB(237, 240, 246));
    FillColor(dc, divider2, kSpecialTheme ? RGB(160, 174, 192) : RGB(237, 240, 246));
    FillColor(dc, divider3, kSpecialTheme ? RGB(160, 174, 192) : RGB(237, 240, 246));

    RECT button = l.trimButton;
    COLORREF buttonBg = kBlue;
    if (g_busy) {
        buttonBg = RGB(165, 184, 232);
    } else if (g_pressedTrim) {
        buttonBg = kBlueHover;
    } else if (g_hover == HOVER_TRIM) {
        buttonBg = RGB(45, 110, 245);
    }
    COLORREF buttonBorder = g_busy ? RGB(165, 184, 232) : kBlue;
    DrawSurface(dc, button, 9, buttonBg, buttonBorder);
    DrawString(dc, g_busy ? L"整理中…" : L"整理内存",
               button, g_fBody, kSpecialTheme ? (g_busy ? kMuted : kBlue) : RGB(255, 255, 255),
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    wchar_t statusLine1[160] = {};
    wchar_t statusLine2[160] = {};
    COLORREF statusColor = kTextSoft;
    COLORREF statusColor2 = kMuted;
    if (g_warning) {
        StringCchCopyW(statusLine1, 160, L"内存仍高于阈值");
        StringCchPrintfW(statusLine2, 160, L"当前 %d%% · 阈值 %d%%",
                         g_metrics.memPercent, g_threshold);
        statusColor = kRed;
        statusColor2 = kAmberText;
    } else if (g_busy) {
        StringCchCopyW(statusLine1, 160, L"正在整理内存…");
        StringCchCopyW(statusLine2, 160, L"请稍候");
    } else {
        StringCchCopyW(statusLine1, 160, g_status1);
        StringCchCopyW(statusLine2, 160, g_status2);
        if (g_lastFreed > 10LL * 1024LL * 1024LL || g_lastClosed > 0) {
            statusColor2 = kGreen;
        }
    }
    RECT status1 = { S(134), S(103), width - S(14), S(117) };
    RECT status2 = { S(134), S(117), width - S(14), S(131) };
    DrawString(dc, statusLine1, status1, g_fSmall, statusColor,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    DrawString(dc, statusLine2, status2, g_fSmall, statusColor2,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    DrawCompactChip(dc, l.chip[0], L"自动整理", g_auto);
    DrawCompactChip(dc, l.chip[1], L"手动关闭进程", g_closeManual);
    DrawCompactChip(dc, l.chip[2], L"自动关闭进程", g_closeAuto);
    DrawCompactChip(dc, l.chip[3], L"腾讯游戏模式", g_aceMode);

#ifndef SPECIAL_VERSION
    RECT appMode = R(20, 198, 520, 16);
#else
    RECT appMode = R(20, 198, 340, 16);
#endif
    DrawString(dc, g_appModeText, appMode, g_fSmall,
               g_appMode ? kBlue : kMuted,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
#ifndef SPECIAL_VERSION
    DrawForegroundInfo(dc);
    DrawClipboardCard(dc, true);
    DrawQuickApps(dc);
#endif
}

static void PaintMinimalContent(HDC dc, int width, int height)
{
    bool tinted = HasTintedBackground();
    COLORREF barBackground = tinted ? SelectedBackgroundColor() : RGB(15, 23, 42);
    COLORREF primary = tinted ? kText : RGB(226, 232, 240);
    COLORREF mutedText = tinted ? kMuted : RGB(148, 163, 184);
    COLORREF accent = tinted ? RGB(180, 83, 9) : kAmber;
    COLORREF green = tinted ? RGB(4, 120, 87) : RGB(52, 211, 153);
    COLORREF red = tinted ? RGB(185, 28, 28) : RGB(248, 113, 113);
    COLORREF blue = tinted ? RGB(29, 78, 216) : RGB(147, 197, 253);

    RECT full = { 0, 0, width, height };
    FillColor(dc, full, barBackground);

    wchar_t fpsText[32] = {};
    wchar_t cpuText[32] = {};
    wchar_t memText[32] = {};
    wchar_t gpuText[32] = {};
    wchar_t aceText[32] = {};
    wchar_t autoText[64] = {};
    if (g_fpsValid) {
        StringCchPrintfW(fpsText, 32, L"FPS %d", g_fpsValue);
    } else {
        StringCchCopyW(fpsText, 32, L"FPS --");
    }
    StringCchPrintfW(cpuText, 32, L"CPU %d%%", (int)std::lround(g_metrics.cpu));
    StringCchPrintfW(memText, 32, L"内存 %d%%", g_metrics.memPercent);
    if (g_metrics.gpuValid) {
        StringCchPrintfW(gpuText, 32, L"GPU %d%%", (int)std::lround(g_metrics.gpu));
    } else {
        StringCchCopyW(gpuText, 32, L"GPU --");
    }
    StringCchPrintfW(aceText, 32, g_aceMode ? L"ACE 开" : L"ACE 关");
    StringCchPrintfW(autoText, 64, g_auto ? L"自动 开 %d%%" : L"自动 关 %d%%", g_threshold);

    RECT fpsRect = R(14, 0, 70, 32);
    RECT cpuRect = R(94, 0, 70, 32);
    RECT memRect = R(172, 0, 70, 32);
    RECT gpuRect = R(250, 0, 70, 32);
    RECT aceRect = R(328, 0, 70, 32);
    RECT autoRect = R(410, 0, 120, 32);
    RECT appModeRect = R(540, 0, 250, 32);
    DrawString(dc, fpsText, fpsRect, g_fBody, accent, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    DrawString(dc, cpuText, cpuRect, g_fBody, primary, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    DrawString(dc, memText, memRect, g_fBody,
               (g_metrics.memPercent >= g_threshold) ? red : primary,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    DrawString(dc, gpuText, gpuRect, g_fBody, primary, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    DrawString(dc, aceText, aceRect, g_fBody,
               g_aceMode ? green : mutedText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    DrawString(dc, autoText, autoRect, g_fBody,
               g_auto ? green : mutedText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    DrawString(dc, g_appModeText, appModeRect, g_fBody,
               g_appMode ? blue : mutedText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
#ifndef SPECIAL_VERSION
    RECT foregroundRect = R(800, 0, 158, 32);
    RECT quickRect = R(968, 0, 96, 32);
    DrawString(dc, g_foregroundText, foregroundRect, g_fBody, mutedText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    DrawString(dc, g_quickText, quickRect, g_fBody, mutedText,
               DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
#endif

    RECT expand = GetMinimalLayout().expandButton;
    RoundFill(dc, expand, 5,
              tinted ? ((g_hover == HOVER_MINIMAL_EXPAND) ? kBluePale : RGB(255, 255, 255)) :
                       ((g_hover == HOVER_MINIMAL_EXPAND) ? RGB(30, 58, 95) : RGB(30, 41, 59)),
              tinted ? ((g_hover == HOVER_MINIMAL_EXPAND) ? kBlueBorder : RGB(203, 213, 225)) :
                       ((g_hover == HOVER_MINIMAL_EXPAND) ? RGB(59, 130, 246) : RGB(51, 65, 85)));
    DrawString(dc, L"展开", expand, g_fSmall,
               tinted ? ((g_hover == HOVER_MINIMAL_EXPAND) ? kBlue : kTextSoft) :
                        ((g_hover == HOVER_MINIMAL_EXPAND) ? RGB(255, 255, 255) : RGB(203, 213, 225)),
               DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT underline = { 0, height - S(2), width, height };
    FillColor(dc, underline, g_warning ? RGB(239, 68, 68) : RGB(37, 99, 235));
}

static void PaintContent(HDC dc, int width, int height)
{
    if (g_minimal) {
        PaintMinimalContent(dc, width, height);
        return;
    }
    if (g_compact) {
        PaintCompactContent(dc, width, height);
        return;
    }
    PaintAppBackground(dc, width, height);
    DrawSpecialWatermark(dc, width, height);

    DrawHeader(dc);

    Layout l = GetLayout();
    DrawMetricCard(dc, l.card[0], 0);
    DrawMetricCard(dc, l.card[1], 1);
    DrawMetricCard(dc, l.card[2], 2);
    DrawMetricCard(dc, l.card[3], 3);

    DrawControlCard(dc);
    DrawTencentCard(dc);
    DrawAppModeBar(dc);
#ifndef SPECIAL_VERSION
    DrawClipboardCard(dc, false);
    DrawQuickApps(dc);
    DrawForegroundInfo(dc);
#endif
    DrawFooter(dc);
    if (g_pickerOpen) DrawAppPicker(dc);
    if (g_bgPanelOpen) DrawBackgroundPanel(dc);
}

// ---------------------------------------------------------------------------
// Window mechanics
// ---------------------------------------------------------------------------
static void EnsureBackBuffer(HDC reference, int width, int height)
{
    if (!g_memDC) {
        g_memDC = CreateCompatibleDC(reference);
    }
    if (!g_memDC) return;
    if (!g_backBmp || g_bufW != width || g_bufH != height) {
        if (g_backBmp) {
            SelectObject(g_memDC, g_oldBmp);
            DeleteObject(g_backBmp);
            g_backBmp = nullptr;
        }
        g_backBmp = CreateCompatibleBitmap(reference, width, height);
        if (g_backBmp) {
            g_oldBmp = (HBITMAP)SelectObject(g_memDC, g_backBmp);
            g_bufW = width;
            g_bufH = height;
        }
    }
}

static void WindowSizeForDpi(int dpi, int* outW, int* outH)
{
    int clientW = MulDiv(CurrentDesignWidth(), dpi, 96);
    int clientH = MulDiv(CurrentDesignHeight(), dpi, 96);
    RECT r = { 0, 0, clientW, clientH };
    DWORD style = (DWORD)GetWindowLongPtrW(g_hwnd, GWL_STYLE);
    DWORD exStyle = (DWORD)GetWindowLongPtrW(g_hwnd, GWL_EXSTYLE);

    typedef BOOL(WINAPI* AdjustRectForDpiFn)(LPRECT, DWORD, BOOL, DWORD, UINT);
    static AdjustRectForDpiFn fn = nullptr;
    static bool loaded = false;
    if (!loaded) {
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        fn = (AdjustRectForDpiFn)GetProcAddress(user32, "AdjustWindowRectExForDpi");
        loaded = true;
    }
    if (fn) {
        fn(&r, style, FALSE, exStyle, (UINT)dpi);
    } else {
        AdjustWindowRectEx(&r, style, FALSE, exStyle);
    }
    *outW = r.right - r.left;
    *outH = r.bottom - r.top;
}

static void ResizeForCurrentDpi(bool center)
{
    if (!g_hwnd) return;
    int width = 0, height = 0;
    WindowSizeForDpi(g_dpi, &width, &height);
    RECT window = {};
    GetWindowRect(g_hwnd, &window);
    int x = window.left;
    int y = window.top;
    if (center) {
        RECT work = {};
        SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
        x = work.left + ((work.right - work.left) - width) / 2;
        y = work.top + ((work.bottom - work.top) - height) / 2;
    }
    SetWindowPos(g_hwnd, nullptr, x, y, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
}

static void PositionFloatingWindow(bool compact)
{
    if (!g_hwnd) return;
    int width = 0, height = 0;
    WindowSizeForDpi(g_dpi, &width, &height);
    HMONITOR monitor = MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTONEAREST);
    MONITORINFO info = {};
    info.cbSize = sizeof(info);
    RECT work = {};
    if (monitor && GetMonitorInfoW(monitor, &info)) {
        work = info.rcWork;
    } else {
        SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
    }
    int x = work.left + ((work.right - work.left) - width) / 2;
    int y = work.top;
    (void)compact;
    SetWindowPos(g_hwnd, HWND_TOPMOST, x, y, width, height,
                 SWP_FRAMECHANGED | SWP_SHOWWINDOW);
}

static void PositionCompactWindow()
{
    PositionFloatingWindow(true);
}

static void PositionMinimalWindow()
{
    PositionFloatingWindow(false);
}

static int HitTest(int x, int y)
{
    if (g_minimal) {
        MinimalLayout m = GetMinimalLayout();
        if (PointIn(m.expandButton, x, y)) return HOVER_MINIMAL_EXPAND;
        return HOVER_NONE;
    }
    if (g_compact) {
        CompactLayout c = GetCompactLayout();
        if (!g_busy && PointIn(c.trimButton, x, y)) return HOVER_TRIM;
        if (PointIn(c.minimalButton, x, y)) return HOVER_MINIMAL;
        if (PointIn(c.expandButton, x, y)) return HOVER_EXPAND;
        if (PointIn(c.closeButton, x, y)) return HOVER_COMPACT_CLOSE;
#ifndef SPECIAL_VERSION
        if (PointIn(c.clipboardCard, x, y)) return HOVER_CLIPBOARD;
        for (int i = 0; i < 3; ++i) {
            if (PointIn(c.quickButton[i], x, y)) return HOVER_QUICK;
        }
#endif
        return HOVER_NONE;
    }

    Layout l = GetLayout();
    if (!g_busy && PointIn(l.trimButton, x, y)) return HOVER_TRIM;
    if (PointIn(l.toggle, x, y)) return HOVER_TOGGLE;
    if (PointIn(l.toggleCloseAuto, x, y)) return HOVER_CLOSE_AUTO;
    if (PointIn(l.toggleCloseManual, x, y)) return HOVER_CLOSE_MANUAL;
    if (PointIn(l.aceToggle, x, y)) return HOVER_ACE_TOGGLE;
    if (PointIn(l.aceSettings, x, y)) return HOVER_ACE_SETTINGS;
    if (PointIn(l.compactButton, x, y)) return HOVER_COMPACT;
    if (PointIn(l.minimalButton, x, y)) return HOVER_MINIMAL;
    if (PointIn(l.singleSwitch, x, y)) return HOVER_SINGLE_SWITCH;
    if (PointIn(l.singleField, x, y)) return HOVER_SINGLE_FIELD;
    if (PointIn(l.multiSwitch, x, y)) return HOVER_MULTI_SWITCH;
    if (PointIn(l.multiField, x, y)) return HOVER_MULTI_FIELD;
    if (PointIn(l.backgroundButton, x, y)) return HOVER_BACKGROUND;
    if (PointIn(l.sliderHit, x, y) || PointIn(l.slider, x, y)) return HOVER_SLIDER;
    if (!g_elevated && PointIn(l.adminChip, x, y)) return HOVER_ADMIN;
#ifndef SPECIAL_VERSION
    if (PointIn(l.clipboardCard, x, y)) return HOVER_CLIPBOARD;
    if (PointIn(l.quickCard, x, y)) return HOVER_QUICK;
#endif
    return HOVER_NONE;
}

static void UpdateThresholdFromMouse(int x)
{
    Layout l = GetLayout();
    int width = l.slider.right - l.slider.left;
    if (width <= 0) return;
    double fraction = (double)(x - l.slider.left) / (double)width;
    if (fraction < 0.0) fraction = 0.0;
    if (fraction > 1.0) fraction = 1.0;
    int value = kMinThreshold + (int)std::lround((kMaxThreshold - kMinThreshold) * fraction);
    if (value < kMinThreshold) value = kMinThreshold;
    if (value > kMaxThreshold) value = kMaxThreshold;
    if (value != g_threshold) {
        g_threshold = value;
        if (g_metrics.memPercent < g_threshold) {
            g_warning = false;
            g_autoBlocked = false;
        }
        InvalidateRect(g_hwnd, nullptr, FALSE);
    }
}

static void ToggleAuto()
{
    g_auto = !g_auto;
    g_autoBlocked = false;
    SaveSettings();
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ToggleCloseAuto()
{
    g_closeAuto = !g_closeAuto;
    SaveSettings();
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ToggleCloseManual()
{
    g_closeManual = !g_closeManual;
    SaveSettings();
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ToggleAceMode()
{
    g_aceMode = !g_aceMode;
    SaveSettings();
    if (g_aceMode) {
        g_aceNextScan = 0;
        g_aceForceApply = true;
    } else {
        RestoreAceProcesses();
    }
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void SetCompactMode(bool compact)
{
    if (g_compact == compact && !g_minimal) return;
    g_compact = compact;
    g_minimal = false;
    g_hover = HOVER_NONE;
    g_dragging = false;
    g_compactDragging = false;
    g_pressedTrim = false;
    g_pressedCompact = false;
    g_pressedMinimal = false;
    g_pressedSingleSwitch = false;
    g_pressedMultiSwitch = false;
    g_pressedSingleField = false;
    g_pressedMultiField = false;
    g_pressedBackground = false;
    g_pressedExpand = false;
    g_pressedCompactClose = false;
    g_pressedMinimalExpand = false;
    g_pickerOpen = false;
    g_pickerHoverRow = -1;
    g_bgPanelOpen = false;
    HideNameEditor();

    if (compact) {
        SetWindowLongPtrW(g_hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
        SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, WS_EX_TOOLWINDOW);
        if (kSpecialTheme) {
            wchar_t title[160] = {};
            StringCchPrintfW(title, 160, L"%ls · 置顶小窗", g_displayName);
            SetWindowTextW(g_hwnd, title);
        } else {
            SetWindowTextW(g_hwnd, L"内存整理 · 置顶小窗");
        }
        PositionCompactWindow();
    } else {
        SetWindowLongPtrW(g_hwnd, GWL_STYLE,
                          WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_VISIBLE);
        SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, 0);
        SetWindowTextW(g_hwnd, kSpecialTheme ? g_displayName : kWindowTitle);
        SetWindowPos(g_hwnd, HWND_NOTOPMOST, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE |
                     SWP_FRAMECHANGED | SWP_SHOWWINDOW);
        ShowWindow(g_hwnd, SW_SHOW);
        ResizeForCurrentDpi(true);
        SetForegroundWindow(g_hwnd);
    }
    InvalidateRect(g_hwnd, nullptr, TRUE);
}

static void SetMinimalMode();

static void HideNameEditor()
{
    if (g_nameEdit) ShowWindow(g_nameEdit, SW_HIDE);
}

static void CloseBackgroundPanel()
{
    g_bgPanelOpen = false;
    g_hover = HOVER_NONE;
    HideNameEditor();
    if (g_hwnd) SetFocus(g_hwnd);
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ShowNameEditor()
{
    if (!kSpecialTheme || !g_hwnd) return;
    if (!g_nameEdit) {
        g_nameEdit = CreateWindowExW(0, L"EDIT", g_displayName,
                                     WS_CHILD | ES_AUTOHSCROLL | WS_BORDER,
                                     0, 0, 0, 0, g_hwnd, (HMENU)1001,
                                     GetModuleHandleW(nullptr), nullptr);
        if (!g_nameEdit) return;
        SendMessageW(g_nameEdit, WM_SETFONT, (WPARAM)g_fBody, TRUE);
    }
    RECT edit = GetBackgroundNameEditRect();
    SetWindowTextW(g_nameEdit, g_displayName);
    SetWindowPos(g_nameEdit, HWND_TOP, edit.left, edit.top,
                 edit.right - edit.left, edit.bottom - edit.top,
                 SWP_SHOWWINDOW);
}

static void SaveDisplayName()
{
    if (!g_nameEdit) return;
    wchar_t text[64] = {};
    GetWindowTextW(g_nameEdit, text, 64);
    wchar_t* start = text;
    while (*start == L' ' || *start == L'\t') ++start;
    wchar_t* end = start + wcslen(start);
    while (end > start && (end[-1] == L' ' || end[-1] == L'\t')) --end;
    *end = 0;
    if (start != text) {
        StringCchCopyW(g_displayName, 64, start);
    } else {
        StringCchCopyW(g_displayName, 64, text);
    }
    if (!g_displayName[0]) StringCchCopyW(g_displayName, 64, L"内存整理助手");
    SaveSettings();
    if (g_hwnd) SetWindowTextW(g_hwnd, g_displayName);
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void OpenBackgroundPanel()
{
    if (g_pickerOpen) CloseAppPicker();
    g_bgPanelOpen = true;
    g_hover = HOVER_NONE;
    if (kSpecialTheme) ShowNameEditor();
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ChooseBackgroundImage()
{
    wchar_t file[1024] = {};
    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_hwnd;
    ofn.lpstrFilter = L"图片 (*.png;*.jpg;*.jpeg;*.bmp;*.gif)\0*.png;*.jpg;*.jpeg;*.bmp;*.gif\0所有文件 (*.*)\0*.*\0\0";
    ofn.lpstrFile = file;
    ofn.nMaxFile = 1024;
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;
    if (!GetOpenFileNameW(&ofn)) return;

    wchar_t target[1024] = {};
    wchar_t localAppData[1024] = {};
    DWORD length = GetEnvironmentVariableW(L"LOCALAPPDATA", localAppData, 1024);
    if (length > 0 && length < 1024) {
        wchar_t directory[1024] = {};
        StringCchPrintfW(directory, 1024, L"%ls\\MemoryAssist", localAppData);
        CreateDirectoryW(directory, nullptr);
        const wchar_t* extension = wcsrchr(file, L'.');
        if (!extension || wcslen(extension) > 8) extension = L".img";
        StringCchPrintfW(target, 1024, L"%ls\\background%ls", directory, extension);
        if (CopyFileW(file, target, FALSE)) {
            StringCchCopyW(g_bgImagePath, 1024, target);
        } else {
            StringCchCopyW(g_bgImagePath, 1024, file);
        }
    } else {
        StringCchCopyW(g_bgImagePath, 1024, file);
    }

    g_bgUseImage = true;
    FreeBackgroundBitmap();
    SaveSettings();
    g_bgPanelOpen = false;
    HideNameEditor();
    SetFocus(g_hwnd);
    InvalidateRect(g_hwnd, nullptr, TRUE);
}

static void SetAppMode(int mode)
{
    if (mode < 0) mode = 0;
    if (mode > 2) mode = 2;
    if (g_appMode == mode) return;
    g_appMode = mode;
    g_appModeForceApply = true;
    g_appModeNextScan = 0;
    if (mode == 0) RestoreAppPriorities();
    SaveSettings();
    UpdateAppModeText();
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void SelectSingleApp(const wchar_t* path)
{
    StringCchCopyW(g_singleAppPath, 512, path ? path : L"");
    RebuildAppModeDisplay();
    SaveSettings();
    g_appModeForceApply = true;
    g_appModeNextScan = 0;
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ToggleMultiApp(const wchar_t* path)
{
    if (!path || !path[0]) return;
    int found = -1;
    for (int i = 0; i < g_multiCount; ++i) {
        if (SamePath(g_multiPaths[i], path)) {
            found = i;
            break;
        }
    }
    if (found >= 0) {
        for (int i = found; i < g_multiCount - 1; ++i) {
            StringCchCopyW(g_multiPaths[i], 512, g_multiPaths[i + 1]);
        }
        --g_multiCount;
        g_multiPaths[g_multiCount][0] = 0;
    } else if (g_multiCount < 12) {
        StringCchCopyW(g_multiPaths[g_multiCount], 512, path);
        ++g_multiCount;
    }
    RebuildAppModeDisplay();
    SaveSettings();
    g_appModeForceApply = true;
    g_appModeNextScan = 0;
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void ClearAppPickerSelections()
{
    if (g_pickerMode == 1) {
        SelectSingleApp(L"");
    } else {
        g_multiCount = 0;
        for (int i = 0; i < 12; ++i) g_multiPaths[i][0] = 0;
        RebuildAppModeDisplay();
        SaveSettings();
        g_appModeForceApply = true;
        g_appModeNextScan = 0;
        InvalidateRect(g_hwnd, nullptr, FALSE);
    }
    for (int i = 0; i < g_appCount; ++i) g_pickerChecked[i] = false;
}

static void OpenAppPicker(int mode)
{
    if (g_bgPanelOpen) CloseBackgroundPanel();
    EnumerateVisibleApps();
    g_pickerMode = mode;
    g_pickerScroll = 0;
    g_pickerHoverRow = -1;
    for (int i = 0; i < g_appCount; ++i) {
        g_pickerChecked[i] = (mode == 2) && IsMultiPathSelected(g_apps[i].path);
    }
    g_pickerOpen = true;
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static void CloseAppPicker()
{
    g_pickerOpen = false;
    g_pickerHoverRow = -1;
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static RECT GetPickerRect()
{
    Layout l = GetLayout();
    RECT anchor = (g_pickerMode == 1) ? l.singleField : l.multiField;
    int width = S(340);
    int height = S(306);
    int x = anchor.left;
    if (x + width > S(778)) x = S(778) - width;
    int y = anchor.top - height - S(6);
    if (y < S(8)) y = anchor.bottom + S(6);
    RECT r = { x, y, x + width, y + height };
    return r;
}

static int GetPickerRowHeight()
{
    return S(30);
}

static int GetPickerHeaderHeight()
{
    return S(36);
}

static int GetPickerFooterHeight()
{
    return S(36);
}

static int GetPickerVisibleRows()
{
    RECT r = GetPickerRect();
    int available = (r.bottom - r.top) - GetPickerHeaderHeight() - GetPickerFooterHeight();
    return available / GetPickerRowHeight();
}

static int PickerRowAt(int x, int y)
{
    if (!g_pickerOpen) return -1;
    RECT r = GetPickerRect();
    if (x < r.left || x >= r.right) return -1;
    int rowsTop = r.top + GetPickerHeaderHeight();
    int rowsBottom = rowsTop + GetPickerVisibleRows() * GetPickerRowHeight();
    if (y < rowsTop || y >= rowsBottom) return -1;
    int row = g_pickerScroll + (y - rowsTop) / GetPickerRowHeight();
    if (row < 0 || row >= g_appCount) return -1;
    return row;
}

static bool PickerContains(int x, int y)
{
    if (!g_pickerOpen) return false;
    RECT r = GetPickerRect();
    return x >= r.left && x < r.right && y >= r.top && y < r.bottom;
}

static void ShowWindowModeMenu(HWND hwnd)
{
    HMENU menu = CreatePopupMenu();
    if (!menu) return;
    UINT flagsFull = MF_STRING | ((!g_compact && !g_minimal) ? MF_CHECKED : 0);
    UINT flagsCompact = MF_STRING | (g_compact ? MF_CHECKED : 0);
    UINT flagsMinimal = MF_STRING | (g_minimal ? MF_CHECKED : 0);
    AppendMenuW(menu, flagsFull, 4001, L"完整界面");
    AppendMenuW(menu, flagsCompact, 4002, L"小窗模式");
    AppendMenuW(menu, flagsMinimal, 4003, L"极简模式");
    AppendMenuW(menu, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(menu, MF_STRING, 4004, L"退出");

    POINT cursor = {};
    GetCursorPos(&cursor);
    int command = (int)TrackPopupMenu(menu, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY,
                                      cursor.x, cursor.y, 0, hwnd, nullptr);
    DestroyMenu(menu);

    if (command == 4001) SetCompactMode(false);
    else if (command == 4002) SetCompactMode(true);
    else if (command == 4003) SetMinimalMode();
    else if (command == 4004) PostMessageW(hwnd, WM_CLOSE, 0, 0);
}

static void SetMinimalMode()
{
    if (g_minimal) return;
    g_minimal = true;
    g_compact = false;
    g_hover = HOVER_NONE;
    g_dragging = false;
    g_compactDragging = false;
    g_pressedTrim = false;
    g_pressedCompact = false;
    g_pressedMinimal = false;
    g_pressedSingleSwitch = false;
    g_pressedMultiSwitch = false;
    g_pressedSingleField = false;
    g_pressedMultiField = false;
    g_pressedBackground = false;
    g_pressedExpand = false;
    g_pressedCompactClose = false;
    g_pressedMinimalExpand = false;
    g_pickerOpen = false;
    g_pickerHoverRow = -1;
    g_bgPanelOpen = false;
    HideNameEditor();

    SetWindowLongPtrW(g_hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
    SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, WS_EX_TOOLWINDOW);
    if (kSpecialTheme) {
        wchar_t title[160] = {};
        StringCchPrintfW(title, 160, L"%ls · 极简", g_displayName);
        SetWindowTextW(g_hwnd, title);
    } else {
        SetWindowTextW(g_hwnd, L"内存整理 · 极简");
    }
    PositionMinimalWindow();
    InvalidateRect(g_hwnd, nullptr, TRUE);
}

static void AceSettingsChanged()
{
    SaveSettings();
    g_aceForceApply = true;
    g_aceNextScan = 0;
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static HWND AddSettingsControl(HWND parent, const wchar_t* className, const wchar_t* text,
                               DWORD style, int x, int y, int w, int h, int id, HFONT font)
{
    HWND control = CreateWindowExW(0, className, text, WS_CHILD | WS_VISIBLE | style,
                                   S(x), S(y), S(w), S(h), parent, (HMENU)(INT_PTR)id,
                                   GetModuleHandleW(nullptr), nullptr);
    if (control && font) {
        SendMessageW(control, WM_SETFONT, (WPARAM)font, TRUE);
    }
    return control;
}

static void SyncAceSettingsControls(HWND hwnd)
{
    SendDlgItemMessageW(hwnd, IDC_ACE_PRIORITY_LOW, BM_SETCHECK,
                        g_acePriority == 0 ? BST_CHECKED : BST_UNCHECKED, 0);
    SendDlgItemMessageW(hwnd, IDC_ACE_PRIORITY_IDLE, BM_SETCHECK,
                        g_acePriority == 1 ? BST_CHECKED : BST_UNCHECKED, 0);
    SendDlgItemMessageW(hwnd, IDC_ACE_ECO, BM_SETCHECK,
                        g_aceEcoQos ? BST_CHECKED : BST_UNCHECKED, 0);
    SendDlgItemMessageW(hwnd, IDC_ACE_IO, BM_SETCHECK,
                        g_aceIoPriority ? BST_CHECKED : BST_UNCHECKED, 0);
    SendDlgItemMessageW(hwnd, IDC_ACE_MEMORY, BM_SETCHECK,
                        g_aceMemoryPriority ? BST_CHECKED : BST_UNCHECKED, 0);
    SendDlgItemMessageW(hwnd, IDC_ACE_TRIM, BM_SETCHECK,
                        g_aceTrimWorkingSet ? BST_CHECKED : BST_UNCHECKED, 0);
    SendDlgItemMessageW(hwnd, IDC_ACE_AFFINITY, BM_SETCHECK,
                        g_aceAffinity ? BST_CHECKED : BST_UNCHECKED, 0);
}

static LRESULT CALLBACK AceSettingsProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
    case WM_CREATE:
        g_aceSettingsWindow = hwnd;
        g_fSettingsTitle = CreateFontW(-MulDiv(14, g_dpi, 72), 0, 0, 0, 600, FALSE, FALSE, FALSE,
                                       DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                       CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
                                       L"Microsoft YaHei UI");
        g_fSettingsSection = CreateFontW(-MulDiv(10, g_dpi, 72), 0, 0, 0, 600, FALSE, FALSE, FALSE,
                                         DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                         CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
                                         L"Microsoft YaHei UI");
        g_fSettingsBody = CreateFontW(-MulDiv(9, g_dpi, 72), 0, 0, 0, 400, FALSE, FALSE, FALSE,
                                      DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                      CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
                                      L"Microsoft YaHei UI");
        g_fSettingsSmall = CreateFontW(-MulDiv(8, g_dpi, 72), 0, 0, 0, 400, FALSE, FALSE, FALSE,
                                       DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                                       CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
                                       L"Microsoft YaHei UI");

        AddSettingsControl(hwnd, L"STATIC", L"腾讯游戏模式设置", SS_LEFT,
                           24, 16, 452, 28, 0, g_fSettingsTitle);
        AddSettingsControl(hwnd, L"STATIC",
                           L"仅调整 ACE 进程的 CPU、I/O、内存优先级和工作集，不会结束、挂起或注入 ACE。\n"
                           L"修改反作弊进程的资源调度可能违反游戏用户协议，请自行评估账号风险。",
                           SS_LEFT, 24, 50, 452, 44, 0, g_fSettingsBody);

        AddSettingsControl(hwnd, L"STATIC", L"CPU 优先级", SS_LEFT,
                           24, 102, 300, 20, 0, g_fSettingsSection);
        AddSettingsControl(hwnd, L"BUTTON", L"低于正常", BS_AUTORADIOBUTTON | WS_GROUP,
                           40, 126, 260, 24, IDC_ACE_PRIORITY_LOW, g_fSettingsBody);
        AddSettingsControl(hwnd, L"BUTTON", L"最低（推荐）", BS_AUTORADIOBUTTON,
                           40, 152, 260, 24, IDC_ACE_PRIORITY_IDLE, g_fSettingsBody);

        AddSettingsControl(hwnd, L"STATIC", L"限制项", SS_LEFT,
                           24, 190, 300, 20, 0, g_fSettingsSection);
        AddSettingsControl(hwnd, L"BUTTON", L"启用效率模式（EcoQoS，降低 CPU 调度优先级）",
                           BS_AUTOCHECKBOX, 40, 214, 430, 24, IDC_ACE_ECO, g_fSettingsBody);
        AddSettingsControl(hwnd, L"BUTTON", L"降低磁盘 I/O 优先级",
                           BS_AUTOCHECKBOX, 40, 240, 430, 24, IDC_ACE_IO, g_fSettingsBody);
        AddSettingsControl(hwnd, L"BUTTON", L"降低内存优先级",
                           BS_AUTOCHECKBOX, 40, 266, 430, 24, IDC_ACE_MEMORY, g_fSettingsBody);
        AddSettingsControl(hwnd, L"BUTTON", L"每 5 秒整理 ACE 工作集",
                           BS_AUTOCHECKBOX, 40, 292, 430, 24, IDC_ACE_TRIM, g_fSettingsBody);
        AddSettingsControl(hwnd, L"BUTTON", L"绑定到最后一个 CPU 核心（实验性，可能影响稳定性）",
                           BS_AUTOCHECKBOX, 40, 318, 440, 24, IDC_ACE_AFFINITY, g_fSettingsBody);

        AddSettingsControl(hwnd, L"STATIC",
                           L"提示：仅调整用户态 ACE 进程；SGuardSvc64 等系统级组件需管理员权限。\n"
                           L"ACE-BASE.sys 等内核驱动无法通过此方式限制。",
                           SS_LEFT, 24, 346, 452, 36, 0, g_fSettingsSmall);

        AddSettingsControl(hwnd, L"BUTTON", L"恢复默认", BS_PUSHBUTTON,
                           24, 392, 120, 32, IDC_ACE_RESET, g_fSettingsBody);
        AddSettingsControl(hwnd, L"BUTTON", L"完成", BS_DEFPUSHBUTTON,
                           352, 392, 124, 32, IDC_ACE_DONE, g_fSettingsBody);

        SyncAceSettingsControls(hwnd);
        return 0;

    case WM_COMMAND: {
        int id = LOWORD(wParam);
        if (HIWORD(wParam) != BN_CLICKED) break;
        if (id == IDC_ACE_PRIORITY_LOW) {
            g_acePriority = 0;
            AceSettingsChanged();
        } else if (id == IDC_ACE_PRIORITY_IDLE) {
            g_acePriority = 1;
            AceSettingsChanged();
        } else if (id == IDC_ACE_ECO || id == IDC_ACE_IO || id == IDC_ACE_MEMORY ||
                   id == IDC_ACE_TRIM || id == IDC_ACE_AFFINITY) {
            bool checked = IsDlgButtonChecked(hwnd, id) == BST_CHECKED;
            if (id == IDC_ACE_ECO) g_aceEcoQos = checked;
            if (id == IDC_ACE_IO) g_aceIoPriority = checked;
            if (id == IDC_ACE_MEMORY) g_aceMemoryPriority = checked;
            if (id == IDC_ACE_TRIM) g_aceTrimWorkingSet = checked;
            if (id == IDC_ACE_AFFINITY) g_aceAffinity = checked;
            AceSettingsChanged();
        } else if (id == IDC_ACE_RESET) {
            g_acePriority = 1;
            g_aceEcoQos = true;
            g_aceIoPriority = true;
            g_aceMemoryPriority = true;
            g_aceTrimWorkingSet = true;
            g_aceAffinity = false;
            SyncAceSettingsControls(hwnd);
            AceSettingsChanged();
        } else if (id == IDC_ACE_DONE) {
            DestroyWindow(hwnd);
        }
        return 0;
    }

    case WM_CTLCOLORSTATIC: {
        HDC dc = (HDC)wParam;
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, RGB(55, 65, 85));
        return (LRESULT)GetStockObject(WHITE_BRUSH);
    }

    case WM_CTLCOLORBTN: {
        HDC dc = (HDC)wParam;
        SetBkMode(dc, TRANSPARENT);
        return (LRESULT)GetStockObject(WHITE_BRUSH);
    }

    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE) {
            DestroyWindow(hwnd);
            return 0;
        }
        break;

    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        if (g_fSettingsTitle) { DeleteObject(g_fSettingsTitle); g_fSettingsTitle = nullptr; }
        if (g_fSettingsSection) { DeleteObject(g_fSettingsSection); g_fSettingsSection = nullptr; }
        if (g_fSettingsBody) { DeleteObject(g_fSettingsBody); g_fSettingsBody = nullptr; }
        if (g_fSettingsSmall) { DeleteObject(g_fSettingsSmall); g_fSettingsSmall = nullptr; }
        g_aceSettingsWindow = nullptr;
        if (g_hwnd) {
            EnableWindow(g_hwnd, TRUE);
            SetForegroundWindow(g_hwnd);
            SetFocus(g_hwnd);
            SetProcessWorkingSetSize(GetCurrentProcess(), (SIZE_T)-1, (SIZE_T)-1);
            SampleMemory();
            InvalidateRect(g_hwnd, nullptr, FALSE);
        }
        return 0;
    }
    return DefWindowProcW(hwnd, message, wParam, lParam);
}

static void OpenAceSettings()
{
    if (g_aceSettingsWindow) {
        SetForegroundWindow(g_aceSettingsWindow);
        return;
    }

    static bool registered = false;
    HINSTANCE instance = GetModuleHandleW(nullptr);
    if (!registered) {
        WNDCLASSEXW wc = {};
        wc.cbSize = sizeof(wc);
        wc.style = CS_DBLCLKS;
        wc.lpfnWndProc = AceSettingsProc;
        wc.hInstance = instance;
        wc.hIcon = (HICON)LoadImageW(instance, MAKEINTRESOURCEW(101), IMAGE_ICON,
                                     GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON),
                                     LR_DEFAULTCOLOR);
        if (!wc.hIcon) wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
        wc.hIconSm = wc.hIcon;
        wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        wc.lpszClassName = kAceSettingsClass;
        if (!RegisterClassExW(&wc)) return;
        registered = true;
    }

    int clientW = S(500);
    int clientH = S(450);
    RECT windowRect = { 0, 0, clientW, clientH };
    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU;
    DWORD exStyle = WS_EX_TOOLWINDOW;
    typedef BOOL(WINAPI* AdjustRectForDpiFn)(LPRECT, DWORD, BOOL, DWORD, UINT);
    HMODULE user32 = GetModuleHandleW(L"user32.dll");
    AdjustRectForDpiFn adjust =
        (AdjustRectForDpiFn)GetProcAddress(user32, "AdjustWindowRectExForDpi");
    if (adjust) {
        adjust(&windowRect, style, FALSE, exStyle, (UINT)g_dpi);
    } else {
        AdjustWindowRectEx(&windowRect, style, FALSE, exStyle);
    }
    int width = windowRect.right - windowRect.left;
    int height = windowRect.bottom - windowRect.top;

    RECT mainRect = {};
    GetWindowRect(g_hwnd, &mainRect);
    int x = mainRect.left + ((mainRect.right - mainRect.left) - width) / 2;
    int y = mainRect.top + ((mainRect.bottom - mainRect.top) - height) / 2;

    HWND settings = CreateWindowExW(exStyle, kAceSettingsClass, L"腾讯游戏模式设置",
                                    style, x, y, width, height, g_hwnd, nullptr, instance, nullptr);
    if (!settings) return;

    EnableWindow(g_hwnd, FALSE);
    ShowWindow(settings, SW_SHOW);
    UpdateWindow(settings);
    SetForegroundWindow(settings);
    SetFocus(settings);
}

static void OnSampleTimer()
{
    SampleCpu();
    SampleMemory();
    SampleGpu();
    UpdateFps();
    UpdateAceMode();
    UpdateAppMode();

    if (g_warning && g_metrics.memPercent < g_threshold) {
        g_warning = false;
    }
    if (g_autoBlocked && g_metrics.memPercent < g_threshold) {
        g_autoBlocked = false;
    }
    if (g_warning) {
        UpdateWarningText();
    }

    if (g_auto && !g_busy && !g_dragging && !g_autoBlocked &&
        g_metrics.memPercent >= g_threshold) {
        ULONGLONG now = GetTickCount64();
        if (g_lastCleanupTick == 0 || now - g_lastCleanupTick >= kAutoCooldownMs) {
            StartCleanup(true);
        }
    }
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
    case WM_CREATE:
#ifndef SPECIAL_VERSION
        g_clipboardListening = AddClipboardFormatListener(hwnd) != FALSE;
#endif
        return 0;

    case WM_CLIPBOARDUPDATE:
#ifndef SPECIAL_VERSION
        CaptureClipboard();
        InvalidateRect(hwnd, nullptr, FALSE);
#endif
        return 0;

    case WM_ERASEBKGND:
        return 1;

    case WM_PAINT: {
        PAINTSTRUCT ps = {};
        HDC dc = BeginPaint(hwnd, &ps);
        RECT client = {};
        GetClientRect(hwnd, &client);
        int width = client.right - client.left;
        int height = client.bottom - client.top;
        EnsureBackBuffer(dc, width, height);
        if (g_memDC && g_backBmp) {
            PaintContent(g_memDC, width, height);
            BitBlt(dc, 0, 0, width, height, g_memDC, 0, 0, SRCCOPY);
        } else {
            PaintContent(dc, width, height);
        }
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED) {
            SetProcessWorkingSetSize(GetCurrentProcess(), (SIZE_T)-1, (SIZE_T)-1);
        }
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;

    case WM_DPICHANGED: {
        g_dpi = HIWORD(wParam);
        if (!g_dpi) g_dpi = 96;
        CreateFonts();
        if (g_minimal) {
            PositionMinimalWindow();
        } else if (g_compact) {
            PositionCompactWindow();
        } else {
            int width = 0, height = 0;
            WindowSizeForDpi(g_dpi, &width, &height);
            RECT* suggested = (RECT*)lParam;
            SetWindowPos(hwnd, nullptr, suggested ? suggested->left : 0,
                         suggested ? suggested->top : 0, width, height,
                         SWP_NOZORDER | SWP_NOACTIVATE);
        }
        InvalidateRect(hwnd, nullptr, TRUE);
        return 0;
    }

    case WM_MOUSEMOVE: {
        if (!g_trackingMouse) {
            TRACKMOUSEEVENT track = {};
            track.cbSize = sizeof(track);
            track.dwFlags = TME_LEAVE;
            track.hwndTrack = hwnd;
            TrackMouseEvent(&track);
            g_trackingMouse = true;
        }
        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);
        if (g_bgPanelOpen) {
            RECT panel = GetBackgroundPanelRect();
            int newHover = HOVER_NONE;
            if (PointIn(panel, x, y)) {
                RECT close = { panel.right - S(32), panel.top + S(8), panel.right - S(8), panel.top + S(32) };
                if (PointIn(close, x, y)) newHover = HOVER_BG_PANEL_CLOSE;
                else if (kSpecialTheme && PointIn(GetBackgroundNameSaveRect(), x, y)) newHover = HOVER_BG_NAME;
                else if (PointIn(GetBackgroundImageButtonRect(), x, y)) newHover = HOVER_BG_IMAGE;
                else if (PointIn(GetBackgroundResetButtonRect(), x, y)) newHover = HOVER_BG_RESET;
            }
            if (newHover != g_hover) {
                g_hover = newHover;
                InvalidateRect(hwnd, nullptr, FALSE);
            }
            return 0;
        }
        if (g_pickerOpen) {
            RECT r = GetPickerRect();
            int newHover = HOVER_NONE;
            int newRow = -1;
            if (PickerContains(x, y)) {
                RECT close = { r.right - S(32), r.top + S(6), r.right - S(8), r.top + S(30) };
                int footerTop = r.bottom - GetPickerFooterHeight();
                RECT clear = { r.left + S(10), footerTop + S(6), r.left + S(94), footerTop + S(30) };
                RECT done = { r.right - S(76), footerTop + S(6), r.right - S(10), footerTop + S(30) };
                if (PointIn(close, x, y)) newHover = HOVER_PICKER_CLOSE;
                else if (PointIn(clear, x, y)) newHover = HOVER_PICKER_CLEAR;
                else if (PointIn(done, x, y)) newHover = HOVER_PICKER_DONE;
                else newRow = PickerRowAt(x, y);
            }
            if (newHover != g_hover || newRow != g_pickerHoverRow) {
                g_hover = newHover;
                g_pickerHoverRow = newRow;
                InvalidateRect(hwnd, nullptr, FALSE);
            }
            return 0;
        }
#ifndef SPECIAL_VERSION
        {
            int row = ClipboardHistoryIndexAt(x, y, g_compact);
            int quick = QuickAppAt(x, y);
            if (row != g_clipboardHoverRow || quick != g_quickHover) {
                g_clipboardHoverRow = row;
                g_quickHover = quick;
                InvalidateRect(hwnd, nullptr, FALSE);
            }
        }
#endif
        if (g_compactDragging) {
            POINT cursor = {};
            GetCursorPos(&cursor);
            int newX = g_compactDragWindow.left + (cursor.x - g_compactDragStart.x);
            int newY = g_compactDragWindow.top + (cursor.y - g_compactDragStart.y);
            SetWindowPos(hwnd, HWND_TOPMOST, newX, newY, 0, 0,
                         SWP_NOSIZE | SWP_NOACTIVATE);
            return 0;
        }
        if (g_dragging) {
            UpdateThresholdFromMouse(x);
        }
        int hover = g_dragging ? HOVER_SLIDER : HitTest(x, y);
        if (hover != g_hover) {
            g_hover = hover;
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;
    }

    case WM_MOUSELEAVE:
        g_trackingMouse = false;
        if (!g_dragging && g_hover != HOVER_NONE) {
            g_hover = HOVER_NONE;
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;

    case WM_SETCURSOR:
        if (LOWORD(lParam) == HTCLIENT) {
            POINT pt = {};
            GetCursorPos(&pt);
            ScreenToClient(hwnd, &pt);
            if (g_bgPanelOpen) {
                SetCursor(LoadCursorW(nullptr, PointIn(GetBackgroundPanelRect(), pt.x, pt.y)
                                                  ? IDC_HAND : IDC_ARROW));
                return TRUE;
            }
            if (g_pickerOpen) {
                SetCursor(LoadCursorW(nullptr, PickerContains(pt.x, pt.y) ? IDC_HAND : IDC_ARROW));
                return TRUE;
            }
            int hover = HitTest(pt.x, pt.y);
            if (hover != HOVER_NONE) {
                SetCursor(LoadCursorW(nullptr, IDC_HAND));
                return TRUE;
            }
            if (g_compact && PointIn(GetCompactLayout().dragArea, pt.x, pt.y)) {
                SetCursor(LoadCursorW(nullptr, IDC_SIZEALL));
                return TRUE;
            }
            SetCursor(LoadCursorW(nullptr, IDC_ARROW));
            return TRUE;
        }
        break;

    case WM_LBUTTONDBLCLK:
        if (g_minimal) {
            SetCompactMode(true);
            return 0;
        }
        if (g_compact) {
            POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
            if (PointIn(GetCompactLayout().dragArea, pt.x, pt.y)) {
                SetCompactMode(false);
                return 0;
            }
        }
        break;

    case WM_RBUTTONUP:
        if (g_bgPanelOpen) {
            CloseBackgroundPanel();
            return 0;
        }
        if (g_pickerOpen) {
            CloseAppPicker();
            return 0;
        }
        ShowWindowModeMenu(hwnd);
        return 0;

    case WM_LBUTTONDOWN: {
        SetFocus(hwnd);
        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);
        if (g_bgPanelOpen) {
            RECT panel = GetBackgroundPanelRect();
            if (x < panel.left || x >= panel.right || y < panel.top || y >= panel.bottom) {
                CloseBackgroundPanel();
                return 0;
            }
            RECT close = { panel.right - S(32), panel.top + S(8), panel.right - S(8), panel.top + S(32) };
            if (PointIn(close, x, y)) {
                CloseBackgroundPanel();
                return 0;
            }
            if (PointIn(GetBackgroundImageButtonRect(), x, y)) {
                ChooseBackgroundImage();
                return 0;
            }
            if (PointIn(GetBackgroundResetButtonRect(), x, y)) {
                g_bgPreset = 0;
                g_bgUseImage = false;
                SaveSettings();
                InvalidateRect(hwnd, nullptr, TRUE);
                return 0;
            }
            for (int i = 0; i < kBackgroundPresetCount; ++i) {
                if (PointIn(GetBackgroundSwatchRect(i), x, y)) {
                    g_bgPreset = i;
                    g_bgUseImage = false;
                    SaveSettings();
                    InvalidateRect(hwnd, nullptr, TRUE);
                    return 0;
                }
            }
            return 0;
        }
        if (g_pickerOpen) {
            RECT r = GetPickerRect();
            if (!PickerContains(x, y)) {
                CloseAppPicker();
                return 0;
            }
            RECT close = { r.right - S(32), r.top + S(6), r.right - S(8), r.top + S(30) };
            int footerTop = r.bottom - GetPickerFooterHeight();
            RECT clear = { r.left + S(10), footerTop + S(6), r.left + S(94), footerTop + S(30) };
            RECT done = { r.right - S(76), footerTop + S(6), r.right - S(10), footerTop + S(30) };
            if (PointIn(close, x, y)) {
                CloseAppPicker();
                return 0;
            }
            if (PointIn(clear, x, y)) {
                ClearAppPickerSelections();
                return 0;
            }
            if (PointIn(done, x, y)) {
                CloseAppPicker();
                return 0;
            }
            int row = PickerRowAt(x, y);
            if (row >= 0 && row < g_appCount) {
                if (g_pickerMode == 1) {
                    SelectSingleApp(g_apps[row].path);
                    CloseAppPicker();
                } else {
                    if (!g_pickerChecked[row] && g_multiCount >= 12) {
                        return 0;
                    }
                    g_pickerChecked[row] = !g_pickerChecked[row];
                    ToggleMultiApp(g_apps[row].path);
                }
                return 0;
            }
            return 0;
        }
#ifndef SPECIAL_VERSION
        int clipIndex = ClipboardHistoryIndexAt(x, y, g_compact);
        if (clipIndex >= 0 && clipIndex < g_clipboardCount) {
            ClipboardEntry& entry = g_clipboardHistory[clipIndex];
            if (entry.kind == CLIPBOARD_TEXT) {
                CopyTextToClipboard(entry.text);
            } else if (entry.kind == CLIPBOARD_IMAGE) {
                ShowClipboardImage(entry.image);
            }
            return 0;
        }
        int quickIndex = QuickAppAt(x, y);
        if (quickIndex >= 0) {
            ActivateQuickApp(quickIndex);
            return 0;
        }
#endif
        if (g_minimal) {
            MinimalLayout m = GetMinimalLayout();
            if (PointIn(m.expandButton, x, y)) {
                g_pressedMinimalExpand = true;
            }
            return 0;
        }
        if (g_compact) {
            CompactLayout c = GetCompactLayout();
            if (!g_busy && PointIn(c.trimButton, x, y)) {
                g_pressedTrim = true;
                InvalidateRect(hwnd, nullptr, FALSE);
            } else if (PointIn(c.minimalButton, x, y)) {
                g_pressedMinimal = true;
            } else if (PointIn(c.expandButton, x, y)) {
                g_pressedExpand = true;
            } else if (PointIn(c.closeButton, x, y)) {
                g_pressedCompactClose = true;
            } else if (PointIn(c.dragArea, x, y)) {
                g_compactDragging = true;
                GetCursorPos(&g_compactDragStart);
                GetWindowRect(hwnd, &g_compactDragWindow);
                SetCapture(hwnd);
                SetCursor(LoadCursorW(nullptr, IDC_SIZEALL));
            }
            return 0;
        }
        Layout l = GetLayout();
        if (!g_busy && PointIn(l.trimButton, x, y)) {
            g_pressedTrim = true;
            InvalidateRect(hwnd, nullptr, FALSE);
        } else if (PointIn(l.toggle, x, y)) {
            g_pressedToggle = true;
        } else if (PointIn(l.toggleCloseAuto, x, y)) {
            g_pressedCloseAuto = true;
        } else if (PointIn(l.toggleCloseManual, x, y)) {
            g_pressedCloseManual = true;
        } else if (PointIn(l.aceToggle, x, y)) {
            g_pressedAceToggle = true;
        } else if (PointIn(l.aceSettings, x, y)) {
            g_pressedAceSettings = true;
        } else if (PointIn(l.compactButton, x, y)) {
            g_pressedCompact = true;
        } else if (PointIn(l.minimalButton, x, y)) {
            g_pressedMinimal = true;
        } else if (PointIn(l.singleSwitch, x, y)) {
            g_pressedSingleSwitch = true;
        } else if (PointIn(l.multiSwitch, x, y)) {
            g_pressedMultiSwitch = true;
        } else if (PointIn(l.singleField, x, y)) {
            g_pressedSingleField = true;
        } else if (PointIn(l.multiField, x, y)) {
            g_pressedMultiField = true;
        } else if (PointIn(l.backgroundButton, x, y)) {
            g_pressedBackground = true;
        } else if (PointIn(l.sliderHit, x, y) || PointIn(l.slider, x, y)) {
            g_dragging = true;
            SetCapture(hwnd);
            UpdateThresholdFromMouse(x);
            InvalidateRect(hwnd, nullptr, FALSE);
        } else if (!g_elevated && PointIn(l.adminChip, x, y)) {
            g_pressedAdmin = true;
        }
        return 0;
    }

    case WM_LBUTTONUP: {
        int x = GET_X_LPARAM(lParam);
        int y = GET_Y_LPARAM(lParam);
        if (g_minimal) {
            MinimalLayout m = GetMinimalLayout();
            if (g_pressedMinimalExpand) {
                g_pressedMinimalExpand = false;
                if (PointIn(m.expandButton, x, y)) {
                    SetCompactMode(true);
                    return 0;
                }
            }
            return 0;
        }
        if (g_compact) {
            CompactLayout c = GetCompactLayout();
            if (g_compactDragging) {
                g_compactDragging = false;
                if (GetCapture() == hwnd) ReleaseCapture();
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            if (g_pressedTrim) {
                g_pressedTrim = false;
                if (!g_busy && PointIn(c.trimButton, x, y)) {
                    g_autoBlocked = false;
                    StartCleanup(false);
                }
                InvalidateRect(hwnd, nullptr, FALSE);
            }
            if (g_pressedMinimal) {
                g_pressedMinimal = false;
                if (PointIn(c.minimalButton, x, y)) {
                    SetMinimalMode();
                    return 0;
                }
            }
            if (g_pressedExpand) {
                g_pressedExpand = false;
                if (PointIn(c.expandButton, x, y)) {
                    SetCompactMode(false);
                    return 0;
                }
            }
            if (g_pressedCompactClose) {
                g_pressedCompactClose = false;
                if (PointIn(c.closeButton, x, y)) {
                    PostMessageW(hwnd, WM_CLOSE, 0, 0);
                    return 0;
                }
            }
            return 0;
        }
        Layout l = GetLayout();
        if (g_pressedTrim) {
            g_pressedTrim = false;
            if (!g_busy && PointIn(l.trimButton, x, y)) {
                g_autoBlocked = false;
                StartCleanup(false);
            }
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        if (g_pressedToggle) {
            g_pressedToggle = false;
            if (PointIn(l.toggle, x, y)) ToggleAuto();
        }
        if (g_pressedCloseAuto) {
            g_pressedCloseAuto = false;
            if (PointIn(l.toggleCloseAuto, x, y)) ToggleCloseAuto();
        }
        if (g_pressedCloseManual) {
            g_pressedCloseManual = false;
            if (PointIn(l.toggleCloseManual, x, y)) ToggleCloseManual();
        }
        if (g_pressedAceToggle) {
            g_pressedAceToggle = false;
            if (PointIn(l.aceToggle, x, y)) ToggleAceMode();
        }
        if (g_pressedAceSettings) {
            g_pressedAceSettings = false;
            if (PointIn(l.aceSettings, x, y)) OpenAceSettings();
        }
        if (g_pressedCompact) {
            g_pressedCompact = false;
            if (PointIn(l.compactButton, x, y)) {
                SetCompactMode(true);
                return 0;
            }
        }
        if (g_pressedMinimal) {
            g_pressedMinimal = false;
            if (PointIn(l.minimalButton, x, y)) {
                SetMinimalMode();
                return 0;
            }
        }
        if (g_pressedSingleSwitch) {
            g_pressedSingleSwitch = false;
            if (PointIn(l.singleSwitch, x, y)) {
                bool wasOn = g_appMode == 1;
                SetAppMode(wasOn ? 0 : 1);
                if (!wasOn && !g_singleAppPath[0]) OpenAppPicker(1);
            }
        }
        if (g_pressedMultiSwitch) {
            g_pressedMultiSwitch = false;
            if (PointIn(l.multiSwitch, x, y)) {
                bool wasOn = g_appMode == 2;
                SetAppMode(wasOn ? 0 : 2);
                if (!wasOn && g_multiCount == 0) OpenAppPicker(2);
            }
        }
        if (g_pressedSingleField) {
            g_pressedSingleField = false;
            if (PointIn(l.singleField, x, y)) OpenAppPicker(1);
        }
        if (g_pressedMultiField) {
            g_pressedMultiField = false;
            if (PointIn(l.multiField, x, y)) OpenAppPicker(2);
        }
        if (g_pressedBackground) {
            g_pressedBackground = false;
            if (PointIn(l.backgroundButton, x, y)) OpenBackgroundPanel();
        }
        if (g_pressedAdmin) {
            g_pressedAdmin = false;
            if (!g_elevated && PointIn(l.adminChip, x, y)) {
                RelaunchElevated();
                return 0;
            }
        }
        if (g_dragging) {
            g_dragging = false;
            if (GetCapture() == hwnd) ReleaseCapture();
            SaveSettings();
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_CAPTURECHANGED:
        if (g_compactDragging) {
            g_compactDragging = false;
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        if (g_dragging) {
            g_dragging = false;
            SaveSettings();
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;

    case WM_MOUSEWHEEL:
        if (g_pickerOpen) {
            int delta = GET_WHEEL_DELTA_WPARAM(wParam);
            int visibleRows = GetPickerVisibleRows();
            int maxScroll = g_appCount > visibleRows ? g_appCount - visibleRows : 0;
            g_pickerScroll -= delta / WHEEL_DELTA;
            if (g_pickerScroll < 0) g_pickerScroll = 0;
            if (g_pickerScroll > maxScroll) g_pickerScroll = maxScroll;
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
#ifndef SPECIAL_VERSION
        {
            POINT point = {};
            GetCursorPos(&point);
            ScreenToClient(hwnd, &point);
            RECT card = g_compact ? GetCompactLayout().clipboardCard : GetLayout().clipboardCard;
            if (PointIn(card, point.x, point.y) && g_clipboardCount > 5) {
                int delta = GET_WHEEL_DELTA_WPARAM(wParam);
                g_clipboardScroll -= delta / WHEEL_DELTA;
                if (g_clipboardScroll < 0) g_clipboardScroll = 0;
                if (g_clipboardScroll > g_clipboardCount - 5) g_clipboardScroll = g_clipboardCount - 5;
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
        }
#endif
        break;

    case WM_KEYDOWN:
        if (g_bgPanelOpen && wParam == VK_ESCAPE) {
            CloseBackgroundPanel();
            return 0;
        }
        if (g_pickerOpen && wParam == VK_ESCAPE) {
            CloseAppPicker();
            return 0;
        }
        if (g_compact && wParam == VK_ESCAPE) {
            SetCompactMode(false);
            return 0;
        }
        if ((wParam == VK_RETURN || wParam == VK_SPACE) && !g_busy && !g_dragging) {
            g_autoBlocked = false;
            StartCleanup(false);
            return 0;
        }
        break;

    case WM_TIMER:
        if (wParam == kSampleTimer) {
            OnSampleTimer();
#ifndef SPECIAL_VERSION
            UpdateForegroundInfo();
            ULONGLONG now = GetTickCount64();
            if (!g_pickerOpen && now >= g_quickNextScan) {
                g_quickNextScan = now + 5000;
                RefreshQuickApps();
            }
#endif
            return 0;
        }
        if (wParam == kSelfTrimTimer) {
            KillTimer(hwnd, kSelfTrimTimer);
            SetProcessWorkingSetSize(GetCurrentProcess(), (SIZE_T)-1, (SIZE_T)-1);
            SampleMemory();
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        break;

    case WM_APP_CLEAN_DONE: {
        CleanupResult* result = (CleanupResult*)lParam;
        FinishCleanup(wParam != 0, result);
        return 0;
    }

    case WM_CLOSE:
        g_closing = true;
        SaveSettings();
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        g_hwnd = nullptr;
#ifndef SPECIAL_VERSION
        if (g_clipboardListening) RemoveClipboardFormatListener(hwnd);
        g_clipboardListening = false;
        FreeClipboardHistory();
#endif
        RestoreAceProcesses();
        RestoreAppPriorities();
        FreeBackgroundBitmap();
        FreeWatermarkBitmap();
        StopFpsTrace();
        KillTimer(hwnd, kSampleTimer);
        KillTimer(hwnd, kSelfTrimTimer);
        CloseGpuQuery();
        if (g_backBmp) {
            SelectObject(g_memDC, g_oldBmp);
            DeleteObject(g_backBmp);
            g_backBmp = nullptr;
        }
        if (g_memDC) {
            DeleteDC(g_memDC);
            g_memDC = nullptr;
        }
        DestroyFonts();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, message, wParam, lParam);
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------
static void EnableDpiAwareness()
{
    typedef BOOL(WINAPI* SetDpiAwarenessContextFn)(HANDLE);
    HMODULE user32 = GetModuleHandleW(L"user32.dll");
    SetDpiAwarenessContextFn setContext =
        (SetDpiAwarenessContextFn)GetProcAddress(user32, "SetProcessDpiAwarenessContext");
    if (setContext) {
        // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
        if (setContext((HANDLE)-4)) return;
    }
    typedef BOOL(WINAPI* SetProcessDpiAwareFn)(void);
    SetProcessDpiAwareFn setAware =
        (SetProcessDpiAwareFn)GetProcAddress(user32, "SetProcessDPIAware");
    if (setAware) setAware();
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int)
{
    EnableDpiAwareness();
    LoadSettings();
    g_elevated = IsElevated();

    const wchar_t* commandLine = GetCommandLineW();
    bool replace = wcsstr(commandLine, L"--replace") != nullptr;

    g_mutex = CreateMutexW(nullptr, TRUE, kMutexName);
    if (g_mutex && GetLastError() == ERROR_ALREADY_EXISTS) {
        HWND existing = FindWindowW(kWindowClass, nullptr);
        if (existing && !replace) {
            if (IsIconic(existing)) ShowWindow(existing, SW_RESTORE);
            SetForegroundWindow(existing);
            FLASHWINFO info = {};
            info.cbSize = sizeof(info);
            info.hwnd = existing;
            info.dwFlags = FLASHW_ALL;
            info.uCount = 2;
            FlashWindowEx(&info);
            CloseHandle(g_mutex);
            return 0;
        }
        if (replace && existing) {
            for (int i = 0; i < 40 && IsWindow(existing); ++i) {
                Sleep(100);
            }
        }
    }

    WNDCLASSEXW wc = {};
    wc.cbSize = sizeof(wc);
    wc.style = CS_DBLCLKS | CS_DROPSHADOW;
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = instance;
    wc.hIcon = (HICON)LoadImageW(instance, MAKEINTRESOURCEW(101), IMAGE_ICON,
                                 GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON),
                                 LR_DEFAULTCOLOR);
    if (!wc.hIcon) wc.hIcon = LoadIconW(nullptr, IDI_APPLICATION);
    wc.hIconSm = (HICON)LoadImageW(instance, MAKEINTRESOURCEW(101), IMAGE_ICON,
                                   GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON),
                                   LR_DEFAULTCOLOR);
    if (!wc.hIconSm) wc.hIconSm = wc.hIcon;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = nullptr;
    wc.lpszClassName = kWindowClass;
    wc.lpszMenuName = nullptr;

    if (!RegisterClassExW(&wc)) {
        MessageBoxW(nullptr, L"无法注册窗口类。", kWindowTitle, MB_OK | MB_ICONERROR);
        return 1;
    }

    DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
    g_hwnd = CreateWindowExW(0, kWindowClass, kWindowTitle, style,
                             CW_USEDEFAULT, CW_USEDEFAULT, 860, 640,
                             nullptr, nullptr, instance, nullptr);
    if (!g_hwnd) {
        MessageBoxW(nullptr, L"无法创建应用窗口。", kWindowTitle, MB_OK | MB_ICONERROR);
        return 1;
    }

    g_dpi = (int)GetWindowDpiSafe(g_hwnd);
    CreateFonts();
    ResizeForCurrentDpi(true);
    InitMetrics();
    StartFpsTrace();

    ShowWindow(g_hwnd, SW_SHOW);
    if (kSpecialTheme) SetWindowTextW(g_hwnd, g_displayName);
#ifndef SPECIAL_VERSION
    CaptureClipboard();
    UpdateForegroundInfo();
    RefreshQuickApps();
#endif
    UpdateWindow(g_hwnd);
    SetTimer(g_hwnd, kSampleTimer, 1000, nullptr);
    SetTimer(g_hwnd, kSelfTrimTimer, 2200, nullptr);

    MSG msg = {};
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    if (g_mutex) {
        CloseHandle(g_mutex);
        g_mutex = nullptr;
    }
    return (int)msg.wParam;
}
